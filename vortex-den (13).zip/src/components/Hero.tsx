import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Zap, Star, Cpu } from "lucide-react";
import { Link } from "react-router-dom";

export default function Hero() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-gray-900 via-black to-gray-800 rounded-3xl mx-4 my-8">
      {/* Background Pattern */}
      <div
        className={
          'absolute inset-0 bg-[url(\'data:image/svg+xml,%3Csvg width="60" height="60" viewBox="0 0 60 60" xmlns="http://www.w3.org/2000/svg"%3E%3Cg fill="none" fill-rule="evenodd"%3E%3Cg fill="%23FF0000" fill-opacity="0.1"%3E%3Ccircle cx="10" cy="10" r="2"/%3E%3C/g%3E%3C/g%3E%3C/svg%3E\')] opacity-20'
        }
      ></div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 lg:py-32">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8">
            <div className="space-y-4">
              <Badge
                variant="secondary"
                className="bg-hexon-red/10 text-hexon-red border-hexon-red/20 hover:bg-hexon-red/20"
              >
                <Zap className="w-3 h-3 mr-1" />
                Nouveau : Config RTX 5090
              </Badge>

              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-tight">
                Le PC Gamer qui
                <span className="block text-transparent bg-clip-text bg-gradient-to-r from-hexon-red to-red-400">
                  s'adapte à vous
                </span>
              </h1>

              <p className="text-xl text-gray-300 max-w-lg">
                Assemblage sur mesure, maintenance professionnelle et PC prêts à
                l'emploi. Votre expérience gaming n'a jamais été aussi
                performante.
              </p>
            </div>

            {/* Key Features */}
            <div className="flex flex-wrap gap-6 text-sm text-gray-300">
              <div className="flex items-center space-x-2">
                <Star className="w-4 h-4 text-hexon-red" />
                <span>Garantie 1 an</span>
              </div>
              <div className="flex items-center space-x-2">
                <Cpu className="w-4 h-4 text-hexon-red" />
                <span>Config sur mesure</span>
              </div>
              <div className="flex items-center space-x-2">
                <Zap className="w-4 h-4 text-hexon-red" />
                <span>Assemblage premium</span>
              </div>
            </div>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Link to="/pc-gamer">
                <Button
                  size="lg"
                  className="bg-hexon-red hover:bg-hexon-red-dark text-white font-semibold px-8 py-3 rounded-xl transition-all duration-200 transform hover:scale-105 w-full sm:w-auto"
                >
                  Voir nos configs
                </Button>
              </Link>
              <Link to="/pc-sur-mesure">
                <Button
                  size="lg"
                  className="bg-white text-black hover:bg-gray-100 border border-white font-semibold px-8 py-3 rounded-xl transition-all duration-200 w-full sm:w-auto"
                >
                  Créer mon PC sur mesure
                </Button>
              </Link>
            </div>

            {/* Key Features */}
            <div className="flex items-center space-x-6 pt-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-white">Sur mesure</div>
                <div className="text-sm text-gray-400">Configuration</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-white">1 an</div>
                <div className="text-sm text-gray-400">Garantie</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-white">Premium</div>
                <div className="text-sm text-gray-400">Assemblage</div>
              </div>
            </div>
          </div>

          {/* Right Content - Real Gaming PC Image */}
          <div className="relative">
            {/* Red Wave Background */}
            <div className="absolute inset-0 z-0">
              <svg
                viewBox="0 0 400 300"
                className="w-full h-full"
                preserveAspectRatio="none"
              >
                <defs>
                  <linearGradient
                    id="redWave"
                    x1="0%"
                    y1="0%"
                    x2="100%"
                    y2="100%"
                  >
                    <stop offset="0%" stopColor="#FF0000" stopOpacity="0.3" />
                    <stop offset="50%" stopColor="#DC2626" stopOpacity="0.2" />
                    <stop offset="100%" stopColor="#B91C1C" stopOpacity="0.1" />
                  </linearGradient>
                </defs>
                <path
                  d="M0,100 Q100,50 200,100 T400,80 L400,300 L0,300 Z"
                  fill="url(#redWave)"
                  className="animate-pulse-glow"
                />
                <path
                  d="M0,120 Q150,70 300,120 T400,100 L400,300 L0,300 Z"
                  fill="url(#redWave)"
                  opacity="0.5"
                  style={{ animationDelay: "1s" }}
                  className="animate-pulse-glow"
                />
              </svg>
            </div>

            {/* Gaming PC Image */}
            <div className="relative z-10 flex justify-center items-center h-full">
              <div className="relative group">
                {/* Glow effect behind the PC */}
                <div className="absolute -inset-4 bg-gradient-to-r from-hexon-red/40 via-red-600/30 to-hexon-red/40 rounded-2xl blur-2xl group-hover:blur-3xl transition-all duration-500 animate-pulse-glow"></div>

                {/* Main PC Image */}
                <div className="relative bg-black/20 backdrop-blur-sm rounded-3xl p-4 border border-hexon-red/30 shadow-2xl">
                  <img
                    src="https://cdn.builder.io/api/v1/assets/81b02be354c64bb2ab82d66e3c8d0ae8/20250220150104_fireball-cyb-1200_vitre-f6b600?format=webp&width=800"
                    alt="PC Gaming HEXON avec RGB Rouge"
                    className="w-full max-w-md h-auto rounded-xl shadow-2xl transform group-hover:scale-105 transition-transform duration-500"
                  />

                  {/* HEXON Branding overlay */}
                  <div className="absolute top-6 left-6 z-20">
                    <div className="bg-black/80 backdrop-blur-sm rounded-lg px-3 py-2 border border-hexon-red/50">
                      <div className="text-white font-bold text-sm font-roboto-condensed">
                        HE<span className="text-hexon-red">X</span>ON
                      </div>
                      <div className="text-xs text-gray-300">GAMING</div>
                    </div>
                  </div>

                  {/* Performance indicator */}
                  <div className="absolute bottom-6 right-6 z-20">
                    <div className="bg-black/80 backdrop-blur-sm rounded-lg px-3 py-2 border border-hexon-red/50">
                      <div className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-hexon-red rounded-full animate-pulse"></div>
                        <span className="text-white text-xs font-medium">
                          RTX READY
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Floating Particles */}
            <div className="absolute top-1/4 left-1/4 w-3 h-3 bg-hexon-red/60 rounded-full animate-pulse-glow"></div>
            <div
              className="absolute top-3/4 right-1/4 w-2 h-2 bg-red-400/60 rounded-full animate-pulse-glow"
              style={{ animationDelay: "2s" }}
            ></div>
            <div
              className="absolute top-1/2 left-1/6 w-1 h-1 bg-hexon-red/80 rounded-full animate-pulse-glow"
              style={{ animationDelay: "3s" }}
            ></div>
          </div>
        </div>
      </div>

      {/* Bottom curve */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1440 120" fill="none" className="w-full h-auto">
          <path
            d="M0,64L48,69.3C96,75,192,85,288,85.3C384,85,480,75,576,64C672,53,768,43,864,48C960,53,1056,75,1152,80C1248,85,1344,75,1392,69.3L1440,64L1440,120L1392,120C1344,120,1248,120,1152,120C1056,120,960,120,864,120C768,120,672,120,576,120C480,120,384,120,288,120C192,120,96,120,48,120L0,120Z"
            fill="white"
          />
        </svg>
      </div>
    </section>
  );
}
