import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star, Cpu, HardDrive, Zap, Monitor } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";

const products = [
  {
    id: 1,
    name: "HEXON FURY RTX 5060",
    category: "PC Gamer Entrée",
    price: 1299,
    originalPrice: 1399,
    rating: 0,
    reviews: 0,
    badge: "Populaire",
    badgeColor: "bg-green-500",
    specs: [
      { icon: Cpu, text: "Intel Core i5-14400F" },
      { icon: Monitor, text: "NVIDIA RTX 5060 16GB" },
      { icon: HardDrive, text: "16GB DDR5 + 1TB NVMe" },
      { icon: Zap, text: "650W 80+ Gold" },
    ],
    image: "/api/placeholder/400/300",
    featured: false,
  },
  {
    id: 2,
    name: "HEXON DESTROYER RTX 5070",
    category: "PC Gamer Premium",
    price: 1899,
    originalPrice: null,
    rating: 0,
    reviews: 0,
    badge: "Nouveau",
    badgeColor: "bg-hexon-red",
    specs: [
      { icon: Cpu, text: "Intel Core i7-14700F" },
      { icon: Monitor, text: "NVIDIA RTX 5070 16GB" },
      { icon: HardDrive, text: "32GB DDR5 + 2TB NVMe" },
      { icon: Zap, text: "750W 80+ Gold" },
    ],
    image: "/api/placeholder/400/300",
    featured: true,
  },
  {
    id: 3,
    name: "HEXON APEX RTX 5090",
    category: "PC Gamer Elite",
    price: 3499,
    originalPrice: null,
    rating: 0,
    reviews: 0,
    badge: "Elite",
    badgeColor: "bg-purple-600",
    specs: [
      { icon: Cpu, text: "Intel Core i9-14900K" },
      { icon: Monitor, text: "NVIDIA RTX 5090 32GB" },
      { icon: HardDrive, text: "64GB DDR5 + 4TB NVMe" },
      { icon: Zap, text: "1000W 80+ Platinum" },
    ],
    image: "/api/placeholder/400/300",
    featured: false,
  },
];

export default function Products() {
  const navigate = useNavigate();

  const handleAddToCart = (productId: number, productName: string) => {
    // Here you would typically add to cart logic (global state, API call, etc.)
    console.log(`Added ${productName} to cart`);

    // Show a quick confirmation and redirect to cart
    alert(`${productName} ajouté au panier !`);
    navigate("/cart");
  };

  return (
    <section className="py-20 bg-hexon-gray-light">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <Badge
            variant="secondary"
            className="mb-4 bg-hexon-red/10 text-hexon-red border-hexon-red/20"
          >
            Nos PC Gamers
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold text-black mb-6 font-roboto-condensed">
            NOS MEILLEURES <span className="text-hexon-red">VENTES</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Découvrez notre sélection de PC gaming haute performance, assemblés
            avec les meilleurs composants et garantis 1 an.
          </p>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {products.map((product) => (
            <Card
              key={product.id}
              className={`group hover:shadow-2xl transition-all duration-300 overflow-hidden ${
                product.featured
                  ? "border-2 border-hexon-red shadow-lg scale-105"
                  : "border border-gray-200 hover:border-hexon-red/30"
              }`}
            >
              {/* Product Image */}
              <CardHeader className="p-0 relative">
                <div className="relative aspect-[4/3] bg-gradient-to-br from-gray-100 to-gray-200 overflow-hidden">
                  {/* Product glow effect */}
                  <div className="absolute inset-4 bg-hexon-red/20 rounded-full blur-3xl opacity-40 animate-pulse-glow"></div>

                  {/* Placeholder for PC image */}
                  <div className="absolute inset-0 bg-gradient-to-br from-gray-800 via-black to-gray-900 flex items-center justify-center">
                    <div className="bg-black rounded-lg p-6 border border-hexon-red/30 shadow-2xl">
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <div className="w-3 h-3 bg-hexon-red rounded-full animate-pulse"></div>
                          <div className="text-xs text-gray-400 font-mono">
                            HEXON
                          </div>
                        </div>
                        <div className="space-y-1">
                          <div className="h-2 bg-gradient-to-r from-hexon-red to-red-400 rounded-full"></div>
                          <div className="h-2 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full w-3/4"></div>
                          <div className="h-2 bg-gradient-to-r from-green-500 to-teal-500 rounded-full w-1/2"></div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Badges */}
                  <div className="absolute top-4 left-4 z-10">
                    <Badge
                      className={`${product.badgeColor} text-white font-semibold`}
                    >
                      {product.badge}
                    </Badge>
                  </div>

                  {product.featured && (
                    <div className="absolute top-4 right-4 z-10">
                      <Badge className="bg-white text-hexon-red border border-hexon-red font-semibold">
                        🔥 TOP VENTE
                      </Badge>
                    </div>
                  )}
                </div>
              </CardHeader>

              <CardContent className="p-6 flex-1">
                {/* Product Info */}
                <div className="mb-4">
                  <div className="text-sm text-gray-500 mb-1">
                    {product.category}
                  </div>
                  <h3 className="text-xl font-bold text-black group-hover:text-hexon-red transition-colors mb-2">
                    {product.name}
                  </h3>

                  {/* Rating - only show if product has reviews */}
                  {product.reviews > 0 && (
                    <div className="flex items-center space-x-2 mb-4">
                      <div className="flex items-center">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-4 h-4 ${i < Math.floor(product.rating) ? "text-yellow-400 fill-current" : "text-gray-300"}`}
                          />
                        ))}
                      </div>
                      <span className="text-sm text-gray-600">
                        {product.rating} ({product.reviews} avis)
                      </span>
                    </div>
                  )}
                </div>

                {/* Specs */}
                <div className="space-y-3 mb-6">
                  {product.specs.map((spec, index) => (
                    <div
                      key={index}
                      className="flex items-center space-x-3 text-sm"
                    >
                      <spec.icon className="w-4 h-4 text-hexon-red flex-shrink-0" />
                      <span className="text-gray-700">{spec.text}</span>
                    </div>
                  ))}
                </div>
              </CardContent>

              <CardFooter className="p-6 pt-0 flex items-center justify-between">
                {/* Price */}
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <span className="text-2xl font-bold text-hexon-red">
                      {product.price.toLocaleString()}€
                    </span>
                    {product.originalPrice && (
                      <span className="text-lg text-gray-400 line-through">
                        {product.originalPrice.toLocaleString()}€
                      </span>
                    )}
                  </div>
                  <div className="text-sm text-gray-500">
                    Ou 3x {Math.round(product.price / 3)}€ sans frais
                  </div>
                </div>

                {/* Add to Cart */}
                <Button
                  onClick={() => handleAddToCart(product.id, product.name)}
                  className={`${
                    product.featured
                      ? "bg-hexon-red hover:bg-hexon-red-dark text-white"
                      : "bg-black hover:bg-gray-800 text-white"
                  } font-semibold px-6 py-2 rounded-xl transition-all duration-200 transform hover:scale-105`}
                >
                  Ajouter au panier
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="text-center">
          <Link to="/pc-gamer">
            <Button
              size="lg"
              variant="outline"
              className="border-hexon-red text-hexon-red hover:bg-hexon-red hover:text-white font-semibold px-8 py-3 rounded-xl transition-all duration-200"
            >
              Voir tous nos PC Gamers
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}
