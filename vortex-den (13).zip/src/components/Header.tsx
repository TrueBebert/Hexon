import { Search, User, ShoppingCart, Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Link, useLocation } from "react-router-dom";
import { useState } from "react";

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
      {/* Top announcement bar */}
      <div className="bg-hexon-red text-white py-2 px-4 text-center text-sm font-medium">
        🔥 Assemblage premium • Support technique 7j/7 • Garantie 1 an
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <Link
                to="/"
                className="text-2xl font-bold font-roboto-condensed hover:opacity-80 transition-opacity"
              >
                HE<span className="text-hexon-red">X</span>ON
              </Link>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:block">
            <div className="flex items-baseline space-x-8">
              <Link
                to="/pc-gamer"
                className={`px-3 py-2 text-sm font-medium transition-colors ${
                  location.pathname === "/pc-gamer"
                    ? "text-hexon-red border-b-2 border-hexon-red"
                    : "text-gray-900 hover:text-hexon-red"
                }`}
              >
                PC Gamer
              </Link>
              <Link
                to="/pc-sur-mesure"
                className={`px-3 py-2 text-sm font-medium transition-colors ${
                  location.pathname === "/pc-sur-mesure"
                    ? "text-hexon-red border-b-2 border-hexon-red"
                    : "text-gray-900 hover:text-hexon-red"
                }`}
              >
                PC sur mesure
              </Link>
              <Link
                to="/maintenance"
                className={`px-3 py-2 text-sm font-medium transition-colors ${
                  location.pathname === "/maintenance"
                    ? "text-hexon-red border-b-2 border-hexon-red"
                    : "text-gray-900 hover:text-hexon-red"
                }`}
              >
                Maintenance
              </Link>
              <Link
                to="/contact"
                className={`px-3 py-2 text-sm font-medium transition-colors ${
                  location.pathname === "/contact"
                    ? "text-hexon-red border-b-2 border-hexon-red"
                    : "text-gray-900 hover:text-hexon-red"
                }`}
              >
                Contact
              </Link>
            </div>
          </nav>

          {/* Search Bar */}
          <div className="hidden md:block flex-1 max-w-md mx-8">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <Input
                type="search"
                placeholder="Rechercher un PC, composant..."
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-hexon-red focus:border-hexon-red"
              />
            </div>
          </div>

          {/* Right side actions */}
          <div className="flex items-center space-x-4">
            {/* User Account */}
            <Link to="/login">
              <Button
                variant="outline"
                size="sm"
                className="hidden md:flex items-center space-x-2 text-black border-gray-300 hover:text-hexon-red hover:border-hexon-red bg-white"
              >
                <User className="h-5 w-5" />
                <span>Connexion</span>
              </Button>
            </Link>

            {/* Shopping Cart */}
            <Link to="/cart">
              <Button variant="ghost" size="sm" className="relative">
                <ShoppingCart className="h-5 w-5 text-gray-700 hover:text-hexon-red" />
                <span className="absolute -top-1 -right-1 h-4 w-4 bg-hexon-red text-white text-xs rounded-full flex items-center justify-center">
                  3
                </span>
              </Button>
            </Link>

            {/* Mobile menu button */}
            <Button
              variant="ghost"
              size="sm"
              className="md:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              <Menu className="h-5 w-5" />
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden border-t border-gray-200 py-4">
            <div className="flex flex-col space-y-4">
              {/* Mobile Search */}
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-gray-400" />
                </div>
                <Input
                  type="search"
                  placeholder="Rechercher..."
                  className="block w-full pl-10 pr-3 py-2"
                />
              </div>

              {/* Mobile Menu Links */}
              <div className="flex flex-col space-y-2">
                <Link
                  to="/pc-gamer"
                  className={`block px-3 py-2 text-base font-medium ${
                    location.pathname === "/pc-gamer"
                      ? "text-hexon-red"
                      : "text-gray-900 hover:text-hexon-red"
                  }`}
                  onClick={() => setIsMenuOpen(false)}
                >
                  PC Gamer
                </Link>
                <Link
                  to="/pc-sur-mesure"
                  className={`block px-3 py-2 text-base font-medium ${
                    location.pathname === "/pc-sur-mesure"
                      ? "text-hexon-red"
                      : "text-gray-900 hover:text-hexon-red"
                  }`}
                  onClick={() => setIsMenuOpen(false)}
                >
                  PC sur mesure
                </Link>
                <Link
                  to="/maintenance"
                  className={`block px-3 py-2 text-base font-medium ${
                    location.pathname === "/maintenance"
                      ? "text-hexon-red"
                      : "text-gray-900 hover:text-hexon-red"
                  }`}
                  onClick={() => setIsMenuOpen(false)}
                >
                  Maintenance
                </Link>
                <Link
                  to="/contact"
                  className={`block px-3 py-2 text-base font-medium ${
                    location.pathname === "/contact"
                      ? "text-hexon-red"
                      : "text-gray-900 hover:text-hexon-red"
                  }`}
                  onClick={() => setIsMenuOpen(false)}
                >
                  Contact
                </Link>
                <Link
                  to="/login"
                  className="text-gray-900 hover:text-hexon-red block px-3 py-2 text-base font-medium border-t border-gray-200 pt-4"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Connexion
                </Link>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Animated gradient border */}
      <div className="h-1 bg-gradient-to-r from-hexon-red via-red-600 to-hexon-red-dark"></div>
    </header>
  );
}
