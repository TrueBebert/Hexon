import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star, Quote } from "lucide-react";

const testimonials = [
  {
    id: 1,
    name: "Alexandre M.",
    title: "PC Gamer HEXON DESTROYER",
    rating: 5,
    date: "15 novembre 2024",
    content:
      "Incroyable ! Mon PC HEXON tourne parfaitement, les jeux en 4K sont fluides et le service client est top. L'assemblage est impeccable et la livraison a été très rapide. Je recommande vivement !",
    verified: true,
  },
  {
    id: 2,
    name: "Sophie L.",
    title: "Configuration sur mesure",
    rating: 5,
    date: "8 novembre 2024",
    content:
      "Service parfait du début à la fin. L'équipe m'a aidé à choisir les composants selon mon budget et mes besoins. Le PC arrive assemblé et testé, prêt à l'emploi. Très professionnel !",
    verified: true,
  },
  {
    id: 3,
    name: "Thomas R.",
    title: "Maintenance PC",
    rating: 5,
    date: "3 novembre 2024",
    content:
      "Mon PC avait des problèmes de surchauffe. HEXON a fait un diagnostic gratuit, remplacé le système de refroidissement rapidement. Maintenant il tourne comme un charme, merci !",
    verified: true,
  },
  {
    id: 4,
    name: "Marina K.",
    title: "PC Streaming HEXON FURY",
    rating: 4,
    date: "28 octobre 2024",
    content:
      "Parfait pour le streaming ! Aucun lag, encode en temps réel sans problème. Le design du boîtier est magnifique avec les LED rouges. Très satisfaite de mon achat.",
    verified: true,
  },
  {
    id: 5,
    name: "Kevin D.",
    title: "Upgrade gaming",
    rating: 5,
    date: "22 octobre 2024",
    content:
      "Après avoir fait upgrader ma CG chez HEXON, mon PC est devenu une bête ! Excellent conseil, prix correct et installation propre. L'équipe connaît vraiment son métier.",
    verified: true,
  },
  {
    id: 6,
    name: "Julie F.",
    title: "Premier PC Gamer",
    rating: 5,
    date: "18 octobre 2024",
    content:
      "Premier PC gamer, j'étais un peu perdue mais l'équipe HEXON m'a guidée parfaitement. Le PC correspond exactement à ce que je voulais, parfait pour jouer et travailler !",
    verified: true,
  },
];

export default function Testimonials() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <Badge
            variant="secondary"
            className="mb-4 bg-hexon-red/10 text-hexon-red border-hexon-red/20"
          >
            Témoignages
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold text-black mb-6 font-roboto-condensed">
            ILS NOUS ONT FAIT <span className="text-hexon-red">CONFIANCE</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Découvrez les retours de nos clients satisfaits qui ont choisi HEXON
            pour leur PC gaming et leurs services.
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {testimonials.map((testimonial) => (
            <Card
              key={testimonial.id}
              className="group hover:shadow-xl transition-all duration-300 border border-gray-200 hover:border-hexon-red/30 bg-gradient-to-br from-white to-gray-50"
            >
              <CardContent className="p-6">
                {/* Quote Icon */}
                <div className="flex justify-between items-start mb-4">
                  <Quote className="w-8 h-8 text-hexon-red/20" />
                  {testimonial.verified && (
                    <Badge
                      variant="secondary"
                      className="bg-green-100 text-green-800 border-green-200"
                    >
                      ✓ Vérifié
                    </Badge>
                  )}
                </div>

                {/* Rating */}
                <div className="flex items-center space-x-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-5 h-5 ${i < testimonial.rating ? "text-yellow-400 fill-current" : "text-gray-300"}`}
                    />
                  ))}
                </div>

                {/* Content */}
                <blockquote className="text-gray-700 mb-6 text-base leading-relaxed">
                  "{testimonial.content}"
                </blockquote>

                {/* Customer Info */}
                <div className="border-t border-gray-100 pt-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-semibold text-black">
                        {testimonial.name}
                      </div>
                      <div className="text-sm text-gray-500">
                        {testimonial.title}
                      </div>
                    </div>
                    <div className="text-xs text-gray-400">
                      {testimonial.date}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Trust Indicators */}
        <div className="bg-gradient-to-r from-hexon-gray-light to-white rounded-3xl p-8 lg:p-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
            <div className="space-y-2">
              <div className="text-3xl font-bold text-hexon-red">4.9/5</div>
              <div className="text-sm text-gray-600">Note moyenne</div>
              <div className="flex justify-center">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className="w-4 h-4 text-yellow-400 fill-current"
                  />
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <div className="text-3xl font-bold text-hexon-red">2500+</div>
              <div className="text-sm text-gray-600">PC assemblés</div>
            </div>

            <div className="space-y-2">
              <div className="text-3xl font-bold text-hexon-red">98%</div>
              <div className="text-sm text-gray-600">Clients satisfaits</div>
            </div>

            <div className="space-y-2">
              <div className="text-3xl font-bold text-hexon-red">100%</div>
              <div className="text-sm text-gray-600">Assemblage expert</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
