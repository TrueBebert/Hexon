import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import {
  Facebook,
  Twitter,
  Instagram,
  Youtube,
  Mail,
  Star,
} from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-hexon-black text-white">
      {/* Animated gradient border */}
      <div className="h-1 bg-gradient-to-r from-hexon-red via-red-600 to-hexon-red-dark"></div>

      {/* Main Footer Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand Section */}
          <div className="lg:col-span-1 space-y-6">
            <div>
              <div className="text-3xl font-bold font-roboto-condensed mb-4">
                HE<span className="text-hexon-red">X</span>ON
              </div>
              <p className="text-gray-300 text-sm leading-relaxed">
                Spécialiste du PC gaming depuis 2020. Assemblage sur mesure,
                maintenance professionnelle et service client d'exception pour
                tous vos besoins gaming.
              </p>
            </div>

            {/* Trust Indicators */}
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <Badge className="bg-hexon-red text-white">
                  <Star className="w-3 h-3 mr-1" />
                  Nouvelle entreprise
                </Badge>
                <span className="text-sm text-gray-300">
                  Passion et expertise gaming
                </span>
              </div>
              <div className="flex items-center space-x-2">
                <Badge className="bg-green-600 text-white">Garantie 1 an</Badge>
                <span className="text-sm text-gray-300">Sur tous nos PC</span>
              </div>
            </div>

            {/* Social Links */}
            <div className="space-y-3">
              <h4 className="font-semibold text-white">Suivez-nous</h4>
              <div className="flex space-x-3">
                <a
                  href="#"
                  className="p-2 bg-gray-800 hover:bg-hexon-red rounded-lg transition-colors"
                >
                  <Facebook className="w-5 h-5" />
                </a>
                <a
                  href="#"
                  className="p-2 bg-gray-800 hover:bg-hexon-red rounded-lg transition-colors"
                >
                  <Instagram className="w-5 h-5" />
                </a>
                <a
                  href="#"
                  className="p-2 bg-gray-800 hover:bg-hexon-red rounded-lg transition-colors"
                >
                  <Twitter className="w-5 h-5" />
                </a>
                <a
                  href="#"
                  className="p-2 bg-gray-800 hover:bg-hexon-red rounded-lg transition-colors"
                >
                  <Youtube className="w-5 h-5" />
                </a>
              </div>
            </div>
          </div>

          {/* Products & Services */}
          <div className="space-y-6">
            <h4 className="font-semibold text-white text-lg font-roboto-condensed">
              PRODUITS & SERVICES
            </h4>
            <ul className="space-y-3 text-sm">
              <li>
                <Link
                  to="/pc-gamer"
                  className="text-gray-300 hover:text-hexon-red transition-colors"
                >
                  PC Gamer prêts à l'emploi
                </Link>
              </li>
              <li>
                <Link
                  to="/pc-sur-mesure"
                  className="text-gray-300 hover:text-hexon-red transition-colors"
                >
                  Configuration sur mesure
                </Link>
              </li>
              <li>
                <Link
                  to="/maintenance"
                  className="text-gray-300 hover:text-hexon-red transition-colors"
                >
                  Maintenance & réparation
                </Link>
              </li>
            </ul>
          </div>

          {/* Support & Info */}
          <div className="space-y-6">
            <h4 className="font-semibold text-white text-lg font-roboto-condensed">
              SUPPORT & INFOS
            </h4>
            <ul className="space-y-3 text-sm">
              <li>
                <Link
                  to="/cgv"
                  className="text-gray-300 hover:text-hexon-red transition-colors"
                >
                  Conditions générales de vente
                </Link>
              </li>
              <li>
                <Link
                  to="/politique-confidentialite"
                  className="text-gray-300 hover:text-hexon-red transition-colors"
                >
                  Politique de confidentialité
                </Link>
              </li>
              <li>
                <Link
                  to="/livraison"
                  className="text-gray-300 hover:text-hexon-red transition-colors"
                >
                  Livraison & retours
                </Link>
              </li>
              <li>
                <Link
                  to="/garantie"
                  className="text-gray-300 hover:text-hexon-red transition-colors"
                >
                  Garantie & SAV
                </Link>
              </li>

              <li>
                <Link
                  to="/mentions-legales"
                  className="text-gray-300 hover:text-hexon-red transition-colors"
                >
                  Mentions légales
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact & Newsletter */}
          <div className="space-y-6">
            <h4 className="font-semibold text-white text-lg font-roboto-condensed">
              CONTACT
            </h4>

            {/* Contact Info */}
            <div className="space-y-3 text-sm">
              <div className="flex items-center space-x-3">
                <Mail className="w-4 h-4 text-hexon-red flex-shrink-0" />
                <span className="text-gray-300">contact@hexonpc.com</span>
              </div>
            </div>

            {/* Newsletter */}
            <div className="space-y-3">
              <h5 className="font-semibold text-white">Newsletter</h5>
              <p className="text-sm text-gray-300">
                Restez informé des nouveautés et offres exclusives
              </p>
              <div className="flex space-x-2">
                <Input
                  type="email"
                  placeholder="Votre email"
                  className="bg-gray-800 border-gray-700 text-white placeholder-gray-400 focus:border-hexon-red"
                />
                <Button className="bg-hexon-red hover:bg-hexon-red-dark text-white px-4">
                  <Mail className="w-4 h-4" />
                </Button>
              </div>
              <p className="text-xs text-gray-400">
                En vous inscrivant, vous acceptez de recevoir nos emails
                promotionnels
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="text-sm text-gray-400">
              © 2024 HEXON. Tous droits réservés. |
              <a
                href="#"
                className="hover:text-hexon-red transition-colors ml-1"
              >
                Politique de confidentialité
              </a>{" "}
              |
              <a
                href="#"
                className="hover:text-hexon-red transition-colors ml-1"
              >
                CGV
              </a>
            </div>

            <div className="flex items-center space-x-6 text-sm text-gray-400">
              <div className="flex space-x-2">
                <div className="bg-gray-700 rounded px-2 py-1 text-xs">
                  VISA
                </div>
                <div className="bg-gray-700 rounded px-2 py-1 text-xs">
                  MASTERCARD
                </div>
                <div className="bg-gray-700 rounded px-2 py-1 text-xs">
                  PAYPAL
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
