import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Link } from "react-router-dom";
import {
  Truck,
  Shield,
  Headphones,
  CreditCard,
  Wrench,
  Clock,
} from "lucide-react";

const faqs = [
  {
    question: "Comment sont assemblés vos PC ?",
    answer:
      "Nos PC sont assemblés avec soin par des experts gaming. Chaque configuration passe par des tests complets (stress test, benchmarks) pour garantir stabilité et performances optimales avant envoi.",
  },
  {
    question: "Quelle est la garantie offerte ?",
    answer:
      "Tous nos PC bénéficient d'une garantie de 1 an pièces et main d'œuvre. En cas de problème, nous prenons en charge la réparation ou le remplacement. Le support technique est inclus pendant toute la durée de garantie.",
  },
  {
    question: "Puis-je upgrader mon PC plus tard ?",
    answer:
      "Absolument ! Nos PC sont conçus pour être évolutifs. Nous proposons des services d'upgrade pour la carte graphique, la RAM, le stockage, etc. Notre équipe vous conseille sur les améliorations compatibles avec votre configuration.",
  },
  {
    question: "Comment fonctionne le service de maintenance ?",
    answer:
      "Nous offrons un diagnostic gratuit pour identifier les problèmes. Ensuite, nous proposons un devis détaillé pour les réparations nécessaires. Toutes nos interventions utilisent des pièces de qualité avec une garantie étendue.",
  },
  {
    question: "Quels moyens de paiement acceptez-vous ?",
    answer:
      "Nous acceptons les cartes bancaires, PayPal et virement SEPA. Pour les entreprises, nous acceptons également les bons de commande avec conditions spéciales.",
  },
  {
    question: "Les PC sont-ils testés avant livraison ?",
    answer:
      "Oui, chaque PC subit une batterie de tests complets : stress test CPU/GPU, test mémoire, vérification du refroidissement, benchmarks gaming, et test de stabilité 24h. Vous recevez un rapport de tests avec votre PC.",
  },
];

const guarantees = [
  {
    icon: Truck,
    title: "Assemblage premium",
    description: "Assemblage soigné par nos experts",
    details: "Tests complets avant envoi",
  },
  {
    icon: Shield,
    title: "Garantie 1 an",
    description: "Pièces et main d'œuvre incluses",
    details: "Support technique inclus",
  },
  {
    icon: Headphones,
    title: "Support 7j/7",
    description: "Équipe technique disponible",
    details: "Réponse sous 2h en moyenne",
  },
  {
    icon: CreditCard,
    title: "Paiement sécurisé",
    description: "Transactions cryptées SSL",
    details: "3D Secure & protection fraude",
  },
  {
    icon: Shield,
    title: "SAV premium",
    description: "Support technique expert",
    details: "Aide personnalisée incluse",
  },
  {
    icon: Clock,
    title: "Tests complets",
    description: "24h de tests de stabilité",
    details: "Rapport fourni avec le PC",
  },
];

export default function FAQ() {
  return (
    <section className="py-20 bg-hexon-gray-light">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <Badge
            variant="secondary"
            className="mb-4 bg-hexon-red/10 text-hexon-red border-hexon-red/20"
          >
            FAQ & Garanties
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold text-black mb-6 font-roboto-condensed">
            VOS QUESTIONS, <span className="text-hexon-red">NOS RÉPONSES</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Tout ce que vous devez savoir sur nos services, garanties et
            processus pour faire le bon choix en toute confiance.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* FAQ Section */}
          <div>
            <h3 className="text-2xl font-bold text-black mb-8 font-roboto-condensed">
              Questions fréquentes
            </h3>
            <Accordion type="single" collapsible className="space-y-4">
              {faqs.map((faq, index) => (
                <AccordionItem
                  key={index}
                  value={`item-${index}`}
                  className="bg-white border border-gray-200 rounded-xl px-6 hover:border-hexon-red/30 transition-colors"
                >
                  <AccordionTrigger className="text-left font-semibold text-black hover:text-hexon-red py-6 hover:no-underline">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-gray-700 pb-6 leading-relaxed">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>

            <div className="mt-8 p-6 bg-white rounded-xl border border-gray-200">
              <h4 className="font-semibold text-black mb-2">
                Vous ne trouvez pas la réponse à votre question ?
              </h4>
              <p className="text-gray-600 mb-4">
                Notre équipe support est là pour vous aider 7j/7
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <Link to="/contact">
                  <Button className="bg-hexon-red hover:bg-hexon-red-dark text-white w-full sm:w-auto">
                    Contacter le support
                  </Button>
                </Link>
              </div>
            </div>
          </div>

          {/* Guarantees Section */}
          <div>
            <h3 className="text-2xl font-bold text-black mb-8 font-roboto-condensed">
              Nos garanties & services
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {guarantees.map((guarantee, index) => (
                <Card
                  key={index}
                  className="bg-white border border-gray-200 hover:border-hexon-red/30 transition-all duration-300 hover:shadow-lg"
                >
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <div className="p-3 bg-hexon-red/10 rounded-xl">
                        <guarantee.icon className="w-6 h-6 text-hexon-red" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-semibold text-black mb-1">
                          {guarantee.title}
                        </h4>
                        <p className="text-sm text-gray-600 mb-1">
                          {guarantee.description}
                        </p>
                        <p className="text-xs text-gray-500">
                          {guarantee.details}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Contact CTA */}
            <div className="mt-8 bg-gradient-to-br from-hexon-black to-gray-800 rounded-xl p-8 text-white text-center">
              <h4 className="text-xl font-bold mb-3 font-roboto-condensed">
                Besoin d'aide personnalisée ?
              </h4>
              <p className="text-gray-300 mb-6">
                Nos experts vous conseillent gratuitement pour choisir votre
                configuration idéale
              </p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <Link to="/contact">
                  <Button className="bg-hexon-red hover:bg-hexon-red-dark text-white w-full sm:w-auto">
                    📞 Rappel gratuit
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
