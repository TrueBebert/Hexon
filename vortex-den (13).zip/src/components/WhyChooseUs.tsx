import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Shield, Zap, Users, Clock, CheckCircle, Star } from "lucide-react";

const features = [
  {
    id: 1,
    icon: Users,
    title: "Équipe passionnée",
    description:
      "Des experts en hardware et gaming pour vous conseiller et assembler votre PC parfait",
  },
  {
    id: 2,
    icon: Shield,
    title: "Garantie 1 an",
    description:
      "Tous nos PC sont garantis 1 an pièces et main d'œuvre avec support technique inclus",
  },
  {
    id: 3,
    icon: Zap,
    title: "Assemblage soigné",
    description:
      "Chaque PC est assemblé avec soin, testé pendant 24h et optimisé pour les meilleures performances",
  },
  {
    id: 4,
    icon: Clock,
    title: "Configs optimales",
    description:
      "Chaque PC est testé et optimisé pour garantir les meilleures performances gaming",
  },
];

export default function WhyChooseUs() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <Badge
            variant="secondary"
            className="mb-4 bg-hexon-red/10 text-hexon-red border-hexon-red/20"
          >
            Pourquoi HEXON
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold text-black mb-6 font-roboto-condensed">
            NOTRE <span className="text-hexon-red">ENGAGEMENT</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Chez HEXON, nous nous engageons à vous fournir le meilleur service
            et les meilleures performances pour votre PC gaming.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          {features.map((feature) => (
            <Card
              key={feature.id}
              className="group hover:shadow-xl transition-all duration-300 border border-gray-200 hover:border-hexon-red/30 bg-gradient-to-br from-white to-gray-50"
            >
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-hexon-red/10 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <feature.icon className="w-8 h-8 text-hexon-red" />
                </div>

                <h3 className="text-xl font-bold text-black mb-4 group-hover:text-hexon-red transition-colors">
                  {feature.title}
                </h3>

                <p className="text-gray-600 leading-relaxed">
                  {feature.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Bottom commitment */}
        <div className="bg-gradient-to-r from-hexon-gray-light to-white rounded-3xl p-8 lg:p-12 text-center">
          <h3 className="text-2xl font-bold text-black mb-4 font-roboto-condensed">
            Notre promesse
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div key="quality" className="space-y-2">
              <CheckCircle className="w-8 h-8 text-hexon-red mx-auto" />
              <div className="font-semibold text-black">Qualité garantie</div>
              <div className="text-sm text-gray-600">
                Composants de marque et assemblage professionnel
              </div>
            </div>

            <div key="service" className="space-y-2">
              <Star className="w-8 h-8 text-hexon-red mx-auto" />
              <div className="font-semibold text-black">Service premium</div>
              <div className="text-sm text-gray-600">
                Support technique et conseil personnalisé
              </div>
            </div>

            <div key="peace-of-mind" className="space-y-2">
              <Shield className="w-8 h-8 text-hexon-red mx-auto" />
              <div className="font-semibold text-black">Tranquillité</div>
              <div className="text-sm text-gray-600">
                Garantie étendue et SAV réactif
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
