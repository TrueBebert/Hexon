import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Wrench, Cpu, Gamepad2, Monitor, Settings, Clock } from "lucide-react";
import { Link } from "react-router-dom";

export default function Services() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <Badge
            variant="secondary"
            className="mb-4 bg-hexon-red/10 text-hexon-red border-hexon-red/20"
          >
            Nos Services
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold text-black mb-6 font-roboto-condensed">
            VOTRE PC GAMER, VOTRE <span className="text-hexon-red">FAÇON</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            De l'assemblage sur mesure à la maintenance professionnelle, HEXON
            vous accompagne dans toute votre expérience gaming.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
          {/* PC sur mesure */}
          <Card className="group hover:shadow-2xl transition-all duration-300 border-2 hover:border-hexon-red/30 bg-gradient-to-br from-white to-gray-50">
            <CardHeader className="pb-4">
              <div className="flex items-center space-x-3 mb-4">
                <div className="p-3 bg-hexon-red/10 rounded-xl">
                  <Cpu className="w-8 h-8 text-hexon-red" />
                </div>
                <Badge className="bg-hexon-red text-white">Populaire</Badge>
              </div>
              <CardTitle className="text-2xl font-bold text-black group-hover:text-hexon-red transition-colors">
                PC sur mesure
              </CardTitle>
              <CardDescription className="text-gray-600 text-lg">
                Configuration 100% personnalisée selon vos besoins et votre
                budget
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="flex items-center space-x-3">
                  <Gamepad2 className="w-5 h-5 text-hexon-red flex-shrink-0" />
                  <span className="text-sm text-gray-700">
                    Gaming performant
                  </span>
                </div>
                <div className="flex items-center space-x-3">
                  <Monitor className="w-5 h-5 text-hexon-red flex-shrink-0" />
                  <span className="text-sm text-gray-700">
                    Streaming & création
                  </span>
                </div>
                <div className="flex items-center space-x-3">
                  <Settings className="w-5 h-5 text-hexon-red flex-shrink-0" />
                  <span className="text-sm text-gray-700">
                    Optimisation pro
                  </span>
                </div>
                <div className="flex items-center space-x-3">
                  <Clock className="w-5 h-5 text-hexon-red flex-shrink-0" />
                  <span className="text-sm text-gray-700">Tests complets</span>
                </div>
              </div>

              <div className="bg-hexon-red/5 border border-hexon-red/20 rounded-xl p-4">
                <h4 className="font-semibold text-black mb-2">
                  Processus de création :
                </h4>
                <div className="space-y-2 text-sm text-gray-700">
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-hexon-red rounded-full"></div>
                    <span>
                      Analyse de vos besoins (gaming, streaming, budget)
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-hexon-red rounded-full"></div>
                    <span>Sélection des composants optimaux</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-hexon-red rounded-full"></div>
                    <span>
                      Assemblage professionnel et tests de performance
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-hexon-red rounded-full"></div>
                    <span>Livraison avec guide d'utilisation</span>
                  </div>
                </div>
              </div>

              <Link to="/pc-sur-mesure" className="w-full">
                <Button className="w-full bg-hexon-red hover:bg-hexon-red-dark text-white font-semibold py-3 rounded-xl transition-all duration-200 transform hover:scale-105">
                  Créer ma configuration
                </Button>
              </Link>
            </CardContent>
          </Card>

          {/* Maintenance & Réparation */}
          <Card className="group hover:shadow-2xl transition-all duration-300 border-2 hover:border-hexon-red/30 bg-gradient-to-br from-white to-gray-50">
            <CardHeader className="pb-4">
              <div className="flex items-center space-x-3 mb-4">
                <div className="p-3 bg-blue-100 rounded-xl">
                  <Wrench className="w-8 h-8 text-blue-600" />
                </div>
                <Badge
                  variant="outline"
                  className="border-blue-200 text-blue-600"
                >
                  Service expert
                </Badge>
              </div>
              <CardTitle className="text-2xl font-bold text-black group-hover:text-blue-600 transition-colors">
                Maintenance & Réparation
              </CardTitle>
              <CardDescription className="text-gray-600 text-lg">
                Diagnostic, réparation et maintenance préventive par nos experts
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 gap-4">
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <h4 className="font-semibold text-blue-900 mb-2">
                    Diagnostic gratuit
                  </h4>
                  <p className="text-sm text-blue-700">
                    Analyse complète de votre PC pour identifier les problèmes
                    de performance ou de stabilité.
                  </p>
                </div>

                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <h4 className="font-semibold text-green-900 mb-2">
                    Réparation premium
                  </h4>
                  <p className="text-sm text-green-700">
                    Intervention rapide avec pièces de qualité et garantie sur
                    les réparations.
                  </p>
                </div>

                <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                  <h4 className="font-semibold text-purple-900 mb-2">
                    Maintenance préventive
                  </h4>
                  <p className="text-sm text-purple-700">
                    Nettoyage, optimisation et mise à jour pour maintenir les
                    performances.
                  </p>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-3">
                <Link to="/maintenance" className="flex-1">
                  <Button
                    variant="outline"
                    className="w-full border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white font-semibold py-3 rounded-xl transition-all duration-200"
                  >
                    Demander un diagnostic
                  </Button>
                </Link>
                <Link to="/maintenance" className="flex-1">
                  <Button
                    variant="outline"
                    className="w-full border-gray-300 text-gray-700 hover:bg-gray-100 font-semibold py-3 rounded-xl transition-all duration-200"
                  >
                    Devis réparation
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Bottom CTA Section */}
        <div className="bg-gradient-to-r from-hexon-black to-gray-800 rounded-3xl p-8 lg:p-12 text-center text-white">
          <h3 className="text-3xl md:text-4xl font-bold mb-4 font-roboto-condensed">
            Besoin d'aide pour choisir ?
          </h3>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Nos experts vous conseillent gratuitement pour trouver la
            configuration parfaite selon votre utilisation et votre budget.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
            <Link to="/contact">
              <Button
                size="lg"
                className="bg-hexon-red hover:bg-hexon-red-dark text-white font-semibold px-8 py-3 rounded-xl transition-all duration-200 w-full sm:w-auto"
              >
                Prendre rendez-vous
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
