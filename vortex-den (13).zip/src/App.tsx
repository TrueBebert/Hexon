import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import ScrollToTop from "./components/ScrollToTop";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import PlaceholderPage from "./pages/PlaceholderPage";
import PCGamerPage from "./pages/PCGamerPage";
import PCSurMesurePage from "./pages/PCSurMesurePage";
import MaintenancePage from "./pages/MaintenancePage";
import ContactPage from "./pages/ContactPage";
import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";
import CartPage from "./pages/CartPage";
import CheckoutPage from "./pages/CheckoutPage";
import GarantiePage from "./pages/GarantiePage";
import LivraisonPage from "./pages/LivraisonPage";
import MentionsLegalesPage from "./pages/MentionsLegalesPage";
import CGVPage from "./pages/CGVPage";
import PolitiqueConfidentialitePage from "./pages/PolitiqueConfidentialitePage";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <ScrollToTop />
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/pc-gamer" element={<PCGamerPage />} />
          <Route path="/pc-sur-mesure" element={<PCSurMesurePage />} />
          <Route path="/maintenance" element={<MaintenancePage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route path="/cart" element={<CartPage />} />
          <Route path="/checkout" element={<CheckoutPage />} />
          <Route path="/cgv" element={<CGVPage />} />
          <Route
            path="/politique-confidentialite"
            element={<PolitiqueConfidentialitePage />}
          />
          <Route path="/garantie" element={<GarantiePage />} />
          <Route path="/livraison" element={<LivraisonPage />} />
          <Route path="/mentions-legales" element={<MentionsLegalesPage />} />
          {/* Placeholder routes for future pages */}
          <Route
            path="/forgot-password"
            element={<PlaceholderPage title="Mot de passe oublié" />}
          />
          <Route
            path="/terms"
            element={<PlaceholderPage title="Conditions d'utilisation" />}
          />
          <Route
            path="/privacy"
            element={<PlaceholderPage title="Politique de confidentialité" />}
          />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
