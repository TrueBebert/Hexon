import Header from "../components/Header";
import Footer from "../components/Footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import {
  Truck,
  Package,
  Clock,
  CheckCircle,
  ArrowLeft,
  Euro,
  Calendar,
  MapPin,
  RotateCcw,
  AlertTriangle,
  Mail,
} from "lucide-react";

export default function LivraisonPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <main className="py-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="mb-8">
            <Link
              to="/"
              className="inline-flex items-center text-hexon-red hover:text-hexon-red-dark mb-4"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour à l'accueil
            </Link>
            <Badge
              variant="secondary"
              className="mb-4 bg-hexon-red/10 text-hexon-red border-hexon-red/20"
            >
              Livraison & Retours
            </Badge>
            <h1 className="text-3xl font-bold text-black font-roboto-condensed">
              LIVRAISON ET <span className="text-hexon-red">RETOURS</span>
            </h1>
            <p className="text-gray-600 mt-2">
              Toutes les informations sur nos délais, frais et conditions de
              retour
            </p>
          </div>

          {/* Délais de Livraison */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Clock className="w-5 h-5 mr-2 text-hexon-red" />
                Délais de Livraison
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <h3 className="font-semibold text-blue-800 mb-2">
                    🖥️ PC Pré-configurés
                  </h3>
                  <p className="text-blue-700">
                    <strong>5-7 jours ouvrables</strong>
                    <br />
                    Tests complets inclus avant expédition
                  </p>
                </div>
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <h3 className="font-semibold text-green-800 mb-2">
                    🔧 PC Sur Mesure
                  </h3>
                  <p className="text-green-700">
                    <strong>10-14 jours ouvrables</strong>
                    <br />
                    Assemblage, tests et optimisation personnalisés
                  </p>
                </div>
              </div>
              <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                <h3 className="font-semibold mb-2">
                  📦 Processus de préparation
                </h3>
                <div className="space-y-2 text-sm text-gray-600">
                  <p>
                    • <strong>Assemblage :</strong> 2-3 jours pour PC sur mesure
                  </p>
                  <p>
                    • <strong>Tests complets :</strong> 24h de stress test
                  </p>
                  <p>
                    • <strong>Emballage sécurisé :</strong> Protection maximale
                  </p>
                  <p>
                    • <strong>Expédition :</strong> Via transporteur agréé
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Frais de Livraison */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Euro className="w-5 h-5 mr-2 text-hexon-red" />
                Frais de Livraison
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex justify-center">
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 max-w-md">
                  <h3 className="font-semibold text-blue-800 mb-2 text-center">
                    📦 Frais de Livraison
                  </h3>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-blue-800 mb-2">
                      30€
                    </div>
                    <p className="text-blue-700">
                      Prix unique pour toute commande
                      <br />
                      France métropolitaine
                      <br />
                      Livraison sécurisée incluse
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Zones de Livraison */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <MapPin className="w-5 h-5 mr-2 text-hexon-red" />
                Zones de Livraison
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <span>
                    <strong>France métropolitaine :</strong> Livraison standard
                  </span>
                </div>
                <div className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <span>
                    <strong>Corse :</strong> Délai supplémentaire +2-3 jours
                  </span>
                </div>
                <div className="flex items-center space-x-3">
                  <AlertTriangle className="w-5 h-5 text-orange-500" />
                  <span>
                    <strong>Autres destinations :</strong> Nous contacter
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Suivi de Commande */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Package className="w-5 h-5 mr-2 text-hexon-red" />
                Suivi de votre Commande
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-hexon-red text-white rounded-full flex items-center justify-center font-bold text-sm">
                    1
                  </div>
                  <div>
                    <h4 className="font-semibold">Confirmation de commande</h4>
                    <p className="text-gray-600">
                      Email de confirmation immédiat
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-hexon-red text-white rounded-full flex items-center justify-center font-bold text-sm">
                    2
                  </div>
                  <div>
                    <h4 className="font-semibold">Préparation</h4>
                    <p className="text-gray-600">
                      Assemblage et tests (selon délais)
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-hexon-red text-white rounded-full flex items-center justify-center font-bold text-sm">
                    3
                  </div>
                  <div>
                    <h4 className="font-semibold">Expédition</h4>
                    <p className="text-gray-600">
                      Numéro de suivi envoyé par email
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-hexon-red text-white rounded-full flex items-center justify-center font-bold text-sm">
                    4
                  </div>
                  <div>
                    <h4 className="font-semibold">Livraison</h4>
                    <p className="text-gray-600">Réception à votre domicile</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Politique de Retour */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <RotateCcw className="w-5 h-5 mr-2 text-hexon-red" />
                Politique de Retour
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <h3 className="font-semibold text-blue-800 mb-2">
                    📅 Délai de rétractation : 14 jours
                  </h3>
                  <p className="text-blue-700">
                    Vous avez 14 jours pour retourner votre PC sans
                    justification
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-semibold mb-2">
                      ✅ Conditions acceptées
                    </h4>
                    <ul className="text-gray-600 text-sm space-y-1">
                      <li>• PC dans son emballage d'origine</li>
                      <li>• Tous les accessoires présents</li>
                      <li>• Aucun dommage physique</li>
                      <li>• Facture d'achat obligatoire</li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2">❌ Exclusions</h4>
                    <ul className="text-gray-600 text-sm space-y-1">
                      <li>• PC sur mesure personnalisé</li>
                      <li>• Logiciels installés par le client</li>
                      <li>• Dommages dus au transport retour</li>
                      <li>• Dépassement des 14 jours</li>
                    </ul>
                  </div>
                </div>

                <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                  <h3 className="font-semibold text-orange-800 mb-2">
                    💰 Frais de retour
                  </h3>
                  <p className="text-orange-700">
                    <strong>À votre charge</strong> sauf en cas de défaut ou
                    erreur de notre part
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Contact */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Mail className="w-5 h-5 mr-2 text-hexon-red" />
                Questions sur votre Livraison ?
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center">
                <p className="text-gray-600 mb-4">
                  Notre équipe est là pour vous aider avec toutes vos questions
                  sur la livraison et les retours.
                </p>
                <Link to="/contact">
                  <Button className="bg-hexon-red hover:bg-hexon-red-dark text-white">
                    <Mail className="w-4 h-4 mr-2" />
                    Contactez-nous
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  );
}
