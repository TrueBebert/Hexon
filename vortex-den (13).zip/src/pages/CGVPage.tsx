import Header from "../components/Header";
import Footer from "../components/Footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import {
  FileText,
  ShoppingCart,
  CreditCard,
  Truck,
  RotateCcw,
  Shield,
  ArrowLeft,
  Mail,
  AlertTriangle,
  Clock,
  Euro,
  CheckCircle,
} from "lucide-react";

export default function CGVPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <main className="py-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="mb-8">
            <Link
              to="/"
              className="inline-flex items-center text-hexon-red hover:text-hexon-red-dark mb-4"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour à l'accueil
            </Link>
            <Badge
              variant="secondary"
              className="mb-4 bg-hexon-red/10 text-hexon-red border-hexon-red/20"
            >
              Conditions Générales de Vente
            </Badge>
            <h1 className="text-3xl font-bold text-black font-roboto-condensed">
              CONDITIONS GÉNÉRALES{" "}
              <span className="text-hexon-red">DE VENTE</span>
            </h1>
            <p className="text-gray-600 mt-2">
              Conditions applicables à tous les achats sur HEXON PC
            </p>
            <p className="text-sm text-gray-500 mt-1">
              Dernière mise à jour : {new Date().toLocaleDateString("fr-FR")}
            </p>
          </div>

          {/* Article 1 - Objet */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <FileText className="w-5 h-5 mr-2 text-hexon-red" />
                Article 1 - Objet et Champ d'Application
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">
                Les présentes Conditions Générales de Vente (CGV) régissent
                toutes les relations contractuelles entre :
              </p>
              <div className="space-y-2">
                <p>
                  <strong>HEXON</strong> - Spécialiste en assemblage et vente de
                  PC gaming
                </p>
                <p>
                  Email : <strong>contact@hexonpc.com</strong>
                </p>
                <p>
                  Et toute personne physique ou morale souhaitant effectuer un
                  achat.
                </p>
              </div>
              <p className="text-gray-600 mt-4">
                Toute commande implique l'acceptation pleine et entière des
                présentes CGV.
              </p>
            </CardContent>
          </Card>

          {/* Article 2 - Produits */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <ShoppingCart className="w-5 h-5 mr-2 text-hexon-red" />
                Article 2 - Produits et Services
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">2.1 - Produits proposés</h3>
                <ul className="text-gray-600 space-y-1">
                  <li>• PC gaming pré-configurés</li>
                  <li>• PC gaming sur mesure</li>
                  <li>• Services d'optimisation et extension de garantie</li>
                  <li>• Services de maintenance et réparation</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold mb-2">
                  2.2 - Informations produits
                </h3>
                <p className="text-gray-600">
                  Les descriptions, caractéristiques et prix des produits sont
                  indiqués sur notre site web. HEXON s'efforce de maintenir
                  l'exactitude de ces informations mais se réserve le droit de
                  les modifier sans préavis.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Article 3 - Commandes */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <CheckCircle className="w-5 h-5 mr-2 text-hexon-red" />
                Article 3 - Commandes et Validation
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">
                  3.1 - Processus de commande
                </h3>
                <div className="space-y-2 text-gray-600">
                  <p>1. Sélection des produits et services</p>
                  <p>2. Validation du panier et des informations</p>
                  <p>3. Choix du mode de paiement</p>
                  <p>4. Confirmation de commande par email</p>
                </div>
              </div>
              <div>
                <h3 className="font-semibold mb-2">3.2 - Validation</h3>
                <p className="text-gray-600">
                  La commande n'est définitive qu'après validation du paiement
                  et envoi d'un email de confirmation par HEXON.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">3.3 - Disponibilité</h3>
                <p className="text-gray-600">
                  En cas d'indisponibilité d'un produit, HEXON s'engage à
                  informer le client dans les plus brefs délais et à proposer
                  une alternative ou un remboursement.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Article 4 - Prix */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Euro className="w-5 h-5 mr-2 text-hexon-red" />
                Article 4 - Prix et Modalités de Paiement
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">4.1 - Prix</h3>
                <div className="space-y-2 text-gray-600">
                  <p>• Tous les prix sont indiqués en euros TTC</p>
                  <p>
                    • Frais de livraison : <strong>30€</strong> pour toute
                    commande
                  </p>
                  <p>• Prix valables au moment de la commande</p>
                </div>
              </div>
              <div>
                <h3 className="font-semibold mb-2">4.2 - Modes de paiement</h3>
                <div className="space-y-2 text-gray-600">
                  <p>• Carte bancaire (Visa, Mastercard)</p>
                  <p>• PayPal</p>
                  <p>• Virement SEPA (pour entreprises)</p>
                </div>
              </div>
              <div>
                <h3 className="font-semibold mb-2">4.3 - Sécurisation</h3>
                <p className="text-gray-600">
                  Tous les paiements sont sécurisés par cryptage SSL et
                  protocole 3D Secure.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Article 5 - Livraison */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Truck className="w-5 h-5 mr-2 text-hexon-red" />
                Article 5 - Livraison
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">5.1 - Délais</h3>
                <div className="space-y-2 text-gray-600">
                  <p>
                    • PC pré-configurés : <strong>5-7 jours ouvrables</strong>
                  </p>
                  <p>
                    • PC sur mesure : <strong>10-14 jours ouvrables</strong>
                  </p>
                  <p>• Tests complets inclus avant expédition</p>
                </div>
              </div>
              <div>
                <h3 className="font-semibold mb-2">5.2 - Zone de livraison</h3>
                <p className="text-gray-600">
                  France métropolitaine uniquement. Corse : délai supplémentaire
                  de 2-3 jours.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">5.3 - Réception</h3>
                <p className="text-gray-600">
                  Le client doit vérifier l'état du colis à la réception et
                  signaler tout dommage au transporteur et à HEXON sous 48h.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Article 6 - Droit de rétractation */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <RotateCcw className="w-5 h-5 mr-2 text-hexon-red" />
                Article 6 - Droit de Rétractation
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">6.1 - Délai</h3>
                <p className="text-gray-600">
                  Conformément au Code de la consommation, vous disposez de
                  <strong> 14 jours</strong> pour retourner votre achat sans
                  justification.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">6.2 - Conditions</h3>
                <div className="space-y-2 text-gray-600">
                  <p>• Produit dans son emballage d'origine</p>
                  <p>• Accessoires et documentation complets</p>
                  <p>• Aucun dommage imputable au client</p>
                  <p>• Facture d'achat obligatoire</p>
                </div>
              </div>
              <div>
                <h3 className="font-semibold mb-2">6.3 - Exclusions</h3>
                <div className="space-y-2 text-gray-600">
                  <p>• PC sur mesure avec configuration personnalisée</p>
                  <p>• Produits endommagés par le client</p>
                  <p>• Services déjà effectués (optimisation, maintenance)</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Article 7 - Garanties */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Shield className="w-5 h-5 mr-2 text-hexon-red" />
                Article 7 - Garanties
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">
                  7.1 - Garantie commerciale
                </h3>
                <p className="text-gray-600">
                  HEXON garantit tous ses PC <strong>1 an</strong> pièces et
                  main d'œuvre contre les défauts de fabrication et pannes
                  matérielles.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">
                  7.2 - Extension de garantie
                </h3>
                <p className="text-gray-600">
                  Extension possible à <strong>2 ans</strong> moyennant 50€
                  supplémentaires, à souscrire lors de l'achat ou dans les 30
                  jours suivants.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">7.3 - Exclusions</h3>
                <div className="space-y-2 text-gray-600">
                  <p>• Dommages physiques (chutes, chocs, liquides)</p>
                  <p>• Mauvaise utilisation ou modifications non autorisées</p>
                  <p>• Usure normale des composants</p>
                  <p>• Problèmes logiciels (virus, corruption OS)</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Article 8 - Responsabilité */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <AlertTriangle className="w-5 h-5 mr-2 text-hexon-red" />
                Article 8 - Limitation de Responsabilité
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">8.1 - Force majeure</h3>
                <p className="text-gray-600">
                  HEXON ne saurait être tenu responsable de tout retard ou
                  manquement dû à un cas de force majeure.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">8.2 - Limitation</h3>
                <p className="text-gray-600">
                  La responsabilité de HEXON est limitée au montant de la
                  commande. Sont exclus les dommages indirects et le manque à
                  gagner.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Article 9 - Données personnelles */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Shield className="w-5 h-5 mr-2 text-hexon-red" />
                Article 9 - Protection des Données
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">
                Les données personnelles collectées sont utilisées uniquement
                pour :
              </p>
              <div className="space-y-2 text-gray-600">
                <p>• Le traitement et suivi de votre commande</p>
                <p>• La gestion de la garantie et du SAV</p>
                <p>
                  • L'envoi d'informations sur nos produits (avec consentement)
                </p>
              </div>
              <p className="text-gray-600 mt-4">
                Conformément au RGPD, vous disposez d'un droit d'accès,
                rectification, suppression et opposition. Pour exercer ces
                droits : <strong>contact@hexonpc.com</strong>
              </p>
            </CardContent>
          </Card>

          {/* Article 10 - Litiges */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <FileText className="w-5 h-5 mr-2 text-hexon-red" />
                Article 10 - Litiges et Droit Applicable
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">10.1 - Droit applicable</h3>
                <p className="text-gray-600">
                  Les présentes CGV sont soumises au droit français.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">10.2 - Médiation</h3>
                <p className="text-gray-600">
                  En cas de litige, une solution amiable sera recherchée avant
                  tout recours judiciaire. Les tribunaux français sont
                  compétents.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">10.3 - Contact</h3>
                <p className="text-gray-600">
                  Pour toute réclamation : <strong>contact@hexonpc.com</strong>
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Contact */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Mail className="w-5 h-5 mr-2 text-hexon-red" />
                Questions sur nos CGV ?
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center">
                <p className="text-gray-600 mb-4">
                  Notre équipe est disponible pour répondre à toutes vos
                  questions concernant nos conditions générales de vente.
                </p>
                <Link to="/contact">
                  <Button className="bg-hexon-red hover:bg-hexon-red-dark text-white">
                    <Mail className="w-4 h-4 mr-2" />
                    Nous contacter
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  );
}
