import { useState } from "react";
import Header from "../components/Header";
import Footer from "../components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Separator } from "@/components/ui/separator";
import { Link } from "react-router-dom";
import {
  ArrowLeft,
  CreditCard,
  Shield,
  Truck,
  CheckCircle,
  User,
  MapPin,
  Phone,
  Mail,
} from "lucide-react";

interface OrderData {
  // Personal Info
  firstName: string;
  lastName: string;
  email: string;
  phone: string;

  // Billing Address
  billingAddress: string;
  billingCity: string;
  billingPostal: string;
  billingCountry: string;

  // Shipping Address
  sameAsbilling: boolean;
  shippingAddress: string;
  shippingCity: string;
  shippingPostal: string;
  shippingCountry: string;

  // Payment
  paymentMethod: string;

  // Additional
  notes: string;
}

// Mock cart data (in real app, this would come from context/state)
const mockOrderItems = [
  {
    id: 1,
    name: "HEXON DESTROYER RTX 5070",
    price: 1899,
    quantity: 1,
  },
];

const mockComplementaryItems = [
  {
    id: 1,
    name: "Optimisation du PC",
    price: 50,
    selected: true,
  },
];

export default function CheckoutPage() {
  const [orderData, setOrderData] = useState<OrderData>({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    billingAddress: "",
    billingCity: "",
    billingPostal: "",
    billingCountry: "France",
    sameAsBinding: true,
    shippingAddress: "",
    shippingCity: "",
    shippingPostal: "",
    shippingCountry: "France",
    paymentMethod: "cb",
    notes: "",
  });

  const [isSubmitted, setIsSubmitted] = useState(false);

  const updateOrderData = (field: keyof OrderData, value: string | boolean) => {
    setOrderData((prev) => ({ ...prev, [field]: value }));
  };

  const subtotal = mockOrderItems.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0,
  );
  const complementaryTotal = mockComplementaryItems
    .filter((item) => item.selected)
    .reduce((sum, item) => sum + item.price, 0);
  const shippingCost = 30;
  const total = subtotal + complementaryTotal + shippingCost;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
  };

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <main className="py-20">
          <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <div className="bg-green-50 border-2 border-green-200 rounded-3xl p-12">
              <CheckCircle className="w-20 h-20 text-green-500 mx-auto mb-6" />
              <h1 className="text-3xl font-bold text-black mb-4 font-roboto-condensed">
                Commande confirmée !
              </h1>
              <p className="text-lg text-gray-600 mb-6">
                Merci pour votre commande. Vous recevrez un email de
                confirmation sous peu.
              </p>
              <div className="bg-white rounded-xl p-6 mb-6 text-left">
                <h3 className="font-semibold mb-3">
                  Récapitulatif de votre commande :
                </h3>
                <div className="space-y-2 text-sm text-gray-600">
                  <div className="flex justify-between">
                    <span>Numéro de commande :</span>
                    <span className="font-medium">
                      HXN-{Date.now().toString().slice(-6)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Total :</span>
                    <span className="font-medium text-hexon-red">
                      {total.toLocaleString()}€
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Email de contact :</span>
                    <span className="font-medium">{orderData.email}</span>
                  </div>
                </div>
              </div>
              <div className="space-y-3">
                <Link to="/">
                  <Button className="bg-hexon-red hover:bg-hexon-red-dark text-white font-semibold px-8 py-3 rounded-xl w-full sm:w-auto">
                    Retour à l'accueil
                  </Button>
                </Link>
                <p className="text-sm text-gray-500">
                  Vous recevrez un suivi détaillé par email
                </p>
              </div>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <main className="py-12">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="mb-8">
            <Link
              to="/cart"
              className="inline-flex items-center text-hexon-red hover:text-hexon-red-dark mb-4"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour au panier
            </Link>
            <h1 className="text-3xl font-bold text-black font-roboto-condensed">
              FINALISER LA <span className="text-hexon-red">COMMANDE</span>
            </h1>
            <p className="text-gray-600 mt-2">
              Remplissez vos informations pour confirmer votre commande
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Order Form */}
            <div className="lg:col-span-2">
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Personal Information */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <User className="w-5 h-5 mr-2 text-hexon-red" />
                      Informations personnelles
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="firstName">Prénom *</Label>
                        <Input
                          id="firstName"
                          value={orderData.firstName}
                          onChange={(e) =>
                            updateOrderData("firstName", e.target.value)
                          }
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="lastName">Nom *</Label>
                        <Input
                          id="lastName"
                          value={orderData.lastName}
                          onChange={(e) =>
                            updateOrderData("lastName", e.target.value)
                          }
                          required
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="email">Email *</Label>
                        <Input
                          id="email"
                          type="email"
                          value={orderData.email}
                          onChange={(e) =>
                            updateOrderData("email", e.target.value)
                          }
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="phone">Téléphone *</Label>
                        <Input
                          id="phone"
                          type="tel"
                          value={orderData.phone}
                          onChange={(e) =>
                            updateOrderData("phone", e.target.value)
                          }
                          required
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Billing Address */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <MapPin className="w-5 h-5 mr-2 text-hexon-red" />
                      Adresse de facturation
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label htmlFor="billingAddress">Adresse *</Label>
                      <Input
                        id="billingAddress"
                        value={orderData.billingAddress}
                        onChange={(e) =>
                          updateOrderData("billingAddress", e.target.value)
                        }
                        placeholder="123 Rue de la Paix"
                        required
                      />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <Label htmlFor="billingCity">Ville *</Label>
                        <Input
                          id="billingCity"
                          value={orderData.billingCity}
                          onChange={(e) =>
                            updateOrderData("billingCity", e.target.value)
                          }
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="billingPostal">Code postal *</Label>
                        <Input
                          id="billingPostal"
                          value={orderData.billingPostal}
                          onChange={(e) =>
                            updateOrderData("billingPostal", e.target.value)
                          }
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="billingCountry">Pays *</Label>
                        <Input
                          id="billingCountry"
                          value={orderData.billingCountry}
                          onChange={(e) =>
                            updateOrderData("billingCountry", e.target.value)
                          }
                          required
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Payment Method */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <CreditCard className="w-5 h-5 mr-2 text-hexon-red" />
                      Mode de paiement
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <RadioGroup
                      value={orderData.paymentMethod}
                      onValueChange={(value) =>
                        updateOrderData("paymentMethod", value)
                      }
                    >
                      <div className="flex items-center space-x-2 p-4 border rounded-lg">
                        <RadioGroupItem value="cb" id="cb" />
                        <Label htmlFor="cb" className="cursor-pointer flex-1">
                          <div className="flex items-center justify-between">
                            <div>
                              <div className="font-medium">Carte bancaire</div>
                              <div className="text-sm text-gray-500">
                                Paiement sécurisé 3D Secure
                              </div>
                            </div>
                            <CreditCard className="w-5 h-5 text-gray-400" />
                          </div>
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2 p-4 border rounded-lg">
                        <RadioGroupItem value="paypal" id="paypal" />
                        <Label
                          htmlFor="paypal"
                          className="cursor-pointer flex-1"
                        >
                          <div className="flex items-center justify-between">
                            <div>
                              <div className="font-medium">PayPal</div>
                              <div className="text-sm text-gray-500">
                                Paiement rapide et sécurisé
                              </div>
                            </div>
                            <div className="text-blue-600 font-bold">
                              PayPal
                            </div>
                          </div>
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2 p-4 border rounded-lg">
                        <RadioGroupItem value="virement" id="virement" />
                        <Label
                          htmlFor="virement"
                          className="cursor-pointer flex-1"
                        >
                          <div className="flex items-center justify-between">
                            <div>
                              <div className="font-medium">Virement SEPA</div>
                              <div className="text-sm text-gray-500">
                                Pour entreprises et commandes importantes
                              </div>
                            </div>
                            <Truck className="w-5 h-5 text-gray-400" />
                          </div>
                        </Label>
                      </div>
                    </RadioGroup>
                  </CardContent>
                </Card>

                {/* Additional Notes */}
                <Card>
                  <CardHeader>
                    <CardTitle>Notes additionnelles (optionnel)</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Textarea
                      value={orderData.notes}
                      onChange={(e) => updateOrderData("notes", e.target.value)}
                      placeholder="Instructions de livraison, commentaires..."
                      rows={3}
                    />
                  </CardContent>
                </Card>
              </form>
            </div>

            {/* Order Summary */}
            <div className="lg:col-span-1">
              <Card className="border-2 border-hexon-red shadow-lg sticky top-8">
                <CardHeader className="bg-hexon-red text-white">
                  <CardTitle className="font-roboto-condensed text-white">
                    RÉCAPITULATIF
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6 space-y-4">
                  {/* Items */}
                  <div className="space-y-3">
                    <h4 className="font-semibold text-black">Articles :</h4>
                    {mockOrderItems.map((item) => (
                      <div
                        key={item.id}
                        className="flex justify-between text-sm"
                      >
                        <span className="text-gray-600">
                          {item.name} x{item.quantity}
                        </span>
                        <span className="font-medium">
                          {(item.price * item.quantity).toLocaleString()}€
                        </span>
                      </div>
                    ))}
                  </div>

                  {/* Complementary */}
                  {mockComplementaryItems.filter((item) => item.selected)
                    .length > 0 && (
                    <>
                      <Separator />
                      <div className="space-y-3">
                        <h4 className="font-semibold text-black">Services :</h4>
                        {mockComplementaryItems
                          .filter((item) => item.selected)
                          .map((item) => (
                            <div
                              key={item.id}
                              className="flex justify-between text-sm"
                            >
                              <span className="text-gray-600">{item.name}</span>
                              <span className="font-medium">{item.price}€</span>
                            </div>
                          ))}
                      </div>
                    </>
                  )}

                  <Separator />

                  {/* Totals */}
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Sous-total :</span>
                      <span>{subtotal.toLocaleString()}€</span>
                    </div>
                    {complementaryTotal > 0 && (
                      <div className="flex justify-between text-sm">
                        <span>Services :</span>
                        <span>{complementaryTotal.toLocaleString()}€</span>
                      </div>
                    )}
                    <div className="flex justify-between text-sm">
                      <span>Livraison :</span>
                      <span>{shippingCost}€</span>
                    </div>
                  </div>

                  <Separator />

                  <div className="flex justify-between text-lg font-bold">
                    <span>Total :</span>
                    <span className="text-hexon-red">
                      {total.toLocaleString()}€
                    </span>
                  </div>

                  {/* Security badges */}
                  <div className="space-y-3 pt-4 border-t">
                    <div className="flex items-center space-x-3 text-sm">
                      <Shield className="w-5 h-5 text-green-600" />
                      <span className="text-gray-600">
                        Paiement sécurisé SSL
                      </span>
                    </div>
                    <div className="flex items-center space-x-3 text-sm">
                      <Truck className="w-5 h-5 text-blue-600" />
                      <span className="text-gray-600">Assemblage premium</span>
                    </div>
                  </div>

                  {/* Submit Button */}
                  <Button
                    onClick={handleSubmit}
                    className="w-full bg-hexon-red hover:bg-hexon-red-dark text-white font-semibold py-3 rounded-xl transition-all duration-200 transform hover:scale-105 mt-6"
                  >
                    Confirmer la commande
                  </Button>

                  <p className="text-xs text-gray-500 text-center mt-2">
                    En confirmant, vous acceptez nos conditions de vente
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
