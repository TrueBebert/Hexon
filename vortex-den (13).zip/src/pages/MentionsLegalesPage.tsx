import Header from "../components/Header";
import Footer from "../components/Footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import {
  Building,
  User,
  Globe,
  Shield,
  ArrowLeft,
  Mail,
  FileText,
  Server,
  Eye,
  Lock,
} from "lucide-react";

export default function MentionsLegalesPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <main className="py-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="mb-8">
            <Link
              to="/"
              className="inline-flex items-center text-hexon-red hover:text-hexon-red-dark mb-4"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour à l'accueil
            </Link>
            <Badge
              variant="secondary"
              className="mb-4 bg-hexon-red/10 text-hexon-red border-hexon-red/20"
            >
              Mentions Légales
            </Badge>
            <h1 className="text-3xl font-bold text-black font-roboto-condensed">
              MENTIONS <span className="text-hexon-red">LÉGALES</span>
            </h1>
            <p className="text-gray-600 mt-2">
              Informations légales et réglementaires du site HEXON
            </p>
          </div>

          {/* Éditeur du site */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Building className="w-5 h-5 mr-2 text-hexon-red" />
                Éditeur du Site
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">Dénomination sociale</h3>
                <p className="text-gray-600">
                  <strong>HEXON</strong> - Spécialiste PC Gaming
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Contact</h3>
                <p className="text-gray-600">
                  Email : <strong>contact@hexonpc.com</strong>
                  <br />
                  Site web :{" "}
                  <strong>
                    <a
                      href="https://hexonpc.com"
                      className="text-hexon-red hover:underline"
                    >
                      https://hexonpc.com
                    </a>
                  </strong>
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Activité</h3>
                <p className="text-gray-600">
                  Assemblage, vente et maintenance de PC gaming sur mesure
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Directeur de publication */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <User className="w-5 h-5 mr-2 text-hexon-red" />
                Directeur de Publication
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Le directeur de la publication est le représentant légal de la
                société HEXON.
                <br />
                Contact : <strong>contact@hexonpc.com</strong>
              </p>
            </CardContent>
          </Card>

          {/* Hébergement */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Server className="w-5 h-5 mr-2 text-hexon-red" />
                Hébergement du Site
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Ce site est hébergé par un prestataire d'hébergement web
                professionnel.
                <br />
                Pour toute question relative à l'hébergement, contactez-nous à{" "}
                <strong>contact@hexonpc.com</strong>
              </p>
            </CardContent>
          </Card>

          {/* Propriété intellectuelle */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <FileText className="w-5 h-5 mr-2 text-hexon-red" />
                Propriété Intellectuelle
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">Contenu du site</h3>
                <p className="text-gray-600">
                  L'ensemble du contenu de ce site (textes, images, logos,
                  design) est la propriété exclusive de HEXON ou fait l'objet
                  d'une autorisation d'utilisation.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Reproduction interdite</h3>
                <p className="text-gray-600">
                  Toute reproduction, totale ou partielle, du contenu de ce site
                  est strictement interdite sans autorisation préalable écrite
                  de HEXON.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Marques et logos</h3>
                <p className="text-gray-600">
                  Les marques et logos présents sur ce site sont déposés par
                  HEXON ou leurs propriétaires respectifs. Toute utilisation non
                  autorisée est interdite.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Protection des données */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Lock className="w-5 h-5 mr-2 text-hexon-red" />
                Protection des Données Personnelles
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">Collecte de données</h3>
                <p className="text-gray-600">
                  Les données personnelles collectées via nos formulaires
                  (contact, devis) sont uniquement utilisées pour traiter vos
                  demandes et vous fournir nos services.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Vos droits</h3>
                <p className="text-gray-600">
                  Conformément au RGPD, vous disposez d'un droit d'accès, de
                  rectification, de suppression et d'opposition concernant vos
                  données personnelles.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Contact données</h3>
                <p className="text-gray-600">
                  Pour exercer vos droits, contactez-nous à{" "}
                  <strong>contact@hexonpc.com</strong>
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Cookies */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Eye className="w-5 h-5 mr-2 text-hexon-red" />
                Cookies et Traceurs
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">Utilisation des cookies</h3>
                <p className="text-gray-600">
                  Ce site utilise des cookies techniques nécessaires à son bon
                  fonctionnement (navigation, sécurité, préférences).
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Gestion des cookies</h3>
                <p className="text-gray-600">
                  Vous pouvez configurer votre navigateur pour refuser les
                  cookies, mais cela peut affecter le fonctionnement du site.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Responsabilité */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Shield className="w-5 h-5 mr-2 text-hexon-red" />
                Limitation de Responsabilité
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">Contenu du site</h3>
                <p className="text-gray-600">
                  HEXON s'efforce de maintenir l'exactitude des informations
                  présentes sur ce site, mais ne peut garantir leur
                  exhaustivité, précision ou actualité.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Liens externes</h3>
                <p className="text-gray-600">
                  Les liens vers des sites externes sont fournis à titre
                  informatif. HEXON n'est pas responsable du contenu de ces
                  sites tiers.
                </p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Disponibilité</h3>
                <p className="text-gray-600">
                  HEXON ne peut garantir l'accès permanent au site et ne sera
                  pas responsable des interruptions temporaires.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Droit applicable */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Globe className="w-5 h-5 mr-2 text-hexon-red" />
                Droit Applicable
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Les présentes mentions légales sont soumises au droit français.
                En cas de litige, les tribunaux français seront seuls
                compétents.
              </p>
            </CardContent>
          </Card>

          {/* Contact */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Mail className="w-5 h-5 mr-2 text-hexon-red" />
                Contact
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center">
                <p className="text-gray-600 mb-4">
                  Pour toute question concernant ces mentions légales ou nos
                  pratiques, n'hésitez pas à nous contacter.
                </p>
                <div className="space-y-2">
                  <p>
                    <strong>Email :</strong> contact@hexonpc.com
                  </p>
                  <p className="text-sm text-gray-500">
                    Dernière mise à jour :{" "}
                    {new Date().toLocaleDateString("fr-FR")}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  );
}
