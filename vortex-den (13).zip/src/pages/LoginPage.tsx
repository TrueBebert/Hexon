import { useState } from "react";
import Header from "../components/Header";
import Footer from "../components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Link } from "react-router-dom";
import {
  Eye,
  EyeOff,
  Mail,
  Lock,
  LogIn,
  User,
  ShieldCheck,
  ArrowLeft,
} from "lucide-react";

interface LoginFormData {
  email: string;
  password: string;
  rememberMe: boolean;
}

export default function LoginPage() {
  const [formData, setFormData] = useState<LoginFormData>({
    email: "",
    password: "",
    rememberMe: false,
  });

  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  const updateFormData = (field: keyof LoginFormData, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (error) setError(""); // Clear error when user starts typing
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError("");

    // Simulate API call
    try {
      await new Promise((resolve) => setTimeout(resolve, 1000));

      // For demo purposes, check for a demo account
      if (
        formData.email === "demo@hexon.fr" &&
        formData.password === "demo123"
      ) {
        console.log("Login successful:", formData);
        // Here you would typically redirect to dashboard or previous page
        alert("Connexion réussie ! Redirection...");
      } else {
        setError("Email ou mot de passe incorrect");
      }
    } catch (err) {
      setError("Une erreur est survenue, veuillez réessayer");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <Header />

      <main className="py-8">
        <div className="max-w-md mx-auto px-4 sm:px-6 lg:px-8">
          {/* Back Link */}
          <div className="mb-6">
            <Link
              to="/"
              className="inline-flex items-center text-sm text-gray-600 hover:text-hexon-red transition-colors"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour à l'accueil
            </Link>
          </div>

          {/* Page Header */}
          <div className="text-center mb-8">
            <Badge
              variant="secondary"
              className="mb-4 bg-hexon-red/10 text-hexon-red border-hexon-red/20"
            >
              Connexion
            </Badge>
            <h1 className="text-3xl md:text-4xl font-bold text-black mb-4 font-roboto-condensed">
              BON RETOUR SUR <span className="text-hexon-red">HEXON</span>
            </h1>
            <p className="text-gray-600">
              Connectez-vous à votre compte pour accéder à vos commandes et
              préférences
            </p>
          </div>

          {/* Login Form */}
          <Card className="border-2 border-hexon-red/20">
            <CardHeader className="bg-hexon-red/5 text-center">
              <CardTitle className="text-xl font-bold text-black font-roboto-condensed flex items-center justify-center">
                <LogIn className="w-5 h-5 mr-2 text-hexon-red" />
                SE CONNECTER
              </CardTitle>
            </CardHeader>
            <CardContent className="p-8">
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Error Message */}
                {error && (
                  <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-700 text-sm">
                    {error}
                  </div>
                )}

                {/* Email */}
                <div>
                  <Label htmlFor="email" className="font-medium mb-2 block">
                    Adresse email *
                  </Label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Mail className="h-5 w-5 text-gray-400" />
                    </div>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => updateFormData("email", e.target.value)}
                      placeholder="votre@email.com"
                      className="pl-10"
                      required
                    />
                  </div>
                </div>

                {/* Password */}
                <div>
                  <Label htmlFor="password" className="font-medium mb-2 block">
                    Mot de passe *
                  </Label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Lock className="h-5 w-5 text-gray-400" />
                    </div>
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      value={formData.password}
                      onChange={(e) =>
                        updateFormData("password", e.target.value)
                      }
                      placeholder="Votre mot de passe"
                      className="pl-10 pr-10"
                      required
                    />
                    <button
                      type="button"
                      className="absolute inset-y-0 right-0 pr-3 flex items-center"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? (
                        <EyeOff className="h-5 w-5 text-gray-400 hover:text-gray-600" />
                      ) : (
                        <Eye className="h-5 w-5 text-gray-400 hover:text-gray-600" />
                      )}
                    </button>
                  </div>
                </div>

                {/* Remember Me & Forgot Password */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="rememberMe"
                      checked={formData.rememberMe}
                      onCheckedChange={(checked) =>
                        updateFormData("rememberMe", checked)
                      }
                    />
                    <Label
                      htmlFor="rememberMe"
                      className="text-sm cursor-pointer"
                    >
                      Se souvenir de moi
                    </Label>
                  </div>
                  <Link
                    to="/forgot-password"
                    className="text-sm text-hexon-red hover:text-hexon-red-dark transition-colors"
                  >
                    Mot de passe oublié ?
                  </Link>
                </div>

                {/* Demo Account Info */}
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-sm">
                  <p className="text-blue-800 font-medium mb-1">
                    💡 Compte de démonstration
                  </p>
                  <p className="text-blue-700">
                    Email : <code>demo@hexon.fr</code>
                  </p>
                  <p className="text-blue-700">
                    Mot de passe : <code>demo123</code>
                  </p>
                </div>

                {/* Submit Button */}
                <Button
                  type="submit"
                  disabled={isLoading}
                  className="w-full bg-hexon-red hover:bg-hexon-red-dark text-white font-semibold py-3 rounded-xl transition-all duration-200 transform hover:scale-105 disabled:transform-none disabled:opacity-50"
                >
                  {isLoading ? (
                    <div className="flex items-center justify-center">
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Connexion...
                    </div>
                  ) : (
                    <div className="flex items-center justify-center">
                      <LogIn className="w-4 h-4 mr-2" />
                      Se connecter
                    </div>
                  )}
                </Button>
              </form>

              {/* Register Link */}
              <div className="mt-6 text-center">
                <p className="text-gray-600">
                  Pas encore de compte ?{" "}
                  <Link
                    to="/register"
                    className="text-hexon-red hover:text-hexon-red-dark font-medium transition-colors"
                  >
                    Créer un compte
                  </Link>
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Benefits Section */}
          <div className="mt-8 bg-hexon-gray-light rounded-2xl p-6">
            <h3 className="font-bold text-black mb-4 text-center font-roboto-condensed">
              AVANTAGES COMPTE <span className="text-hexon-red">HEXON</span>
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
              <div className="flex items-center space-x-2">
                <ShieldCheck className="w-4 h-4 text-hexon-red flex-shrink-0" />
                <span className="text-gray-700">Suivi de vos commandes</span>
              </div>
              <div className="flex items-center space-x-2">
                <User className="w-4 h-4 text-hexon-red flex-shrink-0" />
                <span className="text-gray-700">Historique d'achat</span>
              </div>
              <div className="flex items-center space-x-2">
                <Mail className="w-4 h-4 text-hexon-red flex-shrink-0" />
                <span className="text-gray-700">Offres exclusives</span>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
