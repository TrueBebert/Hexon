import Header from "../components/Header";
import Footer from "../components/Footer";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Construction } from "lucide-react";
import { Link } from "react-router-dom";

interface PlaceholderPageProps {
  title: string;
}

export default function PlaceholderPage({ title }: PlaceholderPageProps) {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="bg-hexon-gray-light rounded-3xl p-12 lg:p-20">
            <div className="w-20 h-20 bg-hexon-red/10 rounded-full flex items-center justify-center mx-auto mb-8">
              <Construction className="w-10 h-10 text-hexon-red" />
            </div>

            <h1 className="text-4xl md:text-5xl font-bold text-black mb-6 font-roboto-condensed">
              {title}
            </h1>

            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
              Cette page est en cours de développement. Nous travaillons dur
              pour vous offrir une expérience exceptionnelle très prochainement
              !
            </p>

            <div className="space-y-4">
              <p className="text-gray-500">
                En attendant, découvrez nos services sur la page d'accueil ou
                contactez-nous directement.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 justify-center pt-6">
                <Link to="/">
                  <Button className="bg-hexon-red hover:bg-hexon-red-dark text-white font-semibold px-8 py-3 rounded-xl transition-all duration-200">
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Retour à l'accueil
                  </Button>
                </Link>

                <Button
                  variant="outline"
                  className="border-hexon-red text-hexon-red hover:bg-hexon-red hover:text-white font-semibold px-8 py-3 rounded-xl transition-all duration-200"
                >
                  Nous contacter
                </Button>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
