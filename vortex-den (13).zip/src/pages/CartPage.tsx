import { useState } from "react";
import Header from "../components/Header";
import Footer from "../components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Link } from "react-router-dom";
import {
  ShoppingCart,
  Plus,
  Minus,
  Trash2,
  ArrowLeft,
  Gift,
  Truck,
  Shield,
  CreditCard,
  Tag,
  ArrowRight,
  AlertCircle,
} from "lucide-react";

interface CartItem {
  id: number;
  name: string;
  category: string;
  price: number;
  originalPrice?: number;
  quantity: number;
  image: string;
  specs: string[];
  inStock: boolean;
  maxQuantity: number;
}

interface PromoCode {
  code: string;
  discount: number;
  type: "percentage" | "fixed";
}

interface ComplementaryProduct {
  id: number;
  name: string;
  description: string;
  price: number;
  icon: React.ComponentType<any>;
  added: boolean;
}

const mockCartItems: CartItem[] = [
  {
    id: 1,
    name: "HEXON DESTROYER RTX 5070",
    category: "PC Gamer Premium",
    price: 1899,
    originalPrice: 1999,
    quantity: 1,
    image: "/api/placeholder/150/150",
    specs: ["Intel Core i7-14700F", "NVIDIA RTX 5070 16GB", "32GB DDR5"],
    inStock: true,
    maxQuantity: 5,
  },

  {
    id: 3,
    name: "HEXON FURY RTX 5060",
    category: "PC Gamer Entrée",
    price: 1299,
    originalPrice: 1399,
    quantity: 1,
    image: "/api/placeholder/150/150",
    specs: ["Intel Core i5-14400F", "NVIDIA RTX 5060 16GB", "16GB DDR5"],
    inStock: false,
    maxQuantity: 3,
  },
];

const validPromoCodes: PromoCode[] = [
  { code: "HEXON10", discount: 10, type: "percentage" },
  { code: "WELCOME50", discount: 50, type: "fixed" },
  { code: "GAMER20", discount: 20, type: "percentage" },
];

const complementaryProducts: ComplementaryProduct[] = [
  {
    id: 1,
    name: "Optimisation du PC",
    description: "Configuration système et optimisation des performances",
    price: 50,
    icon: Shield,
    added: false,
  },
  {
    id: 2,
    name: "Extension de garantie",
    description: "Étendez votre garantie de 1 an à 2 ans",
    price: 40,
    icon: Shield,
    added: false,
  },
];

export default function CartPage() {
  const [cartItems, setCartItems] = useState<CartItem[]>(mockCartItems);
  const [promoCode, setPromoCode] = useState("");
  const [appliedPromo, setAppliedPromo] = useState<PromoCode | null>(null);
  const [promoError, setPromoError] = useState("");
  const [complementaryItems, setComplementaryItems] = useState<
    ComplementaryProduct[]
  >(complementaryProducts);

  const updateQuantity = (id: number, newQuantity: number) => {
    if (newQuantity < 1) return;

    setCartItems((items) =>
      items.map((item) => {
        if (item.id === id) {
          const quantity = Math.min(newQuantity, item.maxQuantity);
          return { ...item, quantity };
        }
        return item;
      }),
    );
  };

  const removeItem = (id: number) => {
    setCartItems((items) => items.filter((item) => item.id !== id));
  };

  const applyPromoCode = () => {
    const promo = validPromoCodes.find(
      (p) => p.code.toLowerCase() === promoCode.toLowerCase(),
    );

    if (promo) {
      setAppliedPromo(promo);
      setPromoError("");
      setPromoCode("");
    } else {
      setPromoError("Code promo invalide");
      setAppliedPromo(null);
    }
  };

  const removePromoCode = () => {
    setAppliedPromo(null);
    setPromoCode("");
    setPromoError("");
  };

  const toggleComplementaryProduct = (id: number) => {
    setComplementaryItems((items) =>
      items.map((item) =>
        item.id === id ? { ...item, added: !item.added } : item,
      ),
    );
  };

  const subtotal = cartItems.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0,
  );
  const complementaryTotal = complementaryItems
    .filter((item) => item.added)
    .reduce((sum, item) => sum + item.price, 0);
  const promoDiscount = appliedPromo
    ? appliedPromo.type === "percentage"
      ? (subtotal + complementaryTotal) * (appliedPromo.discount / 100)
      : appliedPromo.discount
    : 0;
  const shippingCost = 30;
  const total = subtotal + complementaryTotal - promoDiscount + shippingCost;

  const inStockItems = cartItems.filter((item) => item.inStock);
  const outOfStockItems = cartItems.filter((item) => !item.inStock);

  if (cartItems.length === 0) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <main className="py-20">
          <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <div className="bg-hexon-gray-light rounded-3xl p-12">
              <ShoppingCart className="w-20 h-20 text-gray-400 mx-auto mb-6" />
              <h1 className="text-3xl font-bold text-black mb-4 font-roboto-condensed">
                Votre panier est vide
              </h1>
              <p className="text-lg text-gray-600 mb-8">
                Découvrez nos PC gaming haute performance et ajoutez vos
                produits préférés !
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link to="/pc-gamer">
                  <Button className="bg-hexon-red hover:bg-hexon-red-dark text-white font-semibold px-8 py-3 rounded-xl w-full sm:w-auto">
                    Voir nos PC Gamers
                  </Button>
                </Link>
                <Link to="/pc-sur-mesure">
                  <Button
                    variant="outline"
                    className="border-hexon-red text-hexon-red hover:bg-hexon-red hover:text-white font-semibold px-8 py-3 rounded-xl w-full sm:w-auto"
                  >
                    PC sur mesure
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <Header />

      <main className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Back Link */}
          <div className="mb-6">
            <Link
              to="/pc-gamer"
              className="inline-flex items-center text-sm text-gray-600 hover:text-hexon-red transition-colors"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Continuer mes achats
            </Link>
          </div>

          {/* Page Header */}
          <div className="mb-8">
            <h1 className="text-3xl md:text-4xl font-bold text-black mb-2 font-roboto-condensed">
              MON <span className="text-hexon-red">PANIER</span>
            </h1>
            <p className="text-gray-600">
              {cartItems.length} article{cartItems.length > 1 ? "s" : ""} dans
              votre panier
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Cart Items */}
            <div className="lg:col-span-2">
              <Card className="border border-gray-200">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <ShoppingCart className="w-5 h-5 mr-2 text-hexon-red" />
                    Articles sélectionnés
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  {/* In Stock Items */}
                  {inStockItems.length > 0 && (
                    <div>
                      {inStockItems.map((item, index) => (
                        <div key={item.id}>
                          <div className="p-6">
                            <div className="flex flex-col md:flex-row gap-4">
                              {/* Product Image */}
                              <div className="w-full md:w-32 h-32 bg-gradient-to-br from-gray-800 via-black to-gray-900 rounded-lg flex items-center justify-center relative overflow-hidden">
                                <div className="bg-black rounded-lg p-3 border border-hexon-red/30">
                                  <div className="space-y-1">
                                    <div className="flex items-center justify-between">
                                      <div className="w-2 h-2 bg-hexon-red rounded-full animate-pulse"></div>
                                      <div className="text-xs text-gray-400 font-mono">
                                        HEXON
                                      </div>
                                    </div>
                                    <div className="space-y-1">
                                      <div className="h-1 bg-gradient-to-r from-hexon-red to-red-400 rounded-full"></div>
                                      <div className="h-1 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full w-3/4"></div>
                                      <div className="h-1 bg-gradient-to-r from-green-500 to-teal-500 rounded-full w-1/2"></div>
                                    </div>
                                  </div>
                                </div>
                              </div>

                              {/* Product Details */}
                              <div className="flex-1">
                                <div className="flex flex-col md:flex-row justify-between">
                                  <div className="flex-1 mb-4 md:mb-0">
                                    <h3 className="text-lg font-bold text-black mb-1">
                                      {item.name}
                                    </h3>
                                    <p className="text-sm text-gray-500 mb-2">
                                      {item.category}
                                    </p>
                                    <div className="space-y-1">
                                      {item.specs.map((spec, i) => (
                                        <p
                                          key={i}
                                          className="text-xs text-gray-600"
                                        >
                                          • {spec}
                                        </p>
                                      ))}
                                    </div>
                                  </div>

                                  {/* Price and Actions */}
                                  <div className="flex flex-col items-end">
                                    <div className="text-right mb-3">
                                      <div className="flex items-center space-x-2">
                                        <span className="text-lg font-bold text-hexon-red">
                                          {item.price.toLocaleString()}€
                                        </span>
                                        {item.originalPrice && (
                                          <span className="text-sm text-gray-400 line-through">
                                            {item.originalPrice.toLocaleString()}
                                            €
                                          </span>
                                        )}
                                      </div>
                                      <p className="text-xs text-gray-500">
                                        Total:{" "}
                                        {(
                                          item.price * item.quantity
                                        ).toLocaleString()}
                                        €
                                      </p>
                                    </div>

                                    {/* Quantity Controls */}
                                    <div className="flex items-center space-x-2 mb-3">
                                      <Button
                                        variant="outline"
                                        size="sm"
                                        onClick={() =>
                                          updateQuantity(
                                            item.id,
                                            item.quantity - 1,
                                          )
                                        }
                                        disabled={item.quantity <= 1}
                                        className="w-8 h-8 p-0"
                                      >
                                        <Minus className="w-3 h-3" />
                                      </Button>
                                      <span className="w-8 text-center font-medium">
                                        {item.quantity}
                                      </span>
                                      <Button
                                        variant="outline"
                                        size="sm"
                                        onClick={() =>
                                          updateQuantity(
                                            item.id,
                                            item.quantity + 1,
                                          )
                                        }
                                        disabled={
                                          item.quantity >= item.maxQuantity
                                        }
                                        className="w-8 h-8 p-0"
                                      >
                                        <Plus className="w-3 h-3" />
                                      </Button>
                                    </div>

                                    {/* Remove Button */}
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      onClick={() => removeItem(item.id)}
                                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                                    >
                                      <Trash2 className="w-4 h-4 mr-1" />
                                      Supprimer
                                    </Button>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          {index < inStockItems.length - 1 && <Separator />}
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Out of Stock Items */}
                  {outOfStockItems.length > 0 && (
                    <>
                      {inStockItems.length > 0 && <Separator />}
                      <div className="p-6 bg-gray-50">
                        <div className="flex items-center mb-4">
                          <AlertCircle className="w-5 h-5 text-orange-500 mr-2" />
                          <h3 className="font-semibold text-gray-900">
                            Articles indisponibles
                          </h3>
                        </div>
                        {outOfStockItems.map((item, index) => (
                          <div key={item.id} className="opacity-60">
                            <div className="flex flex-col md:flex-row gap-4">
                              <div className="w-full md:w-32 h-32 bg-gray-300 rounded-lg flex items-center justify-center">
                                <span className="text-gray-500 text-sm">
                                  Indisponible
                                </span>
                              </div>
                              <div className="flex-1">
                                <div className="flex justify-between">
                                  <div>
                                    <h3 className="text-lg font-bold text-gray-600 mb-1">
                                      {item.name}
                                    </h3>
                                    <p className="text-sm text-gray-400 mb-2">
                                      {item.category}
                                    </p>
                                    <Badge
                                      variant="destructive"
                                      className="mb-2"
                                    >
                                      Rupture de stock
                                    </Badge>
                                  </div>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => removeItem(item.id)}
                                    className="text-red-600 hover:text-red-700"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </Button>
                                </div>
                              </div>
                            </div>
                            {index < outOfStockItems.length - 1 && (
                              <div className="my-4 border-t border-gray-200" />
                            )}
                          </div>
                        ))}
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>

              {/* Promo Code */}
              <Card className="mt-6 border border-gray-200">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Tag className="w-5 h-5 mr-2 text-hexon-red" />
                    Code promo
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {appliedPromo ? (
                    <div className="flex items-center justify-between p-4 bg-green-50 border border-green-200 rounded-lg">
                      <div>
                        <p className="font-medium text-green-800">
                          Code "{appliedPromo.code}" appliqué
                        </p>
                        <p className="text-sm text-green-600">
                          Réduction:{" "}
                          {appliedPromo.type === "percentage"
                            ? `${appliedPromo.discount}%`
                            : `${appliedPromo.discount}€`}
                        </p>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={removePromoCode}
                        className="text-green-700 hover:text-green-800"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div className="flex gap-2">
                        <Input
                          placeholder="Code promo"
                          value={promoCode}
                          onChange={(e) => {
                            setPromoCode(e.target.value);
                            setPromoError("");
                          }}
                          className="flex-1"
                        />
                        <Button
                          onClick={applyPromoCode}
                          disabled={!promoCode.trim()}
                          className="bg-hexon-red hover:bg-hexon-red-dark text-white"
                        >
                          Appliquer
                        </Button>
                      </div>
                      {promoError && (
                        <p className="text-sm text-red-600">{promoError}</p>
                      )}
                      <div className="text-xs text-gray-500">
                        <p className="font-medium mb-1">
                          Codes de démonstration:
                        </p>
                        <p>• HEXON10 (10% de réduction)</p>
                        <p>• WELCOME50 (50€ de réduction)</p>
                        <p>• GAMER20 (20% de réduction)</p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Complementary Products */}
              <Card className="mt-6 border border-gray-200">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Plus className="w-5 h-5 mr-2 text-hexon-red" />
                    Produits complémentaires
                  </CardTitle>
                  <p className="text-sm text-gray-600 mt-1">
                    Améliorez votre expérience avec nos services additionnels
                  </p>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {complementaryItems.map((product) => (
                      <div
                        key={product.id}
                        className={`p-4 rounded-lg border-2 transition-all duration-200 ${
                          product.added
                            ? "border-hexon-red bg-red-50"
                            : "border-gray-200 hover:border-gray-300"
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-start space-x-3">
                            <product.icon
                              className={`w-6 h-6 mt-1 ${
                                product.added
                                  ? "text-hexon-red"
                                  : "text-gray-500"
                              }`}
                            />
                            <div className="flex-1">
                              <h4 className="font-semibold text-black">
                                {product.name}
                              </h4>
                              <p className="text-sm text-gray-600 mt-1">
                                {product.description}
                              </p>
                              <div className="flex items-center justify-between mt-2">
                                <span className="font-bold text-hexon-red text-lg">
                                  {product.price}€
                                </span>
                                <Button
                                  size="sm"
                                  onClick={() =>
                                    toggleComplementaryProduct(product.id)
                                  }
                                  className={
                                    product.added
                                      ? "bg-hexon-red hover:bg-hexon-red-dark text-white"
                                      : "bg-white border border-hexon-red text-hexon-red hover:bg-hexon-red hover:text-white"
                                  }
                                >
                                  {product.added ? (
                                    <>
                                      <Minus className="w-4 h-4 mr-1" />
                                      Retirer
                                    </>
                                  ) : (
                                    <>
                                      <Plus className="w-4 h-4 mr-1" />
                                      Ajouter
                                    </>
                                  )}
                                </Button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Order Summary */}
            <div className="lg:col-span-1">
              <Card className="border-2 border-hexon-red shadow-lg sticky top-8 bg-white">
                <CardHeader className="bg-hexon-red text-white">
                  <CardTitle className="font-roboto-condensed text-white text-lg">
                    RÉCAPITULATIF COMMANDE
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6 space-y-4 bg-white">
                  {/* Summary */}
                  <div className="space-y-4">
                    <div className="flex justify-between text-black">
                      <span className="font-medium">
                        Sous-total ({inStockItems.length} articles)
                      </span>
                      <span className="font-semibold text-lg">
                        {subtotal.toLocaleString()}€
                      </span>
                    </div>

                    {complementaryTotal > 0 && (
                      <div className="flex justify-between text-black">
                        <span className="font-medium">
                          Services complémentaires (
                          {
                            complementaryItems.filter((item) => item.added)
                              .length
                          }
                          )
                        </span>
                        <span className="font-semibold text-lg">
                          {complementaryTotal.toLocaleString()}€
                        </span>
                      </div>
                    )}

                    {appliedPromo && (
                      <div className="flex justify-between text-green-700 bg-green-50 p-3 rounded-lg border border-green-200">
                        <span className="font-medium">
                          Réduction ({appliedPromo.code})
                        </span>
                        <span className="font-semibold">
                          -{promoDiscount.toLocaleString()}€
                        </span>
                      </div>
                    )}

                    <div className="flex justify-between text-black">
                      <span className="font-medium">Livraison</span>
                      <div className="text-right">
                        <span className="font-semibold text-lg">
                          {shippingCost}€
                        </span>
                        <p className="text-xs text-gray-600">
                          Frais de livraison
                        </p>
                      </div>
                    </div>

                    <div className="border-t-2 border-gray-200 pt-4">
                      <div className="flex justify-between text-xl font-bold">
                        <span className="text-black">Total</span>
                        <span className="text-hexon-red text-2xl">
                          {total.toLocaleString()}€
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Benefits */}
                  <div className="space-y-3 pt-6 border-t-2 border-gray-200">
                    <div className="flex items-center space-x-3 text-sm">
                      <Shield className="w-5 h-5 text-green-600" />
                      <span className="font-medium text-black">
                        Garantie 1 an incluse
                      </span>
                    </div>
                    <div className="flex items-center space-x-3 text-sm">
                      <Truck className="w-5 h-5 text-blue-600" />
                      <span className="font-medium text-black">
                        Assemblage Premium
                      </span>
                    </div>
                    <div className="flex items-center space-x-3 text-sm">
                      <CreditCard className="w-5 h-5 text-purple-600" />
                      <span className="font-medium text-black">
                        Paiement sécurisé
                      </span>
                    </div>
                  </div>

                  {/* Checkout Button */}
                  <div className="pt-4">
                    {outOfStockItems.length > 0 && (
                      <div className="mb-4 p-3 bg-orange-50 border border-orange-200 rounded-lg">
                        <p className="text-sm text-orange-800">
                          Certains articles ne sont plus disponibles.
                          Supprimez-les pour continuer.
                        </p>
                      </div>
                    )}

                    <Link to="/checkout">
                      <Button
                        disabled={inStockItems.length === 0}
                        className="w-full bg-hexon-red hover:bg-hexon-red-dark text-white font-semibold py-3 rounded-xl transition-all duration-200 transform hover:scale-105 disabled:transform-none disabled:opacity-50"
                      >
                        {inStockItems.length === 0 ? (
                          "Panier vide"
                        ) : (
                          <div className="flex items-center justify-center">
                            Commander ({inStockItems.length} articles)
                            <ArrowRight className="w-4 h-4 ml-2" />
                          </div>
                        )}
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
