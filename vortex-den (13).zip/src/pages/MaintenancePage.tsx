import { useState } from "react";
import Header from "../components/Header";
import Footer from "../components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Link } from "react-router-dom";
import {
  Wrench,
  Settings,
  Cpu,
  HardDrive,
  Monitor,
  Zap,
  Clock,
  CheckCircle,
  Phone,
  Mail,
  AlertTriangle,
  Thermometer,
  Volume2,
  Wifi,
  Power,
  RefreshCw,
  ShieldCheck,
  Star,
  ArrowRight,
} from "lucide-react";
import { sendMaintenanceEmail } from "@/lib/emailjs";

interface FormData {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  pcBrand: string;
  problemType: string;
  urgency: string;
  problemDescription: string;
  symptoms: string[];
  preferredContact: string;
  acceptTerms: boolean;
}

const services = [
  {
    id: 1,
    icon: Settings,
    title: "Diagnostic complet",
    description:
      "Analyse approfondie de votre PC pour identifier tous les problèmes",
    features: [
      "Test des composants (CPU, GPU, RAM, disques)",
      "Vérification de la température",
      "Analyse des performances",
      "Rapport détaillé inclus",
    ],
    price: "Gratuit",
    duration: "1-2h",
    color: "bg-blue-500",
  },
  {
    id: 2,
    icon: Wrench,
    title: "Réparation Premium",
    description: "Intervention experte pour remettre votre PC en état optimal",
    features: [
      "Remplacement de composants défaillants",
      "Réparation soudure et connectique",
      "Nettoyage complet du système",
      "Garantie 6 mois sur la réparation",
    ],
    price: "Dès 49€",
    duration: "Qualité garantie",
    color: "bg-hexon-red",
  },
  {
    id: 3,
    icon: RefreshCw,
    title: "Upgrade & Optimisation",
    description:
      "Amélioration des performances et mise à niveau de vos composants",
    features: [
      "Conseil personnalisé selon votre budget",
      "Installation de nouveaux composants",
      "Optimisation logicielle complète",
      "Tests de performance inclus",
    ],
    price: "Dès 39€",
    duration: "2-3h",
    color: "bg-green-500",
  },
  {
    id: 4,
    icon: ShieldCheck,
    title: "Maintenance préventive",
    description:
      "Entretien régulier pour éviter les pannes et optimiser les performances",
    features: [
      "Nettoyage physique complet",
      "Mise à jour des pilotes et firmware",
      "Défragmentation et optimisation",
      "Vérification de l'état des composants",
    ],
    price: "79€",
    duration: "2-3h",
    color: "bg-purple-500",
  },
];

const commonProblems = [
  {
    icon: Power,
    problem: "PC qui ne démarre pas",
    causes: ["Alimentation défaillante", "Carte mère", "Mémoire RAM"],
  },
  {
    icon: Thermometer,
    problem: "Surchauffe",
    causes: ["Ventilateurs bloqués", "Pâte thermique", "Poussière"],
  },
  {
    icon: Volume2,
    problem: "Bruits anormaux",
    causes: ["Ventilateurs usés", "Disque dur défaillant", "Coil whine"],
  },
  {
    icon: Monitor,
    problem: "Problèmes de carte graphique",
    causes: ["GPU défaillant", "Surchauffe", "Pilotes corrompus"],
  },
  {
    icon: Wifi,
    problem: "Problèmes réseau",
    causes: ["Pilotes réseau", "Carte WiFi", "Configuration"],
  },
  {
    icon: AlertTriangle,
    problem: "Plantages système",
    causes: ["Mémoire défaillante", "Pilotes", "Système corrompu"],
  },
];

export default function MaintenancePage() {
  const [formData, setFormData] = useState<FormData>({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    pcBrand: "",
    problemType: "",
    urgency: "",
    problemDescription: "",
    symptoms: [],
    preferredContact: "",
    acceptTerms: false,
  });

  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [emailError, setEmailError] = useState("");

  const updateFormData = (field: keyof FormData, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setEmailError("");

    try {
      const success = await sendMaintenanceEmail(formData);

      if (success) {
        console.log("Maintenance form submitted successfully:", formData);
        setIsSubmitted(true);
      } else {
        setEmailError("Erreur lors de l'envoi. Veuillez réessayer.");
      }
    } catch (error) {
      console.error("Error submitting maintenance form:", error);
      setEmailError("Erreur technique. Veuillez réessayer plus tard.");
    } finally {
      setIsLoading(false);
    }
  };

  const toggleSymptom = (symptom: string) => {
    const symptoms = formData.symptoms.includes(symptom)
      ? formData.symptoms.filter((s) => s !== symptom)
      : [...formData.symptoms, symptom];
    updateFormData("symptoms", symptoms);
  };

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <main className="py-20">
          <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <div className="bg-green-50 border-2 border-green-200 rounded-3xl p-12">
              <CheckCircle className="w-20 h-20 text-green-500 mx-auto mb-6" />
              <h1 className="text-3xl font-bold text-black mb-4 font-roboto-condensed">
                Demande envoyée avec succès !
              </h1>
              <p className="text-lg text-gray-600 mb-6">
                Nous avons bien reçu votre demande de maintenance. Notre équipe
                technique vous contactera dans les <strong>2 heures</strong>{" "}
                pour planifier l'intervention.
              </p>
              <div className="bg-white rounded-xl p-6 mb-6 text-left">
                <h3 className="font-semibold mb-3">Prochaines étapes :</h3>
                <div className="space-y-2 text-sm text-gray-600">
                  <div className="flex items-start space-x-2">
                    <span className="font-semibold text-hexon-red">1.</span>
                    <span>
                      Appel de notre technicien pour préciser le problème
                    </span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <span className="font-semibold text-hexon-red">2.</span>
                    <span>Diagnostic gratuit si nécessaire</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <span className="font-semibold text-hexon-red">3.</span>
                    <span>Devis détaillé pour la réparation</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <span className="font-semibold text-hexon-red">4.</span>
                    <span>Intervention rapide et professionnelle</span>
                  </div>
                </div>
              </div>
              <Button
                onClick={() => setIsSubmitted(false)}
                className="bg-hexon-red hover:bg-hexon-red-dark text-white font-semibold px-8 py-3 rounded-xl"
              >
                Nouvelle demande
              </Button>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <Header />

      <main className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Page Header */}
          <div className="text-center mb-16">
            <Badge
              variant="secondary"
              className="mb-4 bg-hexon-red/10 text-hexon-red border-hexon-red/20"
            >
              Maintenance & Réparation
            </Badge>
            <h1 className="text-4xl md:text-5xl font-bold text-black mb-6 font-roboto-condensed">
              RÉPARATION & <span className="text-hexon-red">MAINTENANCE</span>{" "}
              PC
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Chez HEXON, nous réparons, modifions et optimisons tous types de
              PC. Notre équipe d'experts intervient rapidement pour remettre
              votre machine en parfait état de fonctionnement.
            </p>
          </div>

          {/* Services Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
            {services.map((service) => (
              <Card
                key={service.id}
                className="group hover:shadow-xl transition-all duration-300 border border-gray-200 hover:border-hexon-red/30"
              >
                <CardHeader className="text-center pb-4">
                  <div
                    className={`w-16 h-16 ${service.color} rounded-2xl flex items-center justify-center mx-auto mb-4`}
                  >
                    <service.icon className="w-8 h-8 text-white" />
                  </div>
                  <CardTitle className="text-lg font-bold text-black group-hover:text-hexon-red transition-colors">
                    {service.title}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-gray-600 text-center">
                    {service.description}
                  </p>

                  <div className="space-y-2">
                    {service.features.map((feature, index) => (
                      <div
                        key={index}
                        className="flex items-start space-x-2 text-xs"
                      >
                        <CheckCircle className="w-3 h-3 text-green-500 mt-0.5 flex-shrink-0" />
                        <span className="text-gray-700">{feature}</span>
                      </div>
                    ))}
                  </div>

                  <div className="pt-3 border-t border-gray-100 flex justify-between items-center">
                    <div>
                      <div className="font-bold text-hexon-red">
                        {service.price}
                      </div>
                      <div className="text-xs text-gray-500">
                        {service.duration}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Common Problems Section */}
          <div className="mb-16 bg-hexon-gray-light rounded-3xl p-8 lg:p-12">
            <h2 className="text-3xl font-bold text-black mb-8 text-center font-roboto-condensed">
              PROBLÈMES <span className="text-hexon-red">FRÉQUENTS</span>
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {commonProblems.map((item, index) => (
                <Card key={index} className="bg-white border border-gray-200">
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-3 mb-4">
                      <div className="p-2 bg-hexon-red/10 rounded-lg">
                        <item.icon className="w-5 h-5 text-hexon-red" />
                      </div>
                      <h3 className="font-semibold text-black">
                        {item.problem}
                      </h3>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm font-medium text-gray-700 mb-2">
                        Causes possibles :
                      </p>
                      {item.causes.map((cause, causeIndex) => (
                        <div
                          key={causeIndex}
                          className="flex items-center space-x-2 text-sm text-gray-600"
                        >
                          <div className="w-1.5 h-1.5 bg-hexon-red rounded-full"></div>
                          <span>{cause}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Contact Form */}
          <div className="max-w-4xl mx-auto">
            <Card className="border-2 border-hexon-red/20">
              <CardHeader className="bg-hexon-red/5 text-center">
                <CardTitle className="text-2xl font-bold text-black font-roboto-condensed">
                  DEMANDE DE <span className="text-hexon-red">MAINTENANCE</span>
                </CardTitle>
                <p className="text-gray-600">
                  Décrivez votre problème et nous vous contacterons rapidement
                </p>
              </CardHeader>
              <CardContent className="p-8">
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Personal Information */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label
                        htmlFor="firstName"
                        className="font-medium mb-2 block"
                      >
                        Prénom *
                      </Label>
                      <Input
                        id="firstName"
                        value={formData.firstName}
                        onChange={(e) =>
                          updateFormData("firstName", e.target.value)
                        }
                        placeholder="Votre prénom"
                        required
                      />
                    </div>

                    <div>
                      <Label
                        htmlFor="lastName"
                        className="font-medium mb-2 block"
                      >
                        Nom *
                      </Label>
                      <Input
                        id="lastName"
                        value={formData.lastName}
                        onChange={(e) =>
                          updateFormData("lastName", e.target.value)
                        }
                        placeholder="Votre nom"
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="email" className="font-medium mb-2 block">
                        Email *
                      </Label>
                      <Input
                        id="email"
                        type="email"
                        value={formData.email}
                        onChange={(e) =>
                          updateFormData("email", e.target.value)
                        }
                        placeholder="votre@email.com"
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="phone" className="font-medium mb-2 block">
                        Téléphone *
                      </Label>
                      <Input
                        id="phone"
                        type="tel"
                        value={formData.phone}
                        onChange={(e) =>
                          updateFormData("phone", e.target.value)
                        }
                        placeholder="06 12 34 56 78"
                        required
                      />
                    </div>
                  </div>

                  {/* PC Information */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label className="font-medium mb-2 block">
                        Marque/Modèle de votre PC
                      </Label>
                      <Input
                        value={formData.pcBrand}
                        onChange={(e) =>
                          updateFormData("pcBrand", e.target.value)
                        }
                        placeholder="Ex: PC HEXON, Dell, HP, assemblé..."
                      />
                    </div>

                    <div>
                      <Label className="font-medium mb-2 block">
                        Type de problème *
                      </Label>
                      <Select
                        value={formData.problemType}
                        onValueChange={(value) =>
                          updateFormData("problemType", value)
                        }
                        required
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Choisir le type de problème" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="no-start">
                            PC ne démarre pas
                          </SelectItem>
                          <SelectItem value="performance">
                            Lenteur/Performance
                          </SelectItem>
                          <SelectItem value="overheating">
                            Surchauffe
                          </SelectItem>
                          <SelectItem value="noise">Bruits anormaux</SelectItem>
                          <SelectItem value="display">
                            Problème d'affichage
                          </SelectItem>
                          <SelectItem value="network">
                            Problème réseau
                          </SelectItem>
                          <SelectItem value="crashes">
                            Plantages système
                          </SelectItem>
                          <SelectItem value="virus">Virus/Malware</SelectItem>
                          <SelectItem value="upgrade">
                            Demande d'upgrade
                          </SelectItem>
                          <SelectItem value="other">Autre</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Urgency */}
                  <div>
                    <Label className="font-medium mb-4 block">
                      Niveau d'urgence *
                    </Label>
                    <RadioGroup
                      value={formData.urgency}
                      onValueChange={(value) =>
                        updateFormData("urgency", value)
                      }
                      className="flex flex-col sm:flex-row gap-4"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="low" id="low" />
                        <Label htmlFor="low" className="cursor-pointer">
                          <span className="font-medium text-green-600">
                            Faible
                          </span>
                          <span className="text-sm text-gray-500 block">
                            Pas pressé, dans la semaine
                          </span>
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="medium" id="medium" />
                        <Label htmlFor="medium" className="cursor-pointer">
                          <span className="font-medium text-orange-600">
                            Moyenne
                          </span>
                          <span className="text-sm text-gray-500 block">
                            Sous 2-3 jours
                          </span>
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="high" id="high" />
                        <Label htmlFor="high" className="cursor-pointer">
                          <span className="font-medium text-red-600">
                            Urgente
                          </span>
                          <span className="text-sm text-gray-500 block">
                            Dès que possible
                          </span>
                        </Label>
                      </div>
                    </RadioGroup>
                  </div>

                  {/* Symptoms */}
                  <div>
                    <Label className="font-medium mb-4 block">
                      Symptômes observés (optionnel)
                    </Label>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      {[
                        "Freeze/Blocage",
                        "Redémarrages",
                        "Ventilateurs bruyants",
                        "PC très chaud",
                        "Pas d'affichage",
                        "Artefacts graphiques",
                        "WiFi ne fonctionne pas",
                        "Bluetooth défaillant",
                        "USB ne marchent plus",
                        "Son coupé",
                        "Très lent au démarrage",
                        "Applications plantent",
                      ].map((symptom) => (
                        <div
                          key={symptom}
                          className="flex items-center space-x-2"
                        >
                          <Checkbox
                            id={symptom}
                            checked={formData.symptoms.includes(symptom)}
                            onCheckedChange={() => toggleSymptom(symptom)}
                          />
                          <Label
                            htmlFor={symptom}
                            className="text-sm cursor-pointer"
                          >
                            {symptom}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Problem Description */}
                  <div>
                    <Label
                      htmlFor="description"
                      className="font-medium mb-2 block"
                    >
                      Description détaillée du problème *
                    </Label>
                    <Textarea
                      id="description"
                      value={formData.problemDescription}
                      onChange={(e) =>
                        updateFormData("problemDescription", e.target.value)
                      }
                      placeholder="Décrivez le plus précisément possible le problème rencontré, depuis quand cela se produit, dans quelles circonstances..."
                      rows={4}
                      required
                    />
                  </div>

                  {/* Preferred Contact */}
                  <div>
                    <Label className="font-medium mb-4 block">
                      Mode de contact préféré *
                    </Label>
                    <RadioGroup
                      value={formData.preferredContact}
                      onValueChange={(value) =>
                        updateFormData("preferredContact", value)
                      }
                      className="flex flex-col sm:flex-row gap-4"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="phone" id="phone-contact" />
                        <Label
                          htmlFor="phone-contact"
                          className="cursor-pointer flex items-center space-x-2"
                        >
                          <Phone className="w-4 h-4 text-hexon-red" />
                          <span>Téléphone</span>
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="email" id="email-contact" />
                        <Label
                          htmlFor="email-contact"
                          className="cursor-pointer flex items-center space-x-2"
                        >
                          <Mail className="w-4 h-4 text-hexon-red" />
                          <span>Email</span>
                        </Label>
                      </div>
                    </RadioGroup>
                  </div>

                  {/* Terms */}
                  <div className="flex items-start space-x-2">
                    <Checkbox
                      id="terms"
                      checked={formData.acceptTerms}
                      onCheckedChange={(checked) =>
                        updateFormData("acceptTerms", checked)
                      }
                      required
                    />
                    <Label htmlFor="terms" className="text-sm cursor-pointer">
                      J'accepte que HEXON me contacte concernant ma demande de
                      maintenance et je confirme que les informations fournies
                      sont exactes. *
                    </Label>
                  </div>

                  {/* Error Message */}
                  {emailError && (
                    <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                      <p className="text-red-700 text-sm flex items-center">
                        <AlertTriangle className="w-4 h-4 mr-2" />
                        {emailError}
                      </p>
                    </div>
                  )}

                  {/* Submit Button */}
                  <div className="pt-6">
                    <Button
                      type="submit"
                      className="w-full bg-hexon-red hover:bg-hexon-red-dark text-white font-semibold py-3 rounded-xl transition-all duration-200 transform hover:scale-105 disabled:opacity-50 disabled:transform-none"
                      disabled={
                        isLoading ||
                        !formData.firstName ||
                        !formData.lastName ||
                        !formData.email ||
                        !formData.phone ||
                        !formData.problemType ||
                        !formData.urgency ||
                        !formData.problemDescription ||
                        !formData.preferredContact ||
                        !formData.acceptTerms
                      }
                    >
                      {isLoading ? (
                        <>
                          <div className="w-4 h-4 mr-2 border-2 border-white border-t-transparent rounded-full animate-spin" />
                          Envoi en cours...
                        </>
                      ) : (
                        <>
                          Envoyer ma demande de maintenance
                          <ArrowRight className="w-4 h-4 ml-2" />
                        </>
                      )}
                    </Button>
                  </div>
                </form>

                <div className="mt-8 p-6 bg-white rounded-xl border border-gray-200">
                  <h4 className="font-semibold text-black mb-2">
                    Vous ne trouvez pas la réponse à votre question ?
                  </h4>
                  <p className="text-gray-600 mb-4">
                    Notre équipe support est là pour vous aider 7j/7
                  </p>
                  <div className="flex flex-col sm:flex-row gap-3">
                    <Link to="/contact">
                      <Button className="bg-hexon-red hover:bg-hexon-red-dark text-white w-full sm:w-auto">
                        Demander un diagnostic
                      </Button>
                    </Link>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Contact Info */}
          <div className="mt-16 bg-gradient-to-r from-hexon-black to-gray-800 rounded-3xl p-8 lg:p-12 text-white">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
              <div>
                <h3 className="text-3xl font-bold mb-4 font-roboto-condensed">
                  BESOIN D'AIDE{" "}
                  <span className="text-hexon-red">IMMÉDIATE</span> ?
                </h3>
                <p className="text-xl text-gray-300 mb-6">
                  Notre équipe technique est disponible pour vous conseiller et
                  vous orienter vers la meilleure solution.
                </p>
                <div className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <Mail className="w-5 h-5 text-hexon-red" />
                    <span>contact@hexonpc.com</span>
                  </div>
                </div>
              </div>

              <div className="bg-white/10 rounded-xl p-6">
                <h4 className="font-semibold mb-4 flex items-center">
                  <Clock className="w-5 h-5 text-hexon-red mr-2" />
                  Nos garanties maintenance
                </h4>
                <div className="space-y-3 text-sm">
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-green-400" />
                    <span>Diagnostic gratuit sans engagement</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-green-400" />
                    <span>Devis détaillé avant intervention</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-green-400" />
                    <span>Garantie 6 mois sur les réparations</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-green-400">
                    <CheckCircle className="w-4 h-4 text-green-400" />
                    <span>Travail soigné et garanti</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-green-400" />
                    <span>Pièces de qualité d'origine</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Bottom contact CTAs */}
            <div className="mt-8 text-center">
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <Link to="/contact">
                  <Button className="bg-hexon-red hover:bg-hexon-red-dark text-white w-full sm:w-auto">
                    📞 Rappel gratuit
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
