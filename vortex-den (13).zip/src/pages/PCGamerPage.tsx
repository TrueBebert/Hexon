import { useState, useMemo } from "react";
import Header from "../components/Header";
import Footer from "../components/Footer";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Star,
  Cpu,
  HardDrive,
  Zap,
  Monitor,
  ArrowUpDown,
  Tag,
  Calendar,
} from "lucide-react";
import { Link } from "react-router-dom";

interface Product {
  id: number;
  name: string;
  category: string;
  price: number;
  originalPrice?: number;
  rating: number;
  reviews: number;
  badge?: string;
  badgeColor?: string;
  specs: {
    processor: string;
    gpu: string;
    ram: string;
    storage: string;
    psu: string;
  };
  isNew?: boolean;
  releaseDate: string;
  image: string;
}

const products: Product[] = [
  {
    id: 1,
    name: "HEXON STARTER RTX 4060",
    category: "PC Gamer Entrée",
    price: 899,
    originalPrice: 999,
    rating: 0,
    reviews: 0,
    badge: "Promo",
    badgeColor: "bg-orange-500",
    specs: {
      processor: "Intel Core i3-13100F",
      gpu: "NVIDIA RTX 4060 8GB",
      ram: "16GB DDR4 3200MHz",
      storage: "500GB NVMe SSD",
      psu: "550W 80+ Bronze",
    },
    isNew: false,
    releaseDate: "2024-01-15",
    image: "/api/placeholder/400/300",
  },
  {
    id: 2,
    name: "HEXON FURY RTX 5060",
    category: "PC Gamer Entrée",
    price: 1299,
    originalPrice: 1399,
    rating: 0,
    reviews: 0,
    badge: "Bestseller",
    badgeColor: "bg-green-500",
    specs: {
      processor: "Intel Core i5-14400F",
      gpu: "NVIDIA RTX 5060 16GB",
      ram: "16GB DDR5 5600MHz",
      storage: "1TB NVMe SSD",
      psu: "650W 80+ Gold",
    },
    isNew: false,
    releaseDate: "2024-02-10",
    image: "/api/placeholder/400/300",
  },
  {
    id: 3,
    name: "HEXON DESTROYER RTX 5070",
    category: "PC Gamer Premium",
    price: 1899,
    rating: 0,
    reviews: 0,
    badge: "Nouveau",
    badgeColor: "bg-hexon-red",
    specs: {
      processor: "Intel Core i7-14700F",
      gpu: "NVIDIA RTX 5070 16GB",
      ram: "32GB DDR5 6000MHz",
      storage: "2TB NVMe SSD",
      psu: "750W 80+ Gold",
    },
    isNew: true,
    releaseDate: "2024-11-01",
    image: "/api/placeholder/400/300",
  },
  {
    id: 4,
    name: "HEXON APEX RTX 5090",
    category: "PC Gamer Elite",
    price: 3499,
    rating: 0,
    reviews: 0,
    badge: "Elite",
    badgeColor: "bg-purple-600",
    specs: {
      processor: "Intel Core i9-14900K",
      gpu: "NVIDIA RTX 5090 32GB",
      ram: "64GB DDR5 6400MHz",
      storage: "4TB NVMe SSD",
      psu: "1000W 80+ Platinum",
    },
    isNew: true,
    releaseDate: "2024-10-15",
    image: "/api/placeholder/400/300",
  },
  {
    id: 5,
    name: "HEXON BEAST RTX 4080",
    category: "PC Gamer Premium",
    price: 2299,
    originalPrice: 2499,
    rating: 0,
    reviews: 0,
    badge: "Promo",
    badgeColor: "bg-orange-500",
    specs: {
      processor: "Intel Core i7-13700K",
      gpu: "NVIDIA RTX 4080 16GB",
      ram: "32GB DDR5 5600MHz",
      storage: "2TB NVMe SSD",
      psu: "850W 80+ Gold",
    },
    isNew: false,
    releaseDate: "2024-03-20",
    image: "/api/placeholder/400/300",
  },
  {
    id: 6,
    name: "HEXON VIPER RTX 4070 TI",
    category: "PC Gamer Premium",
    price: 1699,
    rating: 0,
    reviews: 0,
    badge: "Populaire",
    badgeColor: "bg-blue-500",
    specs: {
      processor: "Intel Core i5-14600K",
      gpu: "NVIDIA RTX 4070 TI 12GB",
      ram: "32GB DDR5 5600MHz",
      storage: "1TB NVMe SSD",
      psu: "750W 80+ Gold",
    },
    isNew: false,
    releaseDate: "2024-04-12",
    image: "/api/placeholder/400/300",
  },
  {
    id: 7,
    name: "HEXON TITAN RTX 4090",
    category: "PC Gamer Elite",
    price: 3199,
    rating: 0,
    reviews: 0,
    badge: "Elite",
    badgeColor: "bg-purple-600",
    specs: {
      processor: "Intel Core i9-13900K",
      gpu: "NVIDIA RTX 4090 24GB",
      ram: "64GB DDR5 6000MHz",
      storage: "4TB NVMe SSD",
      psu: "1000W 80+ Platinum",
    },
    isNew: false,
    releaseDate: "2024-01-30",
    image: "/api/placeholder/400/300",
  },
  {
    id: 8,
    name: "HEXON PHANTOM RTX 5070 TI",
    category: "PC Gamer Premium",
    price: 2099,
    rating: 0,
    reviews: 0,
    badge: "Nouveau",
    badgeColor: "bg-hexon-red",
    specs: {
      processor: "Intel Core i7-14700K",
      gpu: "NVIDIA RTX 5070 TI 16GB",
      ram: "32GB DDR5 6000MHz",
      storage: "2TB NVMe SSD",
      psu: "850W 80+ Gold",
    },
    isNew: true,
    releaseDate: "2024-11-15",
    image: "/api/placeholder/400/300",
  },
];

type SortOption =
  | "name-asc"
  | "name-desc"
  | "price-asc"
  | "price-desc"
  | "newest"
  | "rating";

export default function PCGamerPage() {
  const [sortBy, setSortBy] = useState<SortOption>("newest");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");

  const categories = [
    "all",
    "PC Gamer Entrée",
    "PC Gamer Premium",
    "PC Gamer Elite",
  ];

  const filteredAndSortedProducts = useMemo(() => {
    let filtered = products;

    // Filter by category
    if (selectedCategory !== "all") {
      filtered = filtered.filter(
        (product) => product.category === selectedCategory,
      );
    }

    // Sort products
    const sorted = [...filtered].sort((a, b) => {
      switch (sortBy) {
        case "name-asc":
          return a.name.localeCompare(b.name);
        case "name-desc":
          return b.name.localeCompare(a.name);
        case "price-asc":
          return a.price - b.price;
        case "price-desc":
          return b.price - a.price;
        case "newest":
          return (
            new Date(b.releaseDate).getTime() -
            new Date(a.releaseDate).getTime()
          );
        case "rating":
          return b.rating - a.rating;
        default:
          return 0;
      }
    });

    return sorted;
  }, [sortBy, selectedCategory]);

  return (
    <div className="min-h-screen bg-white">
      <Header />

      <main className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Page Header */}
          <div className="mb-12">
            <div className="text-center mb-8">
              <Badge
                variant="secondary"
                className="mb-4 bg-hexon-red/10 text-hexon-red border-hexon-red/20"
              >
                PC Gaming
              </Badge>
              <h1 className="text-4xl md:text-5xl font-bold text-black mb-6 font-roboto-condensed">
                PC <span className="text-hexon-red">GAMER</span> HEXON
              </h1>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Découvrez notre gamme complète de PC gaming haute performance,
                des configurations d'entrée de gamme aux setups les plus
                extrêmes.
              </p>
            </div>

            {/* Filters Section */}
            <div className="bg-hexon-gray-light rounded-2xl p-6 mb-8">
              <div className="flex flex-col lg:flex-row gap-4 items-start lg:items-center justify-between">
                <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
                  <div className="flex items-center space-x-2">
                    <Tag className="w-5 h-5 text-hexon-red" />
                    <span className="font-semibold text-black">Filtres :</span>
                  </div>

                  {/* Category Filter */}
                  <Select
                    value={selectedCategory}
                    onValueChange={setSelectedCategory}
                  >
                    <SelectTrigger className="w-48 bg-white border-gray-300">
                      <SelectValue placeholder="Catégorie" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Toutes les catégories</SelectItem>
                      <SelectItem value="PC Gamer Entrée">
                        Entrée de gamme
                      </SelectItem>
                      <SelectItem value="PC Gamer Premium">Premium</SelectItem>
                      <SelectItem value="PC Gamer Elite">Elite</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2">
                    <ArrowUpDown className="w-5 h-5 text-hexon-red" />
                    <span className="font-semibold text-black">
                      Trier par :
                    </span>
                  </div>

                  {/* Sort Filter */}
                  <Select
                    value={sortBy}
                    onValueChange={(value: SortOption) => setSortBy(value)}
                  >
                    <SelectTrigger className="w-48 bg-white border-gray-300">
                      <SelectValue placeholder="Tri" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="newest">
                        <div className="flex items-center space-x-2">
                          <Calendar className="w-4 h-4" />
                          <span>Plus récents</span>
                        </div>
                      </SelectItem>
                      <SelectItem value="price-asc">Prix croissant</SelectItem>
                      <SelectItem value="price-desc">
                        Prix décroissant
                      </SelectItem>
                      <SelectItem value="name-asc">Nom A-Z</SelectItem>
                      <SelectItem value="name-desc">Nom Z-A</SelectItem>
                      <SelectItem value="rating">Meilleures notes</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Results count */}
              <div className="mt-4 pt-4 border-t border-gray-200">
                <p className="text-sm text-gray-600">
                  <span className="font-semibold text-hexon-red">
                    {filteredAndSortedProducts.length}
                  </span>{" "}
                  PC gaming trouvés
                  {selectedCategory !== "all" && (
                    <span>
                      {" "}
                      dans la catégorie <strong>{selectedCategory}</strong>
                    </span>
                  )}
                </p>
              </div>
            </div>
          </div>

          {/* Products Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-12">
            {filteredAndSortedProducts.map((product) => (
              <Card
                key={product.id}
                className="group hover:shadow-2xl transition-all duration-300 border border-gray-200 hover:border-hexon-red/30 bg-gradient-to-br from-white to-gray-50"
              >
                {/* Product Image */}
                <CardHeader className="p-0 relative">
                  <div className="relative aspect-[4/3] bg-gradient-to-br from-gray-100 to-gray-200 overflow-hidden">
                    {/* Product glow effect */}
                    <div className="absolute inset-4 bg-hexon-red/20 rounded-full blur-3xl opacity-40 animate-pulse-glow"></div>

                    {/* PC representation */}
                    <div className="absolute inset-0 bg-gradient-to-br from-gray-800 via-black to-gray-900 flex items-center justify-center">
                      <div className="bg-black rounded-lg p-4 border border-hexon-red/30 shadow-2xl">
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <div className="w-2 h-2 bg-hexon-red rounded-full animate-pulse"></div>
                            <div className="text-xs text-gray-400 font-mono">
                              HEXON
                            </div>
                          </div>
                          <div className="space-y-1">
                            <div className="h-1.5 bg-gradient-to-r from-hexon-red to-red-400 rounded-full"></div>
                            <div className="h-1.5 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full w-3/4"></div>
                            <div className="h-1.5 bg-gradient-to-r from-green-500 to-teal-500 rounded-full w-1/2"></div>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Badges */}
                    <div className="absolute top-3 left-3 z-10 flex flex-col gap-2">
                      {product.badge && (
                        <Badge
                          className={`${product.badgeColor} text-white font-semibold text-xs px-2 py-1`}
                        >
                          {product.badge}
                        </Badge>
                      )}
                      {product.isNew && (
                        <Badge className="bg-hexon-red text-white font-semibold text-xs px-2 py-1">
                          Nouveau
                        </Badge>
                      )}
                    </div>

                    {product.originalPrice && (
                      <div className="absolute top-3 right-3 z-10">
                        <Badge className="bg-orange-500 text-white font-semibold text-xs px-2 py-1">
                          -
                          {Math.round(
                            ((product.originalPrice - product.price) /
                              product.originalPrice) *
                              100,
                          )}
                          %
                        </Badge>
                      </div>
                    )}
                  </div>
                </CardHeader>

                <CardContent className="p-4 flex-1">
                  {/* Product Info */}
                  <div className="mb-4">
                    <div className="text-xs text-gray-500 mb-1">
                      {product.category}
                    </div>
                    <h3 className="text-lg font-bold text-black group-hover:text-hexon-red transition-colors mb-2 line-clamp-2">
                      {product.name}
                    </h3>

                    {/* Rating - only show if product has reviews */}
                    {product.reviews > 0 && (
                      <div className="flex items-center space-x-2 mb-3">
                        <div className="flex items-center">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`w-3 h-3 ${i < Math.floor(product.rating) ? "text-yellow-400 fill-current" : "text-gray-300"}`}
                            />
                          ))}
                        </div>
                        <span className="text-xs text-gray-600">
                          {product.rating} ({product.reviews})
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Key Specs */}
                  <div className="space-y-2 mb-4">
                    <div className="flex items-center space-x-2 text-xs">
                      <Cpu className="w-3 h-3 text-hexon-red flex-shrink-0" />
                      <span className="text-gray-700 truncate">
                        {product.specs.processor}
                      </span>
                    </div>
                    <div className="flex items-center space-x-2 text-xs">
                      <Monitor className="w-3 h-3 text-hexon-red flex-shrink-0" />
                      <span className="text-gray-700 truncate">
                        {product.specs.gpu}
                      </span>
                    </div>
                    <div className="flex items-center space-x-2 text-xs">
                      <HardDrive className="w-3 h-3 text-hexon-red flex-shrink-0" />
                      <span className="text-gray-700 truncate">
                        {product.specs.ram}
                      </span>
                    </div>
                  </div>
                </CardContent>

                <CardFooter className="p-4 pt-0 flex flex-col space-y-3">
                  {/* Price */}
                  <div className="w-full">
                    <div className="flex items-center space-x-2 mb-1">
                      <span className="text-xl font-bold text-hexon-red">
                        {product.price.toLocaleString()}€
                      </span>
                      {product.originalPrice && (
                        <span className="text-sm text-gray-400 line-through">
                          {product.originalPrice.toLocaleString()}€
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-gray-500">
                      Ou 3x {Math.round(product.price / 3)}€ sans frais
                    </div>
                  </div>

                  {/* Add to Cart */}
                  <Button className="w-full bg-hexon-red hover:bg-hexon-red-dark text-white font-semibold py-2 rounded-xl transition-all duration-200 transform hover:scale-105">
                    Ajouter au panier
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>

          {/* Bottom CTA */}
          <div className="text-center bg-gradient-to-r from-hexon-black to-gray-800 rounded-3xl p-8 lg:p-12 text-white">
            <h3 className="text-3xl md:text-4xl font-bold mb-4 font-roboto-condensed">
              PC sur mesure disponible
            </h3>
            <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
              Aucune configuration ne correspond à vos besoins ? Créez votre PC
              gaming 100% personnalisé
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
              <Link to="/pc-sur-mesure">
                <Button
                  size="lg"
                  className="bg-hexon-red hover:bg-hexon-red-dark text-white font-semibold px-8 py-3 rounded-xl transition-all duration-200 w-full sm:w-auto"
                >
                  Configurer mon PC
                </Button>
              </Link>
              <Link to="/contact">
                <Button
                  variant="outline"
                  size="lg"
                  className="border-white text-white hover:bg-white hover:text-black font-semibold px-8 py-3 rounded-xl transition-all duration-200 w-full sm:w-auto"
                >
                  Demander conseil
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
