import { useState } from "react";
import Header from "../components/Header";
import Footer from "../components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { sendContactEmail } from "@/lib/emailjs";
import { Link } from "react-router-dom";
import {
  Mail,
  Clock,
  MessageCircle,
  Headphones,
  ShoppingCart,
  Wrench,
  HelpCircle,
  Users,
  CheckCircle,
  AlertCircle,
  Building,
  Send,
  Star,
  Calendar,
  ArrowRight,
} from "lucide-react";

interface FormData {
  // Personal info
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  company: string;

  // Contact type
  contactType: string;
  subject: string;
  priority: string;

  // Order info (if SAV)
  orderNumber: string;
  productName: string;

  // Message
  message: string;
  attachments: boolean;
  newsletter: boolean;
  acceptTerms: boolean;
}

const contactTypes = [
  {
    value: "sav",
    label: "Service Après-Vente",
    icon: Wrench,
    description: "Problème avec votre PC HEXON",
    color: "bg-red-500",
  },
  {
    value: "order",
    label: "Question sur commande",
    icon: ShoppingCart,
    description: "Suivi, livraison, facturation",
    color: "bg-blue-500",
  },
  {
    value: "technical",
    label: "Support technique",
    icon: Headphones,
    description: "Aide technique, conseil config",
    color: "bg-green-500",
  },
  {
    value: "sales",
    label: "Renseignements commerciaux",
    icon: MessageCircle,
    description: "Devis, tarifs, disponibilité",
    color: "bg-purple-500",
  },
  {
    value: "partnership",
    label: "Partenariat/Entreprise",
    icon: Building,
    description: "Collaboration, volume, B2B",
    color: "bg-orange-500",
  },
  {
    value: "other",
    label: "Autre demande",
    icon: HelpCircle,
    description: "Question générale",
    color: "bg-gray-500",
  },
];

const contactMethods = [
  {
    icon: Mail,
    title: "Email",
    content: "contact@hexonpc.com",
    subtitle: "Réponse sous 2h en moyenne",
    color: "text-blue-600",
    bgColor: "bg-blue-50",
  },
];

export default function ContactPage() {
  const [formData, setFormData] = useState<FormData>({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    company: "",
    contactType: "",
    subject: "",
    priority: "normal",
    orderNumber: "",
    productName: "",
    message: "",
    attachments: false,
    newsletter: false,
    acceptTerms: false,
  });

  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [emailError, setEmailError] = useState("");

  const updateFormData = (field: keyof FormData, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setEmailError("");

    try {
      const success = await sendContactEmail(formData);

      if (success) {
        console.log("Contact form submitted successfully:", formData);
        setIsSubmitted(true);
      } else {
        setEmailError("Erreur lors de l'envoi. Veuillez réessayer.");
      }
    } catch (error) {
      console.error("Error submitting contact form:", error);
      setEmailError("Erreur technique. Veuillez réessayer plus tard.");
    } finally {
      setIsLoading(false);
    }
  };

  const selectedContactType = contactTypes.find(
    (type) => type.value === formData.contactType,
  );

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <main className="py-20">
          <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <div className="bg-green-50 border-2 border-green-200 rounded-3xl p-12">
              <CheckCircle className="w-20 h-20 text-green-500 mx-auto mb-6" />
              <h1 className="text-3xl font-bold text-black mb-4 font-roboto-condensed">
                Message envoyé avec succès !
              </h1>
              <p className="text-lg text-gray-600 mb-6">
                Nous avons bien reçu votre message. Notre équipe vous contactera
                dans les{" "}
                <strong>
                  {formData.priority === "urgent"
                    ? "2 heures"
                    : formData.priority === "high"
                      ? "4 heures"
                      : "24 heures"}
                </strong>
                .
              </p>
              <div className="bg-white rounded-xl p-6 mb-6 text-left">
                <h3 className="font-semibold mb-3">Récapitulatif :</h3>
                <div className="space-y-2 text-sm text-gray-600">
                  <div className="flex justify-between">
                    <span>Type de demande :</span>
                    <span className="font-medium">
                      {selectedContactType?.label}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Priorité :</span>
                    <span className="font-medium capitalize">
                      {formData.priority === "urgent"
                        ? "Urgente"
                        : formData.priority === "high"
                          ? "Élevée"
                          : "Normale"}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Email de contact :</span>
                    <span className="font-medium">{formData.email}</span>
                  </div>
                  {formData.orderNumber && (
                    <div className="flex justify-between">
                      <span>N° de commande :</span>
                      <span className="font-medium">
                        {formData.orderNumber}
                      </span>
                    </div>
                  )}
                </div>
              </div>
              <Button
                onClick={() => setIsSubmitted(false)}
                className="bg-hexon-red hover:bg-hexon-red-dark text-white font-semibold px-8 py-3 rounded-xl"
              >
                Nouveau message
              </Button>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <Header />

      <main className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Page Header */}
          <div className="text-center mb-16">
            <Badge
              variant="secondary"
              className="mb-4 bg-hexon-red/10 text-hexon-red border-hexon-red/20"
            >
              Contact & Support
            </Badge>
            <h1 className="text-4xl md:text-5xl font-bold text-black mb-6 font-roboto-condensed">
              CONTACTEZ <span className="text-hexon-red">HEXON</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Une question ? Un problème ? Besoin d'aide ? Notre équipe
              d'experts est là pour vous accompagner et répondre à toutes vos
              demandes.
            </p>
          </div>

          {/* Contact Methods */}
          <div className="flex justify-center mb-16">
            <div className="max-w-sm">
              {contactMethods.map((method, index) => (
                <Card
                  key={index}
                  className="group hover:shadow-lg transition-all duration-300 border border-gray-200 hover:border-hexon-red/30"
                >
                  <CardContent className="p-8 text-center">
                    <div
                      className={`w-20 h-20 ${method.bgColor} rounded-2xl flex items-center justify-center mx-auto mb-6`}
                    >
                      <method.icon className={`w-10 h-10 ${method.color}`} />
                    </div>
                    <h3 className="font-bold text-black mb-3 text-lg">
                      {method.title}
                    </h3>
                    <p className="font-semibold text-gray-900 mb-2 text-lg">
                      {method.content}
                    </p>
                    <p className="text-sm text-gray-500">{method.subtitle}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Contact Form */}
          <div className="max-w-4xl mx-auto">
            <Card className="border-2 border-hexon-red/20">
              <CardHeader className="bg-hexon-red/5 text-center">
                <CardTitle className="text-2xl font-bold text-black font-roboto-condensed">
                  FORMULAIRE DE <span className="text-hexon-red">CONTACT</span>
                </CardTitle>
                <p className="text-gray-600">
                  Remplissez le formulaire ci-dessous et nous vous répondrons
                  rapidement
                </p>
              </CardHeader>
              <CardContent className="p-8">
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Contact Type Selection */}
                  <div>
                    <Label className="font-medium mb-4 block text-lg">
                      Type de demande *
                    </Label>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {contactTypes.map((type) => (
                        <div
                          key={type.value}
                          className="flex items-center space-x-2"
                        >
                          <input
                            type="radio"
                            id={type.value}
                            name="contactType"
                            value={type.value}
                            checked={formData.contactType === type.value}
                            onChange={(e) =>
                              updateFormData("contactType", e.target.value)
                            }
                            className="sr-only"
                          />
                          <Label
                            htmlFor={type.value}
                            className={`cursor-pointer p-4 border-2 rounded-xl hover:bg-gray-50 flex-1 transition-all ${
                              formData.contactType === type.value
                                ? "border-hexon-red bg-hexon-red/5"
                                : "border-gray-200"
                            }`}
                          >
                            <div className="flex items-start space-x-3">
                              <div
                                className={`p-2 ${type.color} rounded-lg flex-shrink-0`}
                              >
                                <type.icon className="w-4 h-4 text-white" />
                              </div>
                              <div>
                                <div className="font-semibold text-sm">
                                  {type.label}
                                </div>
                                <div className="text-xs text-gray-500">
                                  {type.description}
                                </div>
                              </div>
                            </div>
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Personal Information */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label
                        htmlFor="firstName"
                        className="font-medium mb-2 block"
                      >
                        Prénom *
                      </Label>
                      <Input
                        id="firstName"
                        value={formData.firstName}
                        onChange={(e) =>
                          updateFormData("firstName", e.target.value)
                        }
                        placeholder="Votre prénom"
                        required
                      />
                    </div>

                    <div>
                      <Label
                        htmlFor="lastName"
                        className="font-medium mb-2 block"
                      >
                        Nom *
                      </Label>
                      <Input
                        id="lastName"
                        value={formData.lastName}
                        onChange={(e) =>
                          updateFormData("lastName", e.target.value)
                        }
                        placeholder="Votre nom"
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="email" className="font-medium mb-2 block">
                        Email *
                      </Label>
                      <Input
                        id="email"
                        type="email"
                        value={formData.email}
                        onChange={(e) =>
                          updateFormData("email", e.target.value)
                        }
                        placeholder="votre@email.com"
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="phone" className="font-medium mb-2 block">
                        Téléphone
                      </Label>
                      <Input
                        id="phone"
                        type="tel"
                        value={formData.phone}
                        onChange={(e) =>
                          updateFormData("phone", e.target.value)
                        }
                        placeholder="06 12 34 56 78"
                      />
                    </div>
                  </div>

                  {/* Company (if partnership) */}
                  {formData.contactType === "partnership" && (
                    <div>
                      <Label
                        htmlFor="company"
                        className="font-medium mb-2 block"
                      >
                        Entreprise *
                      </Label>
                      <Input
                        id="company"
                        value={formData.company}
                        onChange={(e) =>
                          updateFormData("company", e.target.value)
                        }
                        placeholder="Nom de votre entreprise"
                        required={formData.contactType === "partnership"}
                      />
                    </div>
                  )}

                  {/* Subject and Priority */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label
                        htmlFor="subject"
                        className="font-medium mb-2 block"
                      >
                        Sujet *
                      </Label>
                      <Input
                        id="subject"
                        value={formData.subject}
                        onChange={(e) =>
                          updateFormData("subject", e.target.value)
                        }
                        placeholder="Résumé de votre demande"
                        required
                      />
                    </div>

                    <div>
                      <Label className="font-medium mb-2 block">Priorité</Label>
                      <Select
                        value={formData.priority}
                        onValueChange={(value) =>
                          updateFormData("priority", value)
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="normal">
                            Normale (réponse sous 24h)
                          </SelectItem>
                          <SelectItem value="high">
                            Élevée (réponse sous 4h)
                          </SelectItem>
                          <SelectItem value="urgent">
                            Urgente (réponse sous 2h)
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {/* Order info for SAV/Order inquiries */}
                  {(formData.contactType === "sav" ||
                    formData.contactType === "order") && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <Label
                          htmlFor="orderNumber"
                          className="font-medium mb-2 block"
                        >
                          Numéro de commande
                        </Label>
                        <Input
                          id="orderNumber"
                          value={formData.orderNumber}
                          onChange={(e) =>
                            updateFormData("orderNumber", e.target.value)
                          }
                          placeholder="HEX-2024-001234"
                        />
                      </div>

                      <div>
                        <Label
                          htmlFor="productName"
                          className="font-medium mb-2 block"
                        >
                          Nom du produit
                        </Label>
                        <Input
                          id="productName"
                          value={formData.productName}
                          onChange={(e) =>
                            updateFormData("productName", e.target.value)
                          }
                          placeholder="HEXON DESTROYER RTX 5070"
                        />
                      </div>
                    </div>
                  )}

                  {/* Message */}
                  <div>
                    <Label htmlFor="message" className="font-medium mb-2 block">
                      Message *
                    </Label>
                    <Textarea
                      id="message"
                      value={formData.message}
                      onChange={(e) =>
                        updateFormData("message", e.target.value)
                      }
                      placeholder="Décrivez votre demande en détail..."
                      rows={5}
                      required
                    />
                  </div>

                  {/* Additional options */}
                  <div className="space-y-4">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="attachments"
                        checked={formData.attachments}
                        onCheckedChange={(checked) =>
                          updateFormData("attachments", checked)
                        }
                      />
                      <Label htmlFor="attachments" className="text-sm">
                        J'ai des fichiers à joindre (photos, factures,
                        documents)
                      </Label>
                    </div>

                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="newsletter"
                        checked={formData.newsletter}
                        onCheckedChange={(checked) =>
                          updateFormData("newsletter", checked)
                        }
                      />
                      <Label htmlFor="newsletter" className="text-sm">
                        Je souhaite recevoir la newsletter HEXON avec les
                        nouveautés et offres spéciales
                      </Label>
                    </div>

                    <div className="flex items-start space-x-2">
                      <Checkbox
                        id="terms"
                        checked={formData.acceptTerms}
                        onCheckedChange={(checked) =>
                          updateFormData("acceptTerms", checked)
                        }
                        required
                      />
                      <Label htmlFor="terms" className="text-sm">
                        J'accepte que HEXON traite mes données personnelles pour
                        répondre à ma demande et je confirme que les
                        informations fournies sont exactes. *
                      </Label>
                    </div>
                  </div>

                  {/* Error Message */}
                  {emailError && (
                    <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                      <p className="text-red-700 text-sm flex items-center">
                        <AlertCircle className="w-4 h-4 mr-2" />
                        {emailError}
                      </p>
                    </div>
                  )}

                  {/* Submit Button */}
                  <div className="pt-6">
                    <Button
                      type="submit"
                      className="w-full bg-hexon-red hover:bg-hexon-red-dark text-white font-semibold py-3 rounded-xl transition-all duration-200 transform hover:scale-105 disabled:opacity-50 disabled:transform-none"
                      disabled={
                        isLoading ||
                        !formData.firstName ||
                        !formData.lastName ||
                        !formData.email ||
                        !formData.contactType ||
                        !formData.subject ||
                        !formData.message ||
                        !formData.acceptTerms ||
                        (formData.contactType === "partnership" &&
                          !formData.company)
                      }
                    >
                      {isLoading ? (
                        <>
                          <div className="w-4 h-4 mr-2 border-2 border-white border-t-transparent rounded-full animate-spin" />
                          Envoi en cours...
                        </>
                      ) : (
                        <>
                          <Send className="w-4 h-4 mr-2" />
                          Envoyer mon message
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* FAQ Section */}
          <div className="mt-16 max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-black mb-8 text-center font-roboto-condensed">
              QUESTIONS <span className="text-hexon-red">FRÉQUENTES</span>
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[
                {
                  q: "Quel est le délai de réponse ?",
                  a: "Nous répondons sous 24h pour les demandes normales, 4h pour les demandes prioritaires et 2h pour les urgences.",
                },
                {
                  q: "Comment suivre ma commande ?",
                  a: "Vous recevez un email avec le numéro de suivi dès l'expédition. Vous pouvez aussi nous contacter avec votre numéro de commande.",
                },
                {
                  q: "La garantie couvre-t-elle quoi ?",
                  a: "Nos PC sont garantis 1 an pièces et main d'œuvre. La garantie couvre tous les défauts de fabrication et composants.",
                },
                {
                  q: "Puis-je retourner mon PC ?",
                  a: "Vous avez 14 jours pour retourner votre PC sans justification. Les frais de retour sont à votre charge sauf défaut.",
                },
              ].map((faq, index) => (
                <Card key={index} className="border border-gray-200">
                  <CardContent className="p-6">
                    <h3 className="font-semibold text-black mb-2">{faq.q}</h3>
                    <p className="text-sm text-gray-600">{faq.a}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Bottom CTA */}
          <div className="mt-16 bg-gradient-to-r from-hexon-black to-gray-800 rounded-3xl p-8 lg:p-12 text-white text-center">
            <h3 className="text-3xl md:text-4xl font-bold mb-4 font-roboto-condensed">
              ASSISTANCE <span className="text-hexon-red">PREMIUM</span>
            </h3>
            <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
              Notre équipe d'experts est disponible 7 jours sur 7 pour vous
              accompagner dans tous vos projets gaming.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="space-y-2">
                <Users className="w-8 h-8 text-hexon-red mx-auto" />
                <div className="font-semibold">Équipe dédiée</div>
                <div className="text-sm text-gray-300">
                  Techniciens certifiés et passionnés
                </div>
              </div>
              <div className="space-y-2">
                <Clock className="w-8 h-8 text-hexon-red mx-auto" />
                <div className="font-semibold">Support réactif</div>
                <div className="text-sm text-gray-300">Réponse rapide 7j/7</div>
              </div>
              <div className="space-y-2">
                <Star className="w-8 h-8 text-hexon-red mx-auto" />
                <div className="font-semibold">Engagement qualité</div>
                <div className="text-sm text-gray-300">
                  Votre satisfaction est notre priorité
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
