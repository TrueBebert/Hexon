import Header from "../components/Header";
import Footer from "../components/Footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import {
  Shield,
  Eye,
  Lock,
  Database,
  UserCheck,
  Mail,
  ArrowLeft,
  FileText,
  Globe,
  Clock,
  Settings,
  AlertTriangle,
  Trash2,
  Truck,
  CreditCard,
} from "lucide-react";

export default function PolitiqueConfidentialitePage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <main className="py-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="mb-8">
            <Link
              to="/"
              className="inline-flex items-center text-hexon-red hover:text-hexon-red-dark mb-4"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour à l'accueil
            </Link>
            <Badge
              variant="secondary"
              className="mb-4 bg-hexon-red/10 text-hexon-red border-hexon-red/20"
            >
              Politique de Confidentialité
            </Badge>
            <h1 className="text-3xl font-bold text-black font-roboto-condensed">
              POLITIQUE DE{" "}
              <span className="text-hexon-red">CONFIDENTIALITÉ</span>
            </h1>
            <p className="text-gray-600 mt-2">
              Comment nous collectons, utilisons et protégeons vos données
              personnelles
            </p>
            <p className="text-sm text-gray-500 mt-1">
              Dernière mise à jour : {new Date().toLocaleDateString("fr-FR")}
            </p>
          </div>

          {/* Introduction */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Shield className="w-5 h-5 mr-2 text-hexon-red" />
                Introduction
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">
                HEXON s'engage à protéger et respecter votre vie privée. Cette
                politique explique comment nous collectons, utilisons et
                protégeons vos informations personnelles.
              </p>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <h3 className="font-semibold text-blue-800 mb-2">
                  🛡️ Notre engagement RGPD
                </h3>
                <p className="text-blue-700">
                  Cette politique est conforme au Règlement Général sur la
                  Protection des Données (RGPD) et à la loi française sur la
                  protection des données.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Responsable du traitement */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <UserCheck className="w-5 h-5 mr-2 text-hexon-red" />
                Responsable du Traitement
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div>
                  <h3 className="font-semibold mb-1">Identité</h3>
                  <p className="text-gray-600">
                    <strong>HEXON</strong> - Spécialiste PC Gaming
                  </p>
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Contact</h3>
                  <p className="text-gray-600">
                    Email : <strong>contact@hexonpc.com</strong>
                  </p>
                </div>
                <div>
                  <h3 className="font-semibold mb-1">
                    Délégué à la Protection des Données
                  </h3>
                  <p className="text-gray-600">
                    Pour toute question relative à vos données personnelles :
                    <strong> contact@hexonpc.com</strong>
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Données collectées */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Database className="w-5 h-5 mr-2 text-hexon-red" />
                Données Personnelles Collectées
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h3 className="font-semibold mb-3">
                  Données collectées directement
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-gray-50 rounded-lg p-4">
                    <h4 className="font-semibold text-sm mb-2">
                      🛒 Lors d'une commande
                    </h4>
                    <ul className="text-gray-600 text-sm space-y-1">
                      <li>• Nom et prénom</li>
                      <li>• Adresse email</li>
                      <li>• Numéro de téléphone</li>
                      <li>• Adresse de livraison/facturation</li>
                    </ul>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-4">
                    <h4 className="font-semibold text-sm mb-2">
                      📞 Lors d'un contact
                    </h4>
                    <ul className="text-gray-600 text-sm space-y-1">
                      <li>• Nom et prénom</li>
                      <li>• Adresse email</li>
                      <li>• Numéro de téléphone</li>
                      <li>• Message et demande</li>
                    </ul>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-4">
                    <h4 className="font-semibold text-sm mb-2">
                      🔧 Demande de maintenance
                    </h4>
                    <ul className="text-gray-600 text-sm space-y-1">
                      <li>• Informations de contact</li>
                      <li>• Description du problème</li>
                      <li>• Configuration matérielle</li>
                    </ul>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-4">
                    <h4 className="font-semibold text-sm mb-2">
                      🖥️ PC sur mesure
                    </h4>
                    <ul className="text-gray-600 text-sm space-y-1">
                      <li>• Préférences de configuration</li>
                      <li>• Budget et usage souhaité</li>
                      <li>• Informations de contact</li>
                    </ul>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="font-semibold mb-3">Données techniques</h3>
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                  <ul className="text-gray-600 space-y-1">
                    <li>• Adresse IP et données de connexion</li>
                    <li>• Type de navigateur et système d'exploitation</li>
                    <li>• Pages visitées et durée des sessions</li>
                    <li>• Cookies techniques nécessaires au fonctionnement</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Finalités du traitement */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Settings className="w-5 h-5 mr-2 text-hexon-red" />
                Finalités du Traitement
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-green-100 text-green-600 rounded-full flex items-center justify-center font-bold text-sm">
                    1
                  </div>
                  <div>
                    <h4 className="font-semibold">Gestion des commandes</h4>
                    <p className="text-gray-600 text-sm">
                      Traitement, suivi et livraison de vos commandes
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-green-100 text-green-600 rounded-full flex items-center justify-center font-bold text-sm">
                    2
                  </div>
                  <div>
                    <h4 className="font-semibold">Service client</h4>
                    <p className="text-gray-600 text-sm">
                      Réponse à vos questions et support technique
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-green-100 text-green-600 rounded-full flex items-center justify-center font-bold text-sm">
                    3
                  </div>
                  <div>
                    <h4 className="font-semibold">Garantie et SAV</h4>
                    <p className="text-gray-600 text-sm">
                      Gestion des garanties et du service après-vente
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center font-bold text-sm">
                    4
                  </div>
                  <div>
                    <h4 className="font-semibold">
                      Amélioration de nos services
                    </h4>
                    <p className="text-gray-600 text-sm">
                      Analyse anonymisée pour améliorer notre offre
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-purple-100 text-purple-600 rounded-full flex items-center justify-center font-bold text-sm">
                    5
                  </div>
                  <div>
                    <h4 className="font-semibold">
                      Communication (avec consentement)
                    </h4>
                    <p className="text-gray-600 text-sm">
                      Newsletter et offres spéciales si vous y consentez
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Base légale */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <FileText className="w-5 h-5 mr-2 text-hexon-red" />
                Base Légale du Traitement
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <h4 className="font-semibold text-green-800 mb-2">
                      📋 Exécution du contrat
                    </h4>
                    <p className="text-green-700 text-sm">
                      Traitement de vos commandes et livraisons
                    </p>
                  </div>
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <h4 className="font-semibold text-blue-800 mb-2">
                      ⚖️ Obligation légale
                    </h4>
                    <p className="text-blue-700 text-sm">
                      Facturation, comptabilité, garanties
                    </p>
                  </div>
                  <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                    <h4 className="font-semibold text-purple-800 mb-2">
                      ✅ Consentement
                    </h4>
                    <p className="text-purple-700 text-sm">
                      Newsletter et communications marketing
                    </p>
                  </div>
                  <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                    <h4 className="font-semibold text-orange-800 mb-2">
                      🎯 Intérêt légitime
                    </h4>
                    <p className="text-orange-700 text-sm">
                      Amélioration de nos services et sécurité
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Conservation des données */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Clock className="w-5 h-5 mr-2 text-hexon-red" />
                Durée de Conservation
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="space-y-3">
                  <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                    <span className="font-medium">Données de commande</span>
                    <span className="text-hexon-red font-semibold">10 ans</span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                    <span className="font-medium">Données de garantie</span>
                    <span className="text-hexon-red font-semibold">2 ans</span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                    <span className="font-medium">Données de contact</span>
                    <span className="text-hexon-red font-semibold">3 ans</span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                    <span className="font-medium">Données newsletter</span>
                    <span className="text-hexon-red font-semibold">
                      Jusqu'à désinscription
                    </span>
                  </div>
                </div>
                <p className="text-gray-600 text-sm">
                  Les données sont automatiquement supprimées à l'expiration de
                  ces délais, sauf obligation légale de conservation plus
                  longue.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Partage des données */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Globe className="w-5 h-5 mr-2 text-hexon-red" />
                Partage des Données
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold mb-3">
                  Nous partageons vos données uniquement avec :
                </h3>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
                    <Truck className="w-5 h-5 text-blue-600" />
                    <div>
                      <h4 className="font-semibold text-blue-800">
                        Transporteurs
                      </h4>
                      <p className="text-blue-700 text-sm">
                        Pour la livraison de vos commandes
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
                    <CreditCard className="w-5 h-5 text-green-600" />
                    <div>
                      <h4 className="font-semibold text-green-800">
                        Prestataires de paiement
                      </h4>
                      <p className="text-green-700 text-sm">
                        Pour le traitement sécurisé des paiements
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3 p-3 bg-purple-50 rounded-lg">
                    <Mail className="w-5 h-5 text-purple-600" />
                    <div>
                      <h4 className="font-semibold text-purple-800">
                        Service email
                      </h4>
                      <p className="text-purple-700 text-sm">
                        Pour l'envoi de confirmations et newsletters
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <h4 className="font-semibold text-red-800 mb-2">
                  ❌ Nous ne vendons jamais vos données
                </h4>
                <p className="text-red-700 text-sm">
                  Vos données personnelles ne sont ni vendues, ni louées, ni
                  partagées à des fins commerciales avec des tiers.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Sécurité */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Lock className="w-5 h-5 mr-2 text-hexon-red" />
                Sécurité des Données
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <h3 className="font-semibold mb-3">
                  Mesures de sécurité mises en place :
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="text-gray-600">
                      Cryptage SSL/TLS des données
                    </span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="text-gray-600">
                      Hébergement sécurisé en France
                    </span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="text-gray-600">
                      Accès restreint aux données
                    </span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="text-gray-600">
                      Sauvegardes régulières
                    </span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="text-gray-600">
                      Surveillance des intrusions
                    </span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="text-gray-600">
                      Mises à jour de sécurité
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Vos droits */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <UserCheck className="w-5 h-5 mr-2 text-hexon-red" />
                Vos Droits RGPD
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold mb-3">
                  Vous disposez des droits suivants :
                </h3>
                <div className="space-y-3">
                  <div className="flex items-start space-x-3">
                    <Eye className="w-5 h-5 text-blue-600 mt-0.5" />
                    <div>
                      <h4 className="font-semibold">Droit d'accès</h4>
                      <p className="text-gray-600 text-sm">
                        Consulter les données personnelles que nous détenons sur
                        vous
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <Settings className="w-5 h-5 text-green-600 mt-0.5" />
                    <div>
                      <h4 className="font-semibold">Droit de rectification</h4>
                      <p className="text-gray-600 text-sm">
                        Corriger ou mettre à jour vos données personnelles
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <Trash2 className="w-5 h-5 text-red-600 mt-0.5" />
                    <div>
                      <h4 className="font-semibold">Droit à l'effacement</h4>
                      <p className="text-gray-600 text-sm">
                        Demander la suppression de vos données personnelles
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <AlertTriangle className="w-5 h-5 text-orange-600 mt-0.5" />
                    <div>
                      <h4 className="font-semibold">Droit d'opposition</h4>
                      <p className="text-gray-600 text-sm">
                        Vous opposer au traitement de vos données
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <Database className="w-5 h-5 text-purple-600 mt-0.5" />
                    <div>
                      <h4 className="font-semibold">Droit à la portabilité</h4>
                      <p className="text-gray-600 text-sm">
                        Récupérer vos données dans un format structuré
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="bg-hexon-red/5 border border-hexon-red/20 rounded-lg p-4">
                <h4 className="font-semibold text-hexon-red mb-2">
                  📧 Exercer vos droits
                </h4>
                <p className="text-gray-700 text-sm">
                  Pour exercer vos droits, contactez-nous à{" "}
                  <strong>contact@hexonpc.com</strong> en précisant votre
                  demande. Nous vous répondrons sous 30 jours.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Cookies */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Eye className="w-5 h-5 mr-2 text-hexon-red" />
                Cookies et Traceurs
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold mb-3">
                  Types de cookies utilisés
                </h3>
                <div className="space-y-3">
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <h4 className="font-semibold text-green-800 mb-2">
                      🔧 Cookies techniques (obligatoires)
                    </h4>
                    <p className="text-green-700 text-sm mb-2">
                      Nécessaires au fonctionnement du site
                    </p>
                    <ul className="text-green-700 text-sm space-y-1">
                      <li>• Session et authentification</li>
                      <li>• Panier d'achat</li>
                      <li>• Préférences de navigation</li>
                    </ul>
                  </div>
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <h4 className="font-semibold text-blue-800 mb-2">
                      📊 Cookies analytiques (avec consentement)
                    </h4>
                    <p className="text-blue-700 text-sm">
                      Nous permettent d'analyser l'utilisation du site pour
                      l'améliorer
                    </p>
                  </div>
                </div>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Gestion des cookies</h3>
                <p className="text-gray-600 text-sm">
                  Vous pouvez configurer votre navigateur pour accepter ou
                  refuser les cookies. Attention : refuser les cookies
                  techniques peut affecter le fonctionnement du site.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Modifications */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <FileText className="w-5 h-5 mr-2 text-hexon-red" />
                Modifications de cette Politique
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">
                Cette politique de confidentialité peut être mise à jour pour
                refléter les changements dans nos pratiques ou pour des raisons
                légales.
              </p>
              <p className="text-gray-600">
                En cas de modifications importantes, nous vous en informerons
                par email ou via une notification sur notre site web.
              </p>
            </CardContent>
          </Card>

          {/* Contact */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Mail className="w-5 h-5 mr-2 text-hexon-red" />
                Contact et Questions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center">
                <p className="text-gray-600 mb-4">
                  Pour toute question concernant cette politique de
                  confidentialité ou le traitement de vos données personnelles :
                </p>
                <div className="space-y-2 mb-4">
                  <p>
                    <strong>Email :</strong> contact@hexonpc.com
                  </p>
                  <p className="text-sm text-gray-500">
                    Réponse garantie sous 30 jours
                  </p>
                </div>
                <Link to="/contact">
                  <Button className="bg-hexon-red hover:bg-hexon-red-dark text-white">
                    <Mail className="w-4 h-4 mr-2" />
                    Nous contacter
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  );
}
