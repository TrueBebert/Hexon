import { useState } from "react";
import Header from "../components/Header";
import Footer from "../components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Link } from "react-router-dom";
import {
  Eye,
  EyeOff,
  Mail,
  Lock,
  User,
  Phone,
  UserPlus,
  Shield,
  ArrowLeft,
  CheckCircle,
} from "lucide-react";

interface RegisterFormData {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  password: string;
  confirmPassword: string;
  acceptTerms: boolean;
  newsletter: boolean;
}

export default function RegisterPage() {
  const [formData, setFormData] = useState<RegisterFormData>({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    password: "",
    confirmPassword: "",
    acceptTerms: false,
    newsletter: true,
  });

  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<Partial<RegisterFormData>>({});
  const [isSuccess, setIsSuccess] = useState(false);

  const updateFormData = (field: keyof RegisterFormData, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    // Clear error for this field when user starts typing
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: undefined }));
    }
  };

  const validateForm = (): boolean => {
    const newErrors: Partial<RegisterFormData> = {};

    if (!formData.firstName.trim()) {
      newErrors.firstName = "Le prénom est requis";
    }

    if (!formData.lastName.trim()) {
      newErrors.lastName = "Le nom est requis";
    }

    if (!formData.email.trim()) {
      newErrors.email = "L'email est requis";
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = "Format d'email invalide";
    }

    if (!formData.password) {
      newErrors.password = "Le mot de passe est requis";
    } else if (formData.password.length < 6) {
      newErrors.password =
        "Le mot de passe doit contenir au moins 6 caractères";
    }

    if (!formData.confirmPassword) {
      newErrors.confirmPassword = "Veuillez confirmer le mot de passe";
    } else if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = "Les mots de passe ne correspondent pas";
    }

    if (!formData.acceptTerms) {
      newErrors.acceptTerms = "Vous devez accepter les conditions" as any;
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) return;

    setIsLoading(true);

    try {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 2000));

      console.log("Registration successful:", formData);
      setIsSuccess(true);
    } catch (err) {
      setErrors({ email: "Une erreur est survenue, veuillez réessayer" });
    } finally {
      setIsLoading(false);
    }
  };

  if (isSuccess) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <main className="py-20">
          <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <div className="bg-green-50 border-2 border-green-200 rounded-3xl p-12">
              <CheckCircle className="w-20 h-20 text-green-500 mx-auto mb-6" />
              <h1 className="text-3xl font-bold text-black mb-4 font-roboto-condensed">
                Compte créé avec succès !
              </h1>
              <p className="text-lg text-gray-600 mb-6">
                Bienvenue chez HEXON ! Votre compte a été créé avec succès. Vous
                pouvez maintenant vous connecter et profiter de tous nos
                services.
              </p>
              <div className="bg-white rounded-xl p-6 mb-6 text-left">
                <h3 className="font-semibold mb-3">Prochaines étapes :</h3>
                <div className="space-y-2 text-sm text-gray-600">
                  <div className="flex items-start space-x-2">
                    <span className="font-semibold text-hexon-red">1.</span>
                    <span>Email de confirmation envoyé à {formData.email}</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <span className="font-semibold text-hexon-red">2.</span>
                    <span>Cliquez sur le lien pour valider votre compte</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <span className="font-semibold text-hexon-red">3.</span>
                    <span>Connectez-vous et découvrez nos PC gaming</span>
                  </div>
                </div>
              </div>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link to="/login">
                  <Button className="bg-hexon-red hover:bg-hexon-red-dark text-white font-semibold px-8 py-3 rounded-xl w-full sm:w-auto">
                    Se connecter
                  </Button>
                </Link>
                <Link to="/">
                  <Button
                    variant="outline"
                    className="border-hexon-red text-hexon-red hover:bg-hexon-red hover:text-white font-semibold px-8 py-3 rounded-xl w-full sm:w-auto"
                  >
                    Découvrir nos PC
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <Header />

      <main className="py-8">
        <div className="max-w-md mx-auto px-4 sm:px-6 lg:px-8">
          {/* Back Link */}
          <div className="mb-6">
            <Link
              to="/"
              className="inline-flex items-center text-sm text-gray-600 hover:text-hexon-red transition-colors"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour à l'accueil
            </Link>
          </div>

          {/* Page Header */}
          <div className="text-center mb-8">
            <Badge
              variant="secondary"
              className="mb-4 bg-hexon-red/10 text-hexon-red border-hexon-red/20"
            >
              Inscription
            </Badge>
            <h1 className="text-3xl md:text-4xl font-bold text-black mb-4 font-roboto-condensed">
              REJOIGNEZ <span className="text-hexon-red">HEXON</span>
            </h1>
            <p className="text-gray-600">
              Créez votre compte pour accéder aux meilleurs PC gaming et
              bénéficier d'avantages exclusifs
            </p>
          </div>

          {/* Register Form */}
          <Card className="border-2 border-hexon-red/20">
            <CardHeader className="bg-hexon-red/5 text-center">
              <CardTitle className="text-xl font-bold text-black font-roboto-condensed flex items-center justify-center">
                <UserPlus className="w-5 h-5 mr-2 text-hexon-red" />
                CRÉER UN COMPTE
              </CardTitle>
            </CardHeader>
            <CardContent className="p-8">
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Personal Information */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <Label
                      htmlFor="firstName"
                      className="font-medium mb-2 block"
                    >
                      Prénom *
                    </Label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <User className="h-4 w-4 text-gray-400" />
                      </div>
                      <Input
                        id="firstName"
                        value={formData.firstName}
                        onChange={(e) =>
                          updateFormData("firstName", e.target.value)
                        }
                        placeholder="Votre prénom"
                        className="pl-9"
                        required
                      />
                    </div>
                    {errors.firstName && (
                      <p className="text-red-500 text-xs mt-1">
                        {errors.firstName}
                      </p>
                    )}
                  </div>

                  <div>
                    <Label
                      htmlFor="lastName"
                      className="font-medium mb-2 block"
                    >
                      Nom *
                    </Label>
                    <Input
                      id="lastName"
                      value={formData.lastName}
                      onChange={(e) =>
                        updateFormData("lastName", e.target.value)
                      }
                      placeholder="Votre nom"
                      required
                    />
                    {errors.lastName && (
                      <p className="text-red-500 text-xs mt-1">
                        {errors.lastName}
                      </p>
                    )}
                  </div>
                </div>

                {/* Email */}
                <div>
                  <Label htmlFor="email" className="font-medium mb-2 block">
                    Adresse email *
                  </Label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Mail className="h-5 w-5 text-gray-400" />
                    </div>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => updateFormData("email", e.target.value)}
                      placeholder="votre@email.com"
                      className="pl-10"
                      required
                    />
                  </div>
                  {errors.email && (
                    <p className="text-red-500 text-xs mt-1">{errors.email}</p>
                  )}
                </div>

                {/* Phone */}
                <div>
                  <Label htmlFor="phone" className="font-medium mb-2 block">
                    Téléphone (optionnel)
                  </Label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Phone className="h-5 w-5 text-gray-400" />
                    </div>
                    <Input
                      id="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => updateFormData("phone", e.target.value)}
                      placeholder="06 12 34 56 78"
                      className="pl-10"
                    />
                  </div>
                </div>

                {/* Password */}
                <div>
                  <Label htmlFor="password" className="font-medium mb-2 block">
                    Mot de passe *
                  </Label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Lock className="h-5 w-5 text-gray-400" />
                    </div>
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      value={formData.password}
                      onChange={(e) =>
                        updateFormData("password", e.target.value)
                      }
                      placeholder="Minimum 6 caractères"
                      className="pl-10 pr-10"
                      required
                    />
                    <button
                      type="button"
                      className="absolute inset-y-0 right-0 pr-3 flex items-center"
                      onClick={() => setShowPassword(!showPassword)}
                    >
                      {showPassword ? (
                        <EyeOff className="h-5 w-5 text-gray-400 hover:text-gray-600" />
                      ) : (
                        <Eye className="h-5 w-5 text-gray-400 hover:text-gray-600" />
                      )}
                    </button>
                  </div>
                  {errors.password && (
                    <p className="text-red-500 text-xs mt-1">
                      {errors.password}
                    </p>
                  )}
                </div>

                {/* Confirm Password */}
                <div>
                  <Label
                    htmlFor="confirmPassword"
                    className="font-medium mb-2 block"
                  >
                    Confirmer le mot de passe *
                  </Label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Lock className="h-5 w-5 text-gray-400" />
                    </div>
                    <Input
                      id="confirmPassword"
                      type={showConfirmPassword ? "text" : "password"}
                      value={formData.confirmPassword}
                      onChange={(e) =>
                        updateFormData("confirmPassword", e.target.value)
                      }
                      placeholder="Confirmer le mot de passe"
                      className="pl-10 pr-10"
                      required
                    />
                    <button
                      type="button"
                      className="absolute inset-y-0 right-0 pr-3 flex items-center"
                      onClick={() =>
                        setShowConfirmPassword(!showConfirmPassword)
                      }
                    >
                      {showConfirmPassword ? (
                        <EyeOff className="h-5 w-5 text-gray-400 hover:text-gray-600" />
                      ) : (
                        <Eye className="h-5 w-5 text-gray-400 hover:text-gray-600" />
                      )}
                    </button>
                  </div>
                  {errors.confirmPassword && (
                    <p className="text-red-500 text-xs mt-1">
                      {errors.confirmPassword}
                    </p>
                  )}
                </div>

                {/* Terms and Newsletter */}
                <div className="space-y-4">
                  <div className="flex items-start space-x-2">
                    <Checkbox
                      id="acceptTerms"
                      checked={formData.acceptTerms}
                      onCheckedChange={(checked) =>
                        updateFormData("acceptTerms", checked)
                      }
                      required
                    />
                    <Label
                      htmlFor="acceptTerms"
                      className="text-sm cursor-pointer leading-relaxed"
                    >
                      J'accepte les{" "}
                      <Link
                        to="/terms"
                        className="text-hexon-red hover:underline"
                      >
                        conditions d'utilisation
                      </Link>{" "}
                      et la{" "}
                      <Link
                        to="/privacy"
                        className="text-hexon-red hover:underline"
                      >
                        politique de confidentialité
                      </Link>{" "}
                      de HEXON *
                    </Label>
                  </div>
                  {errors.acceptTerms && (
                    <p className="text-red-500 text-xs">
                      {errors.acceptTerms as string}
                    </p>
                  )}

                  <div className="flex items-start space-x-2">
                    <Checkbox
                      id="newsletter"
                      checked={formData.newsletter}
                      onCheckedChange={(checked) =>
                        updateFormData("newsletter", checked)
                      }
                    />
                    <Label
                      htmlFor="newsletter"
                      className="text-sm cursor-pointer"
                    >
                      Je souhaite recevoir les newsletters HEXON avec les
                      nouveautés et offres exclusives
                    </Label>
                  </div>
                </div>

                {/* Submit Button */}
                <Button
                  type="submit"
                  disabled={isLoading}
                  className="w-full bg-hexon-red hover:bg-hexon-red-dark text-white font-semibold py-3 rounded-xl transition-all duration-200 transform hover:scale-105 disabled:transform-none disabled:opacity-50"
                >
                  {isLoading ? (
                    <div className="flex items-center justify-center">
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Création du compte...
                    </div>
                  ) : (
                    <div className="flex items-center justify-center">
                      <UserPlus className="w-4 h-4 mr-2" />
                      Créer mon compte
                    </div>
                  )}
                </Button>
              </form>

              {/* Login Link */}
              <div className="mt-6 text-center">
                <p className="text-gray-600">
                  Déjà un compte ?{" "}
                  <Link
                    to="/login"
                    className="text-hexon-red hover:text-hexon-red-dark font-medium transition-colors"
                  >
                    Se connecter
                  </Link>
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Benefits Section */}
          <div className="mt-8 bg-hexon-gray-light rounded-2xl p-6">
            <h3 className="font-bold text-black mb-4 text-center font-roboto-condensed">
              AVANTAGES COMPTE <span className="text-hexon-red">HEXON</span>
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div className="flex items-center space-x-2">
                <Shield className="w-4 h-4 text-hexon-red flex-shrink-0" />
                <span className="text-gray-700">
                  Suivi commandes temps réel
                </span>
              </div>
              <div className="flex items-center space-x-2">
                <User className="w-4 h-4 text-hexon-red flex-shrink-0" />
                <span className="text-gray-700">Historique et favoris</span>
              </div>
              <div className="flex items-center space-x-2">
                <Mail className="w-4 h-4 text-hexon-red flex-shrink-0" />
                <span className="text-gray-700">Offres exclusives membres</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-hexon-red flex-shrink-0" />
                <span className="text-gray-700">Support prioritaire</span>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
