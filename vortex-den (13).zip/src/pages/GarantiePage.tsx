import Header from "../components/Header";
import Footer from "../components/Footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import {
  Shield,
  Clock,
  CheckCircle,
  Phone,
  Mail,
  Wrench,
  ArrowLeft,
  AlertTriangle,
  FileText,
  Users,
} from "lucide-react";

export default function GarantiePage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      <main className="py-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="mb-8">
            <Link
              to="/"
              className="inline-flex items-center text-hexon-red hover:text-hexon-red-dark mb-4"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Retour à l'accueil
            </Link>
            <Badge
              variant="secondary"
              className="mb-4 bg-hexon-red/10 text-hexon-red border-hexon-red/20"
            >
              Garantie & SAV
            </Badge>
            <h1 className="text-3xl font-bold text-black font-roboto-condensed">
              GARANTIE ET{" "}
              <span className="text-hexon-red">SERVICE APRÈS-VENTE</span>
            </h1>
            <p className="text-gray-600 mt-2">
              Tout ce que vous devez savoir sur nos garanties et notre service
              après-vente
            </p>
          </div>

          {/* Garantie Standard */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Shield className="w-5 h-5 mr-2 text-hexon-red" />
                Garantie Standard HEXON
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold mb-2">✅ Durée de garantie</h3>
                  <p className="text-gray-600">
                    <strong>1 an</strong> pièces et main d'œuvre sur tous nos PC
                    gaming
                  </p>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">🔧 Couverture</h3>
                  <p className="text-gray-600">
                    Tous les défauts de fabrication et pannes matérielles
                  </p>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">⚡ Prise en charge</h3>
                  <p className="text-gray-600">
                    Réparation ou remplacement des composants défaillants
                  </p>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">📞 Support technique</h3>
                  <p className="text-gray-600">
                    Inclus pendant toute la durée de garantie
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Extension de Garantie */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Clock className="w-5 h-5 mr-2 text-hexon-red" />
                Extension de Garantie
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-4">
                <h3 className="font-semibold text-green-800 mb-2">
                  🛡️ Garantie étendue à 2 ans (+50€)
                </h3>
                <p className="text-green-700 text-sm">
                  Prolongez votre tranquillité d'esprit avec une année
                  supplémentaire de garantie complète.
                </p>
              </div>
              <p className="text-gray-600">
                L'extension de garantie peut être souscrite lors de l'achat ou
                dans les 30 jours suivant la livraison.
              </p>
            </CardContent>
          </Card>

          {/* Procédure SAV */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Wrench className="w-5 h-5 mr-2 text-hexon-red" />
                Procédure de Garantie
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-hexon-red text-white rounded-full flex items-center justify-center font-bold text-sm">
                    1
                  </div>
                  <div>
                    <h4 className="font-semibold">Contactez-nous</h4>
                    <p className="text-gray-600">
                      Écrivez-nous à <strong>contact@hexonpc.com</strong> en
                      décrivant le problème
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-hexon-red text-white rounded-full flex items-center justify-center font-bold text-sm">
                    2
                  </div>
                  <div>
                    <h4 className="font-semibold">Diagnostic</h4>
                    <p className="text-gray-600">
                      Notre équipe technique analysera le problème et vous
                      proposera une solution
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-hexon-red text-white rounded-full flex items-center justify-center font-bold text-sm">
                    3
                  </div>
                  <div>
                    <h4 className="font-semibold">Prise en charge</h4>
                    <p className="text-gray-600">
                      Si le problème est couvert, nous organisons la réparation
                      ou le remplacement
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Exclusions */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center">
                <AlertTriangle className="w-5 h-5 mr-2 text-orange-500" />
                Exclusions de Garantie
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 text-gray-600">
                <p>
                  ❌ <strong>Dommages physiques :</strong> Chutes, chocs,
                  liquides renversés
                </p>
                <p>
                  ❌ <strong>Mauvaise utilisation :</strong> Overclocking non
                  autorisé, modifications
                </p>
                <p>
                  ❌ <strong>Usure normale :</strong> Ventilateurs bruyants
                  après 6 mois d'usage
                </p>
                <p>
                  ❌ <strong>Logiciels :</strong> Virus, corruption de données,
                  OS défaillant
                </p>
                <p>
                  ❌ <strong>Périphériques :</strong> Claviers, souris et écrans
                  (garantie constructeur)
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Contact SAV */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Users className="w-5 h-5 mr-2 text-hexon-red" />
                Contactez notre SAV
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold mb-2">📧 Par email</h3>
                  <p className="text-gray-600 mb-4">
                    <strong>contact@hexonpc.com</strong>
                    <br />
                    Réponse sous 24h
                  </p>
                  <Link to="/contact">
                    <Button className="bg-hexon-red hover:bg-hexon-red-dark text-white">
                      <Mail className="w-4 h-4 mr-2" />
                      Contacter le SAV
                    </Button>
                  </Link>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">
                    📄 Informations à fournir
                  </h3>
                  <ul className="text-gray-600 text-sm space-y-1">
                    <li>• Numéro de commande ou facture</li>
                    <li>• Description détaillée du problème</li>
                    <li>• Photos si dommage visible</li>
                    <li>• Configuration de votre PC</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      <Footer />
    </div>
  );
}
