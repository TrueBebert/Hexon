import { useState } from "react";
import Header from "../components/Header";
import Footer from "../components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Link } from "react-router-dom";
import {
  Gamepad2,
  Monitor,
  Cpu,
  HardDrive,
  Zap,
  Palette,
  Euro,
  CheckCircle,
  ArrowRight,
  ArrowLeft,
  Settings,
  Star,
  Clock,
  Shield,
  AlertCircle,
} from "lucide-react";
import { sendPCConfigEmail } from "@/lib/emailjs";

interface FormData {
  // Usage
  primaryUse: string;
  games: string[];
  resolution: string;
  frameRate: string;

  // Budget
  budget: number[];
  paymentMethod: string;

  // Components
  preferredBrands: {
    cpu: string;
    gpu: string;
    ram: string;
    storage: string;
  };

  // Design
  caseStyle: string;
  lighting: string;
  colorScheme: string;

  // Services
  additionalServices: string[];

  // Contact
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  additionalInfo: string;
}

const steps = [
  { id: 1, title: "Usage", icon: Gamepad2 },
  { id: 2, title: "Budget", icon: Euro },
  { id: 3, title: "Composants", icon: Cpu },
  { id: 4, title: "Design", icon: Palette },
  { id: 5, title: "Services", icon: Settings },
  { id: 6, title: "Contact", icon: CheckCircle },
];

const games = [
  "Cyberpunk 2077",
  "Call of Duty",
  "Valorant",
  "League of Legends",
  "Fortnite",
  "Apex Legends",
  "GTA V",
  "Red Dead Redemption 2",
  "Minecraft",
  "World of Warcraft",
  "CS2",
  "Overwatch 2",
];

const initialFormData: FormData = {
  primaryUse: "",
  games: [],
  resolution: "",
  frameRate: "",
  budget: [2000],
  paymentMethod: "",
  preferredBrands: {
    cpu: "",
    gpu: "",
    ram: "",
    storage: "",
  },
  caseStyle: "",
  lighting: "",
  colorScheme: "",
  additionalServices: [],
  firstName: "",
  lastName: "",
  email: "",
  phone: "",
  additionalInfo: "",
};

export default function PCSurMesurePage() {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState<FormData>(initialFormData);
  const [isLoading, setIsLoading] = useState(false);
  const [emailError, setEmailError] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);

  const updateFormData = (field: string, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const updateNestedFormData = (parent: string, field: string, value: any) => {
    setFormData((prev) => ({
      ...prev,
      [parent]: { ...(prev[parent as keyof FormData] as any), [field]: value },
    }));
  };

  const nextStep = () => {
    if (currentStep < steps.length) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = async () => {
    setIsLoading(true);
    setEmailError("");

    try {
      // Préparer les données pour l'email avec les vrais champs du formulaire
      const emailData = {
        usage: formData.primaryUse || "Non spécifié",
        games: formData.games?.join(", ") || "Non spécifié",
        resolution: formData.resolution || "Non spécifié",
        frameRate: formData.frameRate || "Non spécifié",
        budget: formData.budget[0] || 0,
        paymentMethod: formData.paymentMethod || "Non spécifié",
        processor: formData.preferredBrands?.cpu || "Non spécifié",
        graphicsCard: formData.preferredBrands?.gpu || "Non spécifié",
        memory: formData.preferredBrands?.ram || "Non spécifié",
        storage: formData.preferredBrands?.storage || "Non spécifié",
        motherboard: "Sélection automatique selon config",
        powerSupply: "Sélection automatique selon config",
        cooling: "Sélection automatique selon config",
        caseType: formData.caseStyle || "Non spécifié",
        rgbLighting: formData.lighting || "Non spécifié",
        caseColor: formData.colorScheme || "Non spécifié",
        services: formData.additionalServices || [],
        firstName: formData.firstName,
        lastName: formData.lastName,
        email: formData.email,
        phone: formData.phone,
        additionalInfo: formData.additionalInfo,
      };

      const success = await sendPCConfigEmail(emailData);

      if (success) {
        console.log("PC Config form submitted successfully:", formData);
        setIsSubmitted(true);
      } else {
        setEmailError("Erreur lors de l'envoi. Veuillez réessayer.");
      }
    } catch (error) {
      console.error("Error submitting PC config form:", error);
      setEmailError("Erreur technique. Veuillez réessayer plus tard.");
    } finally {
      setIsLoading(false);
    }
  };

  // Page de confirmation après soumission
  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <main className="py-20">
          <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <div className="bg-green-50 border-2 border-green-200 rounded-3xl p-12">
              <CheckCircle className="w-20 h-20 text-green-500 mx-auto mb-6" />
              <h1 className="text-3xl font-bold text-black mb-4 font-roboto-condensed">
                Configuration envoyée !
              </h1>
              <p className="text-lg text-gray-600 mb-6">
                Merci pour votre demande de PC sur mesure. Notre équipe va
                analyser vos besoins et vous contacter sous 24h avec un devis
                personnalisé.
              </p>
              <div className="bg-white rounded-xl p-6 mb-6 text-left">
                <h3 className="font-semibold mb-3">Récapitulatif :</h3>
                <div className="space-y-2 text-sm text-gray-600">
                  <div className="flex justify-between">
                    <span>Usage principal :</span>
                    <span className="font-medium">{formData.primaryUse}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Budget :</span>
                    <span className="font-medium">{formData.budget[0]}€</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Contact :</span>
                    <span className="font-medium">{formData.email}</span>
                  </div>
                </div>
              </div>
              <div className="space-y-3">
                <Link to="/">
                  <Button className="bg-hexon-red hover:bg-hexon-red-dark text-white font-semibold px-8 py-3 rounded-xl w-full sm:w-auto">
                    Retour à l'accueil
                  </Button>
                </Link>
                <p className="text-sm text-gray-500">
                  Vous recevrez un email de confirmation
                </p>
              </div>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-8">
            <div>
              <Label className="text-lg font-semibold mb-4 block">
                Quel sera l'usage principal de votre PC ?
              </Label>
              <RadioGroup
                value={formData.primaryUse}
                onValueChange={(value) => updateFormData("primaryUse", value)}
                className="grid grid-cols-1 md:grid-cols-2 gap-4"
              >
                {[
                  {
                    value: "gaming",
                    label: "Gaming",
                    icon: Gamepad2,
                    desc: "Jeux en haute résolution",
                  },
                  {
                    value: "streaming",
                    label: "Gaming + Streaming",
                    icon: Monitor,
                    desc: "Jeux + diffusion live",
                  },
                  {
                    value: "creation",
                    label: "Création de contenu",
                    icon: Settings,
                    desc: "Montage vidéo, 3D, design",
                  },
                  {
                    value: "work-gaming",
                    label: "Travail + Gaming",
                    icon: Cpu,
                    desc: "Polyvalent bureau et jeux",
                  },
                ].map((option) => (
                  <div
                    key={option.value}
                    className="flex items-center space-x-2"
                  >
                    <RadioGroupItem value={option.value} id={option.value} />
                    <Label
                      htmlFor={option.value}
                      className="flex items-center space-x-3 cursor-pointer p-4 border rounded-lg hover:bg-gray-50 flex-1"
                    >
                      <option.icon className="w-6 h-6 text-hexon-red" />
                      <div>
                        <div className="font-semibold">{option.label}</div>
                        <div className="text-sm text-gray-500">
                          {option.desc}
                        </div>
                      </div>
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            </div>

            <div>
              <Label className="text-lg font-semibold mb-4 block">
                Quels jeux comptez-vous jouer ? (optionnel)
              </Label>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                {games.map((game) => (
                  <div key={game} className="flex items-center space-x-2">
                    <Checkbox
                      id={game}
                      checked={formData.games.includes(game)}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          updateFormData("games", [...formData.games, game]);
                        } else {
                          updateFormData(
                            "games",
                            formData.games.filter((g) => g !== game),
                          );
                        }
                      }}
                    />
                    <Label htmlFor={game} className="text-sm cursor-pointer">
                      {game}
                    </Label>
                  </div>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label className="text-lg font-semibold mb-4 block">
                  Résolution souhaitée
                </Label>
                <Select
                  value={formData.resolution}
                  onValueChange={(value) => updateFormData("resolution", value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Choisir la résolution" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1080p">1920x1080 (1080p)</SelectItem>
                    <SelectItem value="1440p">2560x1440 (1440p)</SelectItem>
                    <SelectItem value="4k">3840x2160 (4K)</SelectItem>
                    <SelectItem value="ultrawide">
                      3440x1440 (Ultrawide)
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label className="text-lg font-semibold mb-4 block">
                  Framerate cible
                </Label>
                <Select
                  value={formData.frameRate}
                  onValueChange={(value) => updateFormData("frameRate", value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="FPS souhaités" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="60fps">60 FPS</SelectItem>
                    <SelectItem value="120fps">120 FPS</SelectItem>
                    <SelectItem value="144fps">144 FPS</SelectItem>
                    <SelectItem value="240fps">240+ FPS</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-8">
            <div>
              <Label className="text-lg font-semibold mb-4 block">
                Quel est votre budget ? ({formData.budget[0]}€)
              </Label>
              <div className="space-y-4">
                <Slider
                  value={formData.budget}
                  onValueChange={(value) => updateFormData("budget", value)}
                  max={5000}
                  min={500}
                  step={100}
                  className="w-full"
                />
                <div className="flex justify-between text-sm text-gray-500">
                  <span>500€</span>
                  <span>2500€</span>
                  <span>5000€+</span>
                </div>
              </div>

              <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
                {[
                  {
                    range: "500-1500€",
                    label: "Entrée de gamme",
                    desc: "Gaming 1080p fluide",
                  },
                  {
                    range: "1500-3000€",
                    label: "Milieu de gamme",
                    desc: "Gaming 1440p / 4K",
                  },
                  {
                    range: "3000€+",
                    label: "Haut de gamme",
                    desc: "4K Ultra / Streaming",
                  },
                ].map((tier) => (
                  <Card
                    key={tier.range}
                    className="border border-gray-200 hover:border-hexon-red/30 transition-colors"
                  >
                    <CardContent className="p-4 text-center">
                      <div className="font-semibold text-hexon-red">
                        {tier.range}
                      </div>
                      <div className="font-medium">{tier.label}</div>
                      <div className="text-sm text-gray-500">{tier.desc}</div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            <div>
              <Label className="text-lg font-semibold mb-4 block">
                Mode de paiement souhaité
              </Label>
              <RadioGroup
                value={formData.paymentMethod}
                onValueChange={(value) =>
                  updateFormData("paymentMethod", value)
                }
                className="space-y-3"
              >
                {[
                  {
                    value: "cb",
                    label: "Carte bancaire",
                    desc: "Paiement sécurisé 3D Secure",
                  },
                  {
                    value: "paypal",
                    label: "PayPal",
                    desc: "Paiement rapide et sécurisé",
                  },
                  {
                    value: "virement",
                    label: "Virement SEPA",
                    desc: "Pour entreprises et commandes importantes",
                  },
                ].map((option) => (
                  <div
                    key={option.value}
                    className="flex items-center space-x-2"
                  >
                    <RadioGroupItem value={option.value} id={option.value} />
                    <Label
                      htmlFor={option.value}
                      className="cursor-pointer flex-1"
                    >
                      <div className="flex justify-between">
                        <span className="font-medium">{option.label}</span>
                        <span className="text-sm text-gray-500">
                          {option.desc}
                        </span>
                      </div>
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-8">
            <div>
              <Label className="text-lg font-semibold mb-4 block">
                Avez-vous des préférences de marques ?
              </Label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <Label className="font-medium mb-2 block">Processeur</Label>
                  <Select
                    value={formData.preferredBrands.cpu}
                    onValueChange={(value) =>
                      updateNestedFormData("preferredBrands", "cpu", value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Aucune préférence" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="intel">
                        Intel (recommandé gaming)
                      </SelectItem>
                      <SelectItem value="amd">
                        AMD (excellent rapport qualité/prix)
                      </SelectItem>
                      <SelectItem value="no-preference">
                        Aucune préférence
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="font-medium mb-2 block">
                    Carte graphique
                  </Label>
                  <Select
                    value={formData.preferredBrands.gpu}
                    onValueChange={(value) =>
                      updateNestedFormData("preferredBrands", "gpu", value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Aucune préférence" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="nvidia">NVIDIA (RTX, DLSS)</SelectItem>
                      <SelectItem value="amd">
                        AMD (excellent rapport perf/prix)
                      </SelectItem>
                      <SelectItem value="no-preference">
                        Aucune préférence
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="font-medium mb-2 block">Mémoire RAM</Label>
                  <Select
                    value={formData.preferredBrands.ram}
                    onValueChange={(value) =>
                      updateNestedFormData("preferredBrands", "ram", value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Aucune préférence" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="corsair">Corsair</SelectItem>
                      <SelectItem value="gskill">G.Skill</SelectItem>
                      <SelectItem value="kingston">Kingston</SelectItem>
                      <SelectItem value="no-preference">
                        Aucune préférence
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="font-medium mb-2 block">Stockage</Label>
                  <Select
                    value={formData.preferredBrands.storage}
                    onValueChange={(value) =>
                      updateNestedFormData("preferredBrands", "storage", value)
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Aucune préférence" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="samsung">
                        Samsung (performances)
                      </SelectItem>
                      <SelectItem value="western-digital">
                        Western Digital
                      </SelectItem>
                      <SelectItem value="crucial">
                        Crucial (rapport qualité/prix)
                      </SelectItem>
                      <SelectItem value="no-preference">
                        Aucune préférence
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            <div className="bg-hexon-gray-light rounded-xl p-6">
              <h3 className="font-semibold mb-4 flex items-center">
                <Star className="w-5 h-5 text-hexon-red mr-2" />
                Nos recommandations
              </h3>
              <div className="text-sm text-gray-600 space-y-2">
                <p>
                  • <strong>Gaming pur :</strong> Intel + NVIDIA pour les
                  meilleures performances
                </p>
                <p>
                  • <strong>Streaming :</strong> AMD CPU + NVIDIA GPU pour
                  encoder et jouer simultanément
                </p>
                <p>
                  • <strong>Budget optimisé :</strong> AMD CPU + GPU pour le
                  meilleur rapport qualité/prix
                </p>
              </div>
            </div>
          </div>
        );

      case 4:
        return (
          <div className="space-y-8">
            <div>
              <Label className="text-lg font-semibold mb-4 block">
                Style de boîtier
              </Label>
              <RadioGroup
                value={formData.caseStyle}
                onValueChange={(value) => updateFormData("caseStyle", value)}
                className="grid grid-cols-1 md:grid-cols-2 gap-4"
              >
                {[
                  {
                    value: "minimalist",
                    label: "Minimaliste",
                    desc: "Design épuré, discret",
                  },
                  {
                    value: "gaming",
                    label: "Gaming",
                    desc: "Look agressif, LED intégrées",
                  },
                  {
                    value: "premium",
                    label: "Premium",
                    desc: "Matériaux haut de gamme",
                  },
                  {
                    value: "compact",
                    label: "Compact",
                    desc: "Encombrement réduit",
                  },
                ].map((option) => (
                  <div
                    key={option.value}
                    className="flex items-center space-x-2"
                  >
                    <RadioGroupItem value={option.value} id={option.value} />
                    <Label
                      htmlFor={option.value}
                      className="cursor-pointer p-4 border rounded-lg hover:bg-gray-50 flex-1"
                    >
                      <div className="font-semibold">{option.label}</div>
                      <div className="text-sm text-gray-500">{option.desc}</div>
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            </div>

            <div>
              <Label className="text-lg font-semibold mb-4 block">
                Éclairage RGB
              </Label>
              <RadioGroup
                value={formData.lighting}
                onValueChange={(value) => updateFormData("lighting", value)}
                className="space-y-3"
              >
                {[
                  {
                    value: "full-rgb",
                    label: "RGB complet",
                    desc: "Éclairage synchronisé sur tous les composants",
                  },
                  {
                    value: "minimal-rgb",
                    label: "RGB discret",
                    desc: "Éclairage subtil et élégant",
                  },
                  {
                    value: "no-rgb",
                    label: "Sans RGB",
                    desc: "Look professionnel, sans éclairage",
                  },
                ].map((option) => (
                  <div
                    key={option.value}
                    className="flex items-center space-x-2"
                  >
                    <RadioGroupItem value={option.value} id={option.value} />
                    <Label
                      htmlFor={option.value}
                      className="cursor-pointer flex-1"
                    >
                      <div className="flex justify-between">
                        <span className="font-medium">{option.label}</span>
                        <span className="text-sm text-gray-500">
                          {option.desc}
                        </span>
                      </div>
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            </div>

            <div>
              <Label className="text-lg font-semibold mb-4 block">
                Couleur principale
              </Label>
              <div className="grid grid-cols-3 md:grid-cols-6 gap-3">
                {[
                  { value: "red", label: "Rouge", color: "bg-red-500" },
                  { value: "blue", label: "Bleu", color: "bg-blue-500" },
                  { value: "green", label: "Vert", color: "bg-green-500" },
                  { value: "purple", label: "Violet", color: "bg-purple-500" },
                  { value: "black", label: "Noir", color: "bg-black" },
                  { value: "white", label: "Blanc", color: "bg-white border" },
                ].map((color) => (
                  <button
                    key={color.value}
                    onClick={() => updateFormData("colorScheme", color.value)}
                    className={`p-3 rounded-lg border-2 transition-all ${
                      formData.colorScheme === color.value
                        ? "border-hexon-red"
                        : "border-gray-200 hover:border-gray-300"
                    }`}
                  >
                    <div
                      className={`w-8 h-8 rounded-full ${color.color} mx-auto mb-2`}
                    ></div>
                    <div className="text-xs">{color.label}</div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        );

      case 5:
        return (
          <div className="space-y-8">
            <div>
              <Label className="text-lg font-semibold mb-4 block">
                Services additionnels
              </Label>
              <div className="space-y-4">
                {[
                  {
                    value: "windows-install",
                    label: "Installation Windows + pilotes",
                    desc: "Windows 11 Pro + tous les pilotes mis à jour",
                    price: "Inclus",
                  },
                  {
                    value: "pc-optimization",
                    label: "Optimisation du PC",
                    desc: "Réglages avancés pour performances maximales",
                    price: "+50€",
                  },
                  {
                    value: "extended-warranty",
                    label: "Garantie étendue 2 ans",
                    desc: "Extension de garantie de 1 an à 2 ans",
                    price: "+50€",
                  },
                ].map((service) => (
                  <div
                    key={service.value}
                    className="flex items-center space-x-3 p-4 border rounded-lg"
                  >
                    <Checkbox
                      id={service.value}
                      checked={formData.additionalServices.includes(
                        service.value,
                      )}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          updateFormData("additionalServices", [
                            ...formData.additionalServices,
                            service.value,
                          ]);
                        } else {
                          updateFormData(
                            "additionalServices",
                            formData.additionalServices.filter(
                              (s) => s !== service.value,
                            ),
                          );
                        }
                      }}
                    />
                    <div className="flex-1">
                      <div className="font-semibold">{service.label}</div>
                      <div className="text-sm text-gray-500">
                        {service.desc}
                      </div>
                    </div>
                    <Badge
                      variant={
                        service.price === "Inclus" ? "default" : "secondary"
                      }
                    >
                      {service.price}
                    </Badge>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-hexon-gray-light rounded-xl p-6">
              <h3 className="font-semibold mb-4 flex items-center">
                <Shield className="w-5 h-5 text-hexon-red mr-2" />
                Garanties HEXON
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                <div className="flex items-center space-x-2 text-sm text-green-700">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  <span>Garantie 1 an incluse</span>
                </div>
                <div className="flex items-center space-x-2 text-sm text-green-700">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  <span>Tests complets inclus</span>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  <span>Support technique 7j/7</span>
                </div>
              </div>
            </div>
          </div>
        );

      case 6:
        return (
          <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="firstName" className="font-medium mb-2 block">
                  Prénom *
                </Label>
                <Input
                  id="firstName"
                  value={formData.firstName}
                  onChange={(e) => updateFormData("firstName", e.target.value)}
                  placeholder="Votre prénom"
                  required
                />
              </div>

              <div>
                <Label htmlFor="lastName" className="font-medium mb-2 block">
                  Nom *
                </Label>
                <Input
                  id="lastName"
                  value={formData.lastName}
                  onChange={(e) => updateFormData("lastName", e.target.value)}
                  placeholder="Votre nom"
                  required
                />
              </div>

              <div>
                <Label htmlFor="email" className="font-medium mb-2 block">
                  Email *
                </Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => updateFormData("email", e.target.value)}
                  placeholder="votre@email.com"
                  required
                />
              </div>

              <div>
                <Label htmlFor="phone" className="font-medium mb-2 block">
                  Téléphone
                </Label>
                <Input
                  id="phone"
                  type="tel"
                  value={formData.phone}
                  onChange={(e) => updateFormData("phone", e.target.value)}
                  placeholder="06 12 34 56 78"
                />
              </div>
            </div>

            <div>
              <Label
                htmlFor="additionalInfo"
                className="font-medium mb-2 block"
              >
                Informations complémentaires
              </Label>
              <Textarea
                id="additionalInfo"
                value={formData.additionalInfo}
                onChange={(e) =>
                  updateFormData("additionalInfo", e.target.value)
                }
                placeholder="Précisions supplémentaires, contraintes particulières, questions..."
                rows={4}
              />
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
              <h3 className="font-semibold mb-4 flex items-center">
                <Clock className="w-5 h-5 text-blue-600 mr-2" />
                Étapes suivantes
              </h3>
              <div className="space-y-3 text-sm text-blue-800">
                <div className="flex items-start space-x-2">
                  <span className="font-semibold">1.</span>
                  <span>
                    Réception et analyse de votre demande (dans les 2h)
                  </span>
                </div>
                <div className="flex items-start space-x-2">
                  <span className="font-semibold">2.</span>
                  <span>
                    Appel de notre expert pour affiner votre configuration
                  </span>
                </div>
                <div className="flex items-start space-x-2">
                  <span className="font-semibold">3.</span>
                  <span>Devis détaillé avec tarifs et délais</span>
                </div>
                <div className="flex items-start space-x-2">
                  <span className="font-semibold">4.</span>
                  <span>Assemblage et tests (5-7 jours ouvrés)</span>
                </div>
                <div className="flex items-start space-x-2">
                  <span className="font-semibold">5.</span>
                  <span>Livraison de votre PC prêt à l'emploi</span>
                </div>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <Header />

      <main className="py-8">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Page Header */}
          <div className="text-center mb-12">
            <Badge
              variant="secondary"
              className="mb-4 bg-hexon-red/10 text-hexon-red border-hexon-red/20"
            >
              PC Sur Mesure
            </Badge>
            <h1 className="text-4xl md:text-5xl font-bold text-black mb-6 font-roboto-condensed">
              CRÉEZ VOTRE PC <span className="text-hexon-red">PARFAIT</span>
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Configurez votre PC gaming idéal avec l'aide de nos experts.
              Chaque composant est sélectionné selon vos besoins et votre
              budget.
            </p>
          </div>

          {/* Progress Steps */}
          <div className="mb-12">
            <div className="flex items-center justify-between mb-8">
              {steps.map((step, index) => (
                <div key={step.id} className="flex items-center">
                  <div
                    className={`flex items-center justify-center w-12 h-12 rounded-full border-2 transition-all ${
                      currentStep >= step.id
                        ? "bg-hexon-red border-hexon-red text-white"
                        : currentStep === step.id
                          ? "border-hexon-red text-hexon-red"
                          : "border-gray-300 text-gray-300"
                    }`}
                  >
                    <step.icon className="w-5 h-5" />
                  </div>
                  <div
                    className={`ml-3 hidden sm:block ${
                      currentStep >= step.id
                        ? "text-hexon-red"
                        : "text-gray-500"
                    }`}
                  >
                    <div className="font-semibold text-sm">{step.title}</div>
                  </div>
                  {index < steps.length - 1 && (
                    <div
                      className={`w-12 md:w-24 h-1 mx-4 transition-all ${
                        currentStep > step.id ? "bg-hexon-red" : "bg-gray-200"
                      }`}
                    />
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Form Content */}
          <Card className="max-w-4xl mx-auto">
            <CardHeader>
              <CardTitle className="text-2xl font-bold text-center">
                {steps[currentStep - 1].title}
              </CardTitle>
            </CardHeader>
            <CardContent className="p-8">
              {renderStepContent()}

              {/* Navigation Buttons */}
              {/* Error Message */}
              {emailError && (
                <div className="p-4 bg-red-50 border border-red-200 rounded-lg mb-4">
                  <p className="text-red-700 text-sm flex items-center">
                    <AlertCircle className="w-4 h-4 mr-2" />
                    {emailError}
                  </p>
                </div>
              )}

              <div className="flex justify-between pt-6">
                <Button
                  variant="outline"
                  onClick={prevStep}
                  disabled={currentStep === 1 || isLoading}
                  className="flex items-center space-x-2"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>Précédent</span>
                </Button>

                {currentStep < steps.length ? (
                  <Button
                    onClick={nextStep}
                    disabled={isLoading}
                    className="bg-hexon-red hover:bg-hexon-red-dark text-white flex items-center space-x-2"
                  >
                    <span>Suivant</span>
                    <ArrowRight className="w-4 h-4" />
                  </Button>
                ) : (
                  <Button
                    onClick={handleSubmit}
                    className="bg-hexon-red hover:bg-hexon-red-dark text-white flex items-center space-x-2 disabled:opacity-50"
                    disabled={
                      isLoading ||
                      !formData.firstName ||
                      !formData.lastName ||
                      !formData.email
                    }
                  >
                    {isLoading ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        <span>Envoi en cours...</span>
                      </>
                    ) : (
                      <>
                        <CheckCircle className="w-4 h-4" />
                        <span>Envoyer ma demande</span>
                      </>
                    )}
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Bottom Trust Section */}
          <div className="mt-16 bg-gradient-to-r from-hexon-black to-gray-800 rounded-3xl p-8 lg:p-12 text-white text-center">
            <h3 className="text-3xl md:text-4xl font-bold mb-4 font-roboto-condensed">
              Pourquoi choisir HEXON ?
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-8">
              <div className="space-y-2">
                <Star className="w-8 h-8 text-hexon-red mx-auto" />
                <div className="font-semibold">Passion gaming</div>
                <div className="text-sm text-gray-300">
                  Équipe de passionnés dédiée aux meilleures performances
                </div>
              </div>
              <div className="space-y-2">
                <Shield className="w-8 h-8 text-hexon-red mx-auto" />
                <div className="font-semibold">Garantie premium</div>
                <div className="text-sm text-gray-300">
                  1 an de garantie + support technique illimité
                </div>
              </div>
              <div className="space-y-2">
                <Clock className="w-8 h-8 text-hexon-red mx-auto" />
                <div className="font-semibold">Assemblage Premium</div>
                <div className="text-sm text-gray-300">
                  Assemblage soigné en 5-7 jours ouvrés
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
